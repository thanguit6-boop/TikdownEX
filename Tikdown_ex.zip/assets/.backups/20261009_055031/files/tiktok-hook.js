(function(){(function(){var N,G,W,z;if(window.__DOWNLOAD_HOOK__)return;window.__DOWNLOAD_HOOK__=!0;const b=()=>{};let q="",P=null;function ee(){try{const e=location.pathname.match(/^\/@([^/?#]+)/);return e?e[1]:""}catch{return""}}function te(e){if(!e||typeof e!="object")return!1;const r=e.commerceUserInfo;if(r&&typeof r=="object"&&(r.commerceUser===!0||typeof r.category=="string"&&r.category.length>0||typeof r.sellerLevel=="number"&&r.sellerLevel>0||r.starInfo&&typeof r.starInfo=="object")||e.ttSeller===!0)return!0;if(e.bioLink&&typeof e.bioLink=="object"){const d=String(e.bioLink.link||"");if(/tiktok\.com\/.*\/shop|\/shop\/|tiktok\.com\/@[^/]+\/shop/i.test(d))return!0}return!1}let p={backgroundPlay:!1,autoPiP:!1,volumeNormalizer:!1,playbackSpeed:1};const M=(N=Object.getOwnPropertyDescriptor(Document.prototype,"hidden"))==null?void 0:N.get,F=(G=Object.getOwnPropertyDescriptor(Document.prototype,"visibilityState"))==null?void 0:G.get;function _(){return M?!!M.call(document):!1}const re=window.requestAnimationFrame.bind(window),oe=window.cancelAnimationFrame.bind(window);let D=!1;function ne(){D||(D=!0,window.requestAnimationFrame=e=>_()?window.setTimeout(()=>e(performance.now()),16):re(e),window.cancelAnimationFrame=e=>{_()?window.clearTimeout(e):oe(e)})}ne(),window.addEventListener("__download_settings__",e=>{const r=e.detail;r&&typeof r=="object"&&(p={...p,...r},K(),C(),A())});try{Object.defineProperty(document,"hidden",{configurable:!0,get(){return p.backgroundPlay?!1:_()}}),Object.defineProperty(document,"visibilityState",{configurable:!0,get(){return p.backgroundPlay?"visible":F?F.call(document):"visible"}})}catch{}let x=!1;function ie(){return p.autoPiP&&(_()||!document.hasFocus())}async function E(e){if(!ie()||x)return;const r=j();if(!(!r||document.pictureInPictureElement===r)){x=!0;try{T(r),await r.requestPictureInPicture()}catch{B()}finally{x=!1}}}function A(e){setTimeout(()=>E(),250),setTimeout(()=>E(),700),setTimeout(()=>E(),1400),setTimeout(()=>E(),2400)}async function R(){if(document.pictureInPictureElement)try{await document.exitPictureInPicture()}catch{}}const U=e=>{e.isTrusted&&(p.autoPiP&&(e.type==="visibilitychange"?_()?A():R():e.type==="blur"?setTimeout(()=>{document.hasFocus()||A()},150):e.type==="focus"&&R()),p.backgroundPlay&&e.stopImmediatePropagation())};for(const e of["visibilitychange","pagehide","blur","focus"])window.addEventListener(e,U,!0),document.addEventListener(e,U,!0);function ce(){document.querySelectorAll("video").forEach(e=>{const r=p.playbackSpeed||1;if(Math.abs(e.playbackRate-r)>.01)try{e.playbackRate=r}catch{}})}const v=((W=window.AudioContext)==null?void 0:W.prototype)||((z=window.webkitAudioContext)==null?void 0:z.prototype),V=v==null?void 0:v.createMediaElementSource;if(v&&V){const e=new WeakSet;v.createMediaElementSource=function(r){const d=V.call(this,r);if(e.has(r))return d;e.add(r);try{const h=this,c=h.createDynamicsCompressor();c.threshold.value=-24,c.knee.value=30,c.ratio.value=12,c.attack.value=.003,c.release.value=.25;const g=h.createGain();g.gain.value=1.5;const s=d.connect;let a=!0;d.connect=function(f,y,k){return a&&(a=!1,p.volumeNormalizer)?(s.call(this,c),c.connect(g),g.connect(f,y,k),f):s.call(this,f,y,k)}}catch{}return d}}function C(){if("mediaSession"in navigator)try{navigator.mediaSession.setActionHandler("enterpictureinpicture",async()=>{if(!p.autoPiP)return;const e=j();if(e){T(e);try{await e.requestPictureInPicture()}catch{B()}}}),navigator.mediaSession.setActionHandler("nexttrack",()=>{ae(),setTimeout(O,100),A("media-nexttrack")}),navigator.mediaSession.setActionHandler("previoustrack",()=>{le(),setTimeout(O,100),A("media-previoustrack")})}catch{}}function T(e){e.removeAttribute("disablepictureinpicture"),e.disablePictureInPicture=!1,p.autoPiP?(e.setAttribute("autopictureinpicture","true"),e.autoPictureInPicture=!0):(e.removeAttribute("autopictureinpicture"),e.autoPictureInPicture=!1)}function se(){document.querySelectorAll("video").forEach(e=>{try{T(e),e.__downloadHookPipPlaying||(e.__downloadHookPipPlaying=!0,e.addEventListener("playing",()=>{const r=document.pictureInPictureElement;if(!(!p.autoPiP||!r||r===e))try{T(e),e.requestPictureInPicture().catch(()=>{})}catch{}}))}catch{}})}function O(){if(!p.autoPiP||!("mediaSession"in navigator))return;const e=j();if(e)try{document.pictureInPictureElement||(navigator.mediaSession.metadata=new MediaMetadata({title:"Download",artist:"Auto PiP Enabled",artwork:[]})),navigator.mediaSession.playbackState=e.paused?"paused":"playing"}catch{}}function B(){var e;try{(e=document.querySelector('[data-e2e="more-menu-popover_mini-player"]'))==null||e.click()}catch{}}function ae(){const e=document.querySelector('[data-e2e="arrow-right"], [data-e2e="arrow-down"], button[data-e2e="video-switch-next"]');if(e){e.click();return}(document.querySelector('[data-e2e="recommend-list-item-container"]')||document.getElementById("app")||document.documentElement).dispatchEvent(new KeyboardEvent("keydown",{key:"ArrowDown",code:"ArrowDown",keyCode:40,which:40,bubbles:!0,cancelable:!0,composed:!0,view:window})),setTimeout(()=>window.scrollBy({top:window.innerHeight,behavior:"smooth"}),150)}function le(){const e=document.querySelector('[data-e2e="arrow-left"], [data-e2e="arrow-up"], button[data-e2e="video-switch-prev"]');if(e){e.click();return}(document.querySelector('[data-e2e="recommend-list-item-container"]')||document.getElementById("app")||document.documentElement).dispatchEvent(new KeyboardEvent("keydown",{key:"ArrowUp",code:"ArrowUp",keyCode:38,which:38,bubbles:!0,cancelable:!0,composed:!0,view:window})),setTimeout(()=>window.scrollBy({top:-window.innerHeight,behavior:"smooth"}),150)}function j(){var d;const e=Array.from(document.querySelectorAll("video"));if(!e.length)return null;const r=window.innerHeight/2;return((d=e.map(h=>{const c=h.getBoundingClientRect(),g=Math.max(0,Math.min(c.bottom,window.innerHeight)-Math.max(c.top,0)),s=Math.max(0,Math.min(c.right,window.innerWidth)-Math.max(c.left,0)),a=g*s,f=Math.abs((c.top+c.bottom)/2-r),y=(h.paused?0:1e6)+(h.readyState>=2?1e5:0)+a-f;return{video:h,score:y}}).sort((h,c)=>c.score-h.score)[0])==null?void 0:d.video)||null}function K(){ce(),se(),O()}C(),setInterval(C,2e3),setInterval(K,1e3);try{const e=window.fetch;window.fetch=async function(...r){var h;const d=await e.apply(this,r);try{const c=typeof r[0]=="string"?r[0]:r[0]instanceof Request?r[0].url:((h=r[0])==null?void 0:h.url)||"";typeof c=="string"&&/tiktok\.com\/api\//.test(c)&&!/\/inbox\/|\/notice|\/check\b/i.test(c)&&d.clone().json().then(s=>{var Y,$,J,Q,X;let a=[];if(Array.isArray(s==null?void 0:s.itemList))a=s.itemList;else if(Array.isArray(s==null?void 0:s.items))a=s.items;else if(Array.isArray(s==null?void 0:s.aweme_list))a=s.aweme_list;else if(s&&typeof s=="object")for(const t of Object.keys(s)){const n=s[t];if(Array.isArray(n)&&n.length&&n[0]&&typeof n[0]=="object"){if((n[0].id||n[0].aweme_id)&&(n[0].author||n[0].video||n[0].music)){a=n;break}const wKey=n[0].item?"item":(n[0].aweme_info?"aweme_info":null);if(wKey&&n[0][wKey]&&(n[0][wKey].id||n[0][wKey].aweme_id)&&(n[0][wKey].author||n[0][wKey].video||n[0][wKey].music)){a=n.map(x=>x&&x[wKey]).filter(Boolean);break}}}if(!a.length)return;b("item_list response:",c.slice(0,120),"items=",a.length);const f=ee();if(f&&q!==f&&(q=f,P=null,b("profile owner changed →",f,"(reset shop flag)")),f&&P===null){let t=!1;for(const n of a)if(((Y=n==null?void 0:n.author)==null?void 0:Y.uniqueId)===f&&(t=!0,te(n.author))){P=!0;const m=n.author.commerceUserInfo,w=n.author.bioLink;b("profile owner",f,"detected as SHOP creator",{commerceUserInfo:m?Object.keys(m).slice(0,10):null,ttSeller:n.author.ttSeller,bioLink:w&&typeof w=="object"?w.link:null});break}P===null&&t&&(P=!1,b("profile owner",f,"detected as NON-shop creator"))}try{window.postMessage({type:"__DOWNLOAD_PROBE_URL__",url:c.slice(0,200)+" → items: "+a.length},"*")}catch{}const y=[],k=[],H=[];for(const t of a){if(!t)continue;const n=String(t.id||t.video_id||t.aweme_id||"");if(!n||!/^\d{6,}$/.test(n))continue;let m=!1;if(Array.isArray(t.anchors))for(const i of t.anchors){if(!i||i.type!==33)continue;const u=String(i.schema||i.action_url||""),o=i.extra||{},S=/\/shop\//.test(u)||!!o.product_id||!!o.shop_id,L=typeof i.keyword=="string"?i.keyword:"",fe=/capcut|edit like|editing made|template|effect/i.test(L);if(S||L&&!fe){m=!0;break}if(!L&&!u&&!Object.keys(o).length){m=!0;break}}if(!m&&Array.isArray(t.anchors_extras)){for(const i of t.anchors_extras)if(i&&(i.type===33||i.anchor_type===33)){m=!0;break}}if(!m&&Array.isArray(t.contents)){for(const i of t.contents)if(i){if(Array.isArray(i.anchors)){for(const u of i.anchors)if(u&&u.type===33){m=!0;break}}if(m)break}}let w=!1;const l=t.commerceProductInfo||t.commerce_product_info;if(l&&typeof l=="object"){const i=l.products||l.product_list;if(Array.isArray(i)&&i.length>0){const u=i[0];u&&(u.product_id||u.title)&&(w=!0)}else(l.product_id||l.title)&&(w=!0)}let I=!1,Z=!1;!m&&!w&&(t.isECVideo===1||t.isECVideo===!0)&&(Array.isArray(t.anchors)&&t.anchors.some(u=>u&&u.type===54)?P===!0&&(I=!0,Z=!0):I=!0);const ue=m||w||I;if(H.length<5){const i=Array.isArray(t.anchors)?t.anchors.map(o=>({type:o==null?void 0:o.type,keyword:typeof(o==null?void 0:o.keyword)=="string"?o.keyword.slice(0,40):o==null?void 0:o.keyword,extra_keys:o!=null&&o.extra&&typeof o.extra=="object"?Object.keys(o.extra).slice(0,10):null})):null,u=l&&typeof l=="object"?{keys:Object.keys(l).slice(0,10),productsLen:Array.isArray(l.products)?l.products.length:null,product0_id:(J=($=l.products)==null?void 0:$[0])==null?void 0:J.product_id,product0_title:typeof((X=(Q=l.products)==null?void 0:Q[0])==null?void 0:X.title)=="string"?l.products[0].title.slice(0,40):null,direct_product_id:l.product_id,direct_title:typeof l.title=="string"?l.title.slice(0,40):null}:null;H.push({id:n,hasShopAnchor:m,hasRealCommerceProduct:w,relaxedByProfileShop:Z,anchorsDump:i,AnchorTypes:t.AnchorTypes,isECVideo:t.isECVideo,cpiDump:u,anchors_extras:Array.isArray(t.anchors_extras)?t.anchors_extras.map(o=>({type:o==null?void 0:o.type,anchor_type:o==null?void 0:o.anchor_type,keys:o?Object.keys(o).slice(0,8):null})):t.anchors_extras,contents_summary:Array.isArray(t.contents)?t.contents.map(o=>({desc:typeof(o==null?void 0:o.desc)=="string"?o.desc.slice(0,60):null,anchorTypes:Array.isArray(o==null?void 0:o.anchors)?o.anchors.map(S=>S==null?void 0:S.type):null})):null,desc:typeof t.desc=="string"?t.desc.slice(0,120):null,itemKeys:Object.keys(t).filter(o=>/commerce|product|anchor|shop|ec|tcm/i.test(o)),allKeys:Object.keys(t).slice(0,40)})}ue?y.push(n):!I&&(t.isECVideo===0||t.isECVideo===!1||t.isECVideo===void 0)&&!t.AnchorTypes&&(Array.isArray(t.anchors)&&t.anchors.some(u=>u&&u.type===54)||k.push(n))}const _ks=window.__downloadKnownShop||(window.__downloadKnownShop=new Set());for(const x of a){if(x&&x.author&&x.author.uniqueId&&te(x.author))_ks.add(x.author.uniqueId)}let _upg=0;for(const x of a){if(!x||!x.author||!x.author.uniqueId)continue;if(_ks.has(x.author.uniqueId)){const id=x.id||x.aweme_id;if(!id)continue;const ni=k.indexOf(id);if(ni>=0)k.splice(ni,1);if(!y.includes(id)){y.push(id);_upg++}}}b("[D7] knownShopCreators set:",_ks.size,"upgraded ids=",_upg),b("item_list classified: total=",a.length," shop=",y.length," nonShop=",k.length," unclassified=",a.length-y.length-k.length),window.postMessage({type:"__DOWNLOAD_PROFILE_POSTS__",shopIds:y,nonShopIds:k,total:a.length,sample:H},"*")}).catch(()=>{})}catch{}return d}}catch{}

/* ===== [Download] Search-result PiP + player + download + speed =====
 * TikTok normally renders search cards as <img> thumbnails and only creates a
 * <video> after the card is opened.  This control is attached to the card's
 * /video/ link, not just to an already-created <video>.  If no native preview
 * video is available, the content-script bridge loads the selected card's
 * stream into one private media element and PiP is requested from that element.
 * The adjacent player and download controls use the same selected card URL
 * existing TIKTOK_DOWNLOAD handler.  Playback speed is a tab-session override
 * so TikTok/React and the older rate synchronizer cannot reset it.
 */
(function(){
if(window.__DOWNLOAD_SEARCH_PIP__)return;window.__DOWNLOAD_SEARCH_PIP__=!0;
try{window.dispatchEvent(new CustomEvent("__download_settings__",{detail:{autoScroll:false,backgroundPlay:false,autoPiP:false,cleanVideoMode:false,unlockShopVideo:false,productViewer:true,volumeNormalizer:true,playbackSpeed:1}}))}catch{}
const documentPipSupported=!!(window.documentPictureInPicture&&typeof window.documentPictureInPicture.requestWindow==="function");
const pipSupported=documentPipSupported||!!document.pictureInPictureEnabled&&typeof HTMLVideoElement!=="undefined"&&typeof HTMLVideoElement.prototype.requestPictureInPicture==="function";

const PIP_BUTTON_CLASS="__download_search_pip_btn",PLAYER_BUTTON_CLASS="__download_search_player_btn",DOWNLOAD_BUTTON_CLASS="__download_search_download_btn",SPEED_BUTTON_CLASS="__download_search_speed_btn",SPEED_MENU_CLASS="__download_search_speed_menu",PLAYER_OVERLAY_ID="__download_search_video_player",PLAYER_CONTROLS_CLASS="__download_player_controls",PLAYER_WINDOW_NAME="DownloadVideoPlayer",PLAYER_REQUEST_PARAM="__download_player",PLAYER_SPEED_PARAM="__download_speed",PLAYER_SPEED_MESSAGE="__DOWNLOAD_PLAYER_SPEED__",REQUEST_TYPE="__DOWNLOAD_SEARCH_PIP_MEDIA_REQUEST__",RESPONSE_TYPE="__DOWNLOAD_SEARCH_PIP_MEDIA_RESPONSE__",DOWNLOAD_REQUEST_TYPE="__DOWNLOAD_SEARCH_DOWNLOAD_REQUEST__",DOWNLOAD_RESPONSE_TYPE="__DOWNLOAD_SEARCH_DOWNLOAD_RESPONSE__";
const busy=new WeakSet,downloadBusy=new WeakSet,streamCache=new Map,streamRequests=new Map,pendingRequests=new Map,pendingDownloads=new Map,queuedNodes=new Set,pipActivatedUrls=new Set,playerActivatedUrls=new Set,downloadActivatedUrls=new Set;
let warmVideo=null,documentPipWindow=null,documentPipPlaybackSpeed=null,scanScheduled=!1,lastHref=location.href,requestNumber=0,wasSearchPage=!1,basePlaybackSpeed=1,syncingSearchSpeed=!1,playerRequestStarted=!1,playerPopup=null,playerPopupSpeed=null;
/* "Luôn hiển thị trên cùng" (popup.html). Chrome gives extensions no way to pin an ordinary popup
 * window on top, so when this is on the player button opens the video in a Document Picture-in-Picture
 * window instead, which Chrome always keeps above other windows. The value is relayed by
 * tiktok-loader.js (ISOLATED world) at startup and on every change, so it is live without a reload. */
let playerAlwaysOnTop=!1;
window.addEventListener("__DOWNLOAD_PLAYER_ALWAYS_ON_TOP__",event=>{playerAlwaysOnTop=!!(event&&event.detail&&event.detail.enabled===!0)});
/* ===== Player size / position memory =====
 * Remembers how big the user made each player and where they left it, for both
 * players: "win" = the dedicated popup window, "pip" = the always-on-top
 * Document PiP window.  Sizes are viewport (inner) sizes and are kept per video
 * shape (portrait / square / landscape): the next video of the same shape
 * reuses the user's size, a different shape (9:16 -> 16:9) is fitted again.
 * x/y is the window's screen position.  This MAIN-world hook cannot use
 * chrome.storage, so tiktok-loader.js (ISOLATED world) keeps everything in
 * chrome.storage.local (survives closing the browser) and relays it here with
 * CustomEvents, the same way it relays the always-on-top option above. */
let playerBounds={},playerBoundsLoaded=!1,playerBoundsWaiters=[];
window.addEventListener("__DOWNLOAD_PLAYER_BOUNDS__",event=>{
try{const parsed=JSON.parse(event&&event.detail&&event.detail.json);if(parsed&&typeof parsed==="object")playerBounds=parsed}catch{}
playerBoundsLoaded=!0;const waiters=playerBoundsWaiters;playerBoundsWaiters=[];for(const done of waiters)done()
});
try{window.dispatchEvent(new CustomEvent("__DOWNLOAD_PLAYER_BOUNDS_REQUEST__"))}catch{}
function playerBoundsReady(timeout){
if(playerBoundsLoaded)return Promise.resolve();
return new Promise(resolve=>{const timer=setTimeout(resolve,timeout||800);playerBoundsWaiters.push(()=>{clearTimeout(timer);resolve()})})
}
function playerShape(vw,vh){const ratio=vw/vh;return ratio<.8?"portrait":ratio>1.25?"landscape":"square"}
function savedPlayerBounds(mode){const rec=playerBounds&&playerBounds[mode];return rec&&typeof rec==="object"?rec:{}}
function savedPlayerSize(mode,shape){
const rec=savedPlayerBounds(mode),size=rec.sizes&&rec.sizes[shape];
return size&&Number.isFinite(size.w)&&Number.isFinite(size.h)&&size.w>=120&&size.h>=80?{w:Math.round(size.w),h:Math.round(size.h)}:null
}
/* Size to open a new window at before its video (and so its shape) is known: the last size used. */
function playerStartSize(mode,fallback){
const size=savedPlayerSize(mode,savedPlayerBounds(mode).last)||fallback,scr=window.screen||{};
return{w:Math.min(size.w,scr.availWidth||size.w),h:Math.min(size.h,scr.availHeight||size.h)}
}
function pipWindowOptions(){const size=playerStartSize("pip",{w:400,h:680});return{width:size.w,height:size.h}}
function playerWindowFeatures(){
const rec=savedPlayerBounds("win"),size=playerStartSize("win",{w:560,h:820});
let features="popup=yes,width="+size.w+",height="+size.h+",resizable=yes,scrollbars=no";
if(Number.isFinite(rec.x)&&Number.isFinite(rec.y))features+=",left="+Math.round(rec.x)+",top="+Math.round(rec.y);
return features
}
/* True while the window is maximised or fullscreen (outer size covers the work area). */
function playerWindowIsFilled(win){
try{
if(win.document&&win.document.fullscreenElement)return!0;
const scr=win.screen||{};
return!!scr.availWidth&&win.outerWidth>=scr.availWidth-2&&win.outerHeight>=scr.availHeight-2
}catch{return!1}
}
function savePlayerBounds(mode,patch){
try{
const rec=Object.assign({},savedPlayerBounds(mode));rec.sizes=Object.assign({},rec.sizes);
if(patch.shape&&Number.isFinite(patch.w)&&Number.isFinite(patch.h)){rec.sizes[patch.shape]={w:Math.round(patch.w),h:Math.round(patch.h)};rec.last=patch.shape}
if(Number.isFinite(patch.x)&&Number.isFinite(patch.y)){rec.x=Math.round(patch.x);rec.y=Math.round(patch.y)}
if(typeof patch.max==="boolean")rec.max=patch.max;
playerBounds=Object.assign({},playerBounds,{[mode]:rec});
window.dispatchEvent(new CustomEvent("__DOWNLOAD_PLAYER_BOUNDS_SAVE__",{detail:{json:JSON.stringify(Object.assign({mode},patch))}}))
}catch{}
}
/* Resize a player window so its VIEWPORT becomes width x height.  resizeTo() is read as an outer size by
 * normal popups; if a window reads it differently the one-shot resizeBy() below corrects the difference.
 * Chrome may still clamp the result (e.g. Document PiP has a maximum size). */
function applyPlayerInnerSize(win,width,height){
try{
const tw=Math.round(width),th=Math.round(height);
win.__downloadBoundsHold=Date.now()+1800;
if(Math.abs(win.innerWidth-tw)<=3&&Math.abs(win.innerHeight-th)<=3)return;
const extraW=Math.max(0,win.outerWidth-win.innerWidth),extraH=Math.max(0,win.outerHeight-win.innerHeight);
win.resizeTo(tw+extraW,th+extraH);
win.setTimeout(()=>{try{
const dx=tw-win.innerWidth,dy=th-win.innerHeight;if(Math.abs(dx)>3||Math.abs(dy)>3)win.resizeBy(dx,dy);
}catch{}},350)
}catch{}
}
/* Watches a player window and saves its size / position once the user has stopped changing it
 * (there is no "moved" event, so it polls).  getShape() returns the shape of the video currently shown. */
function trackPlayerBounds(win,mode,getShape){
if(!win||win.__downloadBoundsTracker)return;
win.__downloadBoundsTracker=!0;
let lastSig="",savedSig="",stableSince=Date.now(),timer=0;
const stop=()=>{try{win.clearInterval(timer)}catch{}};
const snapshot=force=>{
if(win.closed){stop();return}
if(Date.now()<(win.__downloadBoundsHold||0)){lastSig="";return}
if(win.document&&win.document.fullscreenElement)return;
const w=win.innerWidth,h=win.innerHeight;if(!(w>0&&h>0))return;
const filled=mode==="win"&&playerWindowIsFilled(win),sig=filled?"max":[w,h,win.screenX,win.screenY].join();
if(!force){if(sig!==lastSig){lastSig=sig;stableSince=Date.now();return}if(Date.now()-stableSince<450)return}
if(sig===savedSig)return;
const shape=getShape();if(!shape)return;
savedSig=sig;
filled?savePlayerBounds(mode,{max:!0}):savePlayerBounds(mode,{shape,w,h,x:win.screenX,y:win.screenY,max:!1})
};
try{timer=win.setInterval(()=>{try{snapshot(!1)}catch{}},250)}catch{}
try{win.addEventListener("pagehide",()=>{try{snapshot(!0)}catch{}stop()},{once:!0})}catch{}
}
const SPEED_STORAGE_KEY="__download_search_playback_speed_v1",PIP_SPEED_STORAGE_KEY="__download_document_pip_speed_v1",SPEED_MIN=.5,SPEED_MAX=3;
let searchPlaybackSpeed=null;
try{const saved=Number(sessionStorage.getItem(SPEED_STORAGE_KEY));Number.isFinite(saved)&&saved>=SPEED_MIN&&saved<=SPEED_MAX&&(searchPlaybackSpeed=saved)}catch{}
try{const saved=Number(sessionStorage.getItem(PIP_SPEED_STORAGE_KEY));Number.isFinite(saved)&&saved>=.25&&saved<=3&&(documentPipPlaybackSpeed=saved)}catch{}

/* The original Auto PiP hook reacts to any preview video that starts playing.
 * Guard its requestPictureInPicture() call while a search card has been put in
 * PiP manually.  A deliberate click on another Download PiP button is permitted. */
(function(){
if(window.__DOWNLOAD_SEARCH_PIP_LOCK_GUARD__||typeof HTMLVideoElement==="undefined")return;
const request=HTMLVideoElement.prototype.requestPictureInPicture;if(typeof request!=="function")return;
window.__DOWNLOAD_SEARCH_PIP_LOCK_GUARD__=!0;
HTMLVideoElement.prototype.requestPictureInPicture=function(...args){
const locked=window.__DOWNLOAD_SEARCH_PIP_LOCK__,allowed=window.__DOWNLOAD_SEARCH_PIP_ALLOW__;
if(locked&&document.pictureInPictureElement!==locked)window.__DOWNLOAD_SEARCH_PIP_LOCK__=null;
if(locked&&document.pictureInPictureElement===locked&&this!==locked&&this!==allowed)return Promise.reject(new DOMException("Download search PiP is locked to the selected video","NotAllowedError"));
return request.apply(this,args)
}
})();
function lockSearchPiP(video){
if(!video)return;
window.__DOWNLOAD_SEARCH_PIP_LOCK__=video;
if(video.__downloadSearchPipLockBound)return;
video.__downloadSearchPipLockBound=!0;
video.addEventListener("leavepictureinpicture",()=>{if(window.__DOWNLOAD_SEARCH_PIP_LOCK__===video)window.__DOWNLOAD_SEARCH_PIP_LOCK__=null;broadcastPipClosed(video.__downloadSearchPipUrl)})
}
function unlockSearchPiP(video){if(!video||window.__DOWNLOAD_SEARCH_PIP_LOCK__===video)window.__DOWNLOAD_SEARCH_PIP_LOCK__=null}
async function requestSelectedPiP(video,waitForReady){
window.__DOWNLOAD_SEARCH_PIP_ALLOW__=video;
try{return await enterPiP(video,waitForReady)}finally{if(window.__DOWNLOAD_SEARCH_PIP_ALLOW__===video)window.__DOWNLOAD_SEARCH_PIP_ALLOW__=null}
}

/* Search and Explore use the same card controls and dynamic-card observer. */
function isSearchPage(){try{return/^\/(?:search|explore)(?:\/|$)/.test(location.pathname)}catch{return!1}}
function isDedicatedPlayerWindow(){try{return new URL(location.href).searchParams.has(PLAYER_REQUEST_PARAM)}catch{return!1}}
if(isDedicatedPlayerWindow())try{const style=document.createElement("style");style.id="__download_player_hide_search_actions";style.textContent="."+PIP_BUTTON_CLASS+",."+PLAYER_BUTTON_CLASS+",."+DOWNLOAD_BUTTON_CLASS+",."+SPEED_BUTTON_CLASS+",.__download_dl_btn{display:none!important}";(document.head||document.documentElement).appendChild(style)}catch{}
function icon(){return'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.25" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="4.5" width="20" height="15" rx="2"/><rect x="12.5" y="12" width="7.5" height="5.5" rx="1" fill="currentColor" stroke="none"/></svg>'}
function playerIcon(){return'<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.25" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="m10 9 5 3-5 3Z" fill="currentColor" stroke="none"/></svg>'}
function downloadIcon(){const src=document.documentElement&&document.documentElement.dataset.downloadExtensionIcon;return src?'<img src="'+src+'" alt="" style="display:block!important;width:23px!important;height:23px!important;object-fit:contain!important">':'<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.35" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></svg>'}

function videoUrl(value){
try{const url=new URL(value,location.href);return url.protocol==="https:"&&/(^|\.)tiktok\.com$/i.test(url.hostname)&&/\/video\/\d+/.test(url.pathname)?url.href:""}catch{return""}
}
function hasCardSize(el){
try{const r=el.getBoundingClientRect();return r.width>=76&&r.height>=76&&r.width<=720&&r.height<=1100}catch{return!1}
}
function isThumbnailLink(link){return!!(link&&hasCardSize(link)&&(link.querySelector("img,video,picture,canvas")||link.querySelector("[style*='background']")))}
function buttonLabel(btn){return btn&&btn.dataset.downloadAction==="player"?"Mở video trên cửa sổ riêng":btn&&btn.dataset.downloadAction==="download"?"Tải xuống":btn&&btn.dataset.downloadAction==="speed"?"Playback speed":"Trình phát nổi"}
function setButtonState(btn,state,message){
if(!btn||!btn.isConnected)return;
btn.dataset.downloadPipState=state||"";
btn.title=message||buttonLabel(btn);
btn.setAttribute("aria-label",btn.title);
btn.style.background=state==="loading"?"rgba(8,145,178,.9)":state==="active"?"#2adc00":state==="error"?"rgba(220,38,38,.9)":"rgba(0,0,0,.62)";
}
function actionState(action){return action==="player"?{urls:playerActivatedUrls,message:"Đã xem"}:action==="download"?{urls:downloadActivatedUrls,message:"Đã tải"}:{urls:pipActivatedUrls,message:"Đã xem"}}
function flash(btn,message){setButtonState(btn,"error",message||buttonLabel(btn)+" is unavailable");setTimeout(()=>{let url="";try{url=typeof btn.__downloadGetUrl==="function"&&btn.__downloadGetUrl()||""}catch{}const action=btn&&btn.dataset.downloadAction,state=actionState(action);if((action==="pip"||action==="player"||action==="download")&&url&&state.urls.has(url))setButtonState(btn,"active",state.message);else setButtonState(btn,"",buttonLabel(btn))},1400)}
function markCardActionActive(btn,url,activatedUrls,message){if(url)activatedUrls.add(url);setButtonState(btn,"active",message)}
function restoreCardActionState(btn,url,activatedUrls,message){if(!btn)return;if(url&&activatedUrls.has(url))setButtonState(btn,"active",message);else if(btn.dataset.downloadPipState==="active")setButtonState(btn,"",buttonLabel(btn))}
/* ===== [Download] Multi-select panel bridge =====
 * The multi-select side panel (assets/multi-select.js) runs in the ISOLATED
 * world and has no direct access to this MAIN-world module's state, so it
 * signals a completed download with a CustomEvent — the same cross-world
 * pattern __download_settings__ already uses. This just reuses the existing
 * "active" (green) button state and downloadActivatedUrls set, so a video
 * downloaded from the panel looks exactly like one downloaded from this
 * card's own Download button, and survives card re-render the same way. */
window.addEventListener("__download_multi_mark_downloaded__",event=>{
try{
const url=event&&event.detail&&event.detail.url;
if(!url)return;
downloadActivatedUrls.add(url);
document.querySelectorAll("."+DOWNLOAD_BUTTON_CLASS).forEach(btn=>{
const btnUrl=typeof btn.__downloadGetUrl==="function"&&btn.__downloadGetUrl();
if(btnUrl===url)setButtonState(btn,"active","Đã tải")
})
}catch{}
});
/* ===== [Download] Player select button =====
 * A checkbox identical to the one multi-select.js puts on every search card
 * (top-left, purple/cyan gradient when ticked), added to the video being
 * played in the dedicated player window and in the always-on-top (Document
 * PiP) player.  It ticks / unticks that video in the "Video đã chọn" list.
 * The selection lives in multi-select.js (ISOLATED world, search tab), so:
 *  - Document PiP player and in-page player (same tab as the cards): the same
 *    CustomEvent pattern as the PiP bridge above (toggle / query go to
 *    multi-select.js, its state events come back).
 *  - dedicated popup window (a separate page): postMessage to window.opener
 *    (the search tab that opened it, the same link the speed sync uses).  The
 *    opener relays to multi-select.js and posts every state change back. */
const SELECT_BUTTON_CLASS="__download_player_select_btn",SELECT_TOGGLE_EVENT="__DOWNLOAD_MULTISELECT_SELECT_TOGGLE__",SELECT_QUERY_EVENT="__DOWNLOAD_MULTISELECT_SELECT_QUERY__",SELECT_STATE_EVENT="__DOWNLOAD_MULTISELECT_SELECTION_STATE__",PLAYER_SELECT_TOGGLE_MESSAGE="__DOWNLOAD_PLAYER_SELECT_TOGGLE__",PLAYER_SELECT_QUERY_MESSAGE="__DOWNLOAD_PLAYER_SELECT_QUERY__",PLAYER_SELECT_STATE_MESSAGE="__DOWNLOAD_PLAYER_SELECT_STATE__";
const playerSelectEntries=new Set,selectionByUrl=new Map,selectSubscribers=new Set;
function selectMeta(thumb,title){return{thumb:typeof thumb==="string"&&/^https:\/\//i.test(thumb)?thumb.slice(0,2048):"",title:typeof title==="string"?title.trim().slice(0,200):""}}
/* Players that live in the same tab as multi-select.js. */
const localSelectBridge={
toggle(target){try{window.dispatchEvent(new CustomEvent(SELECT_TOGGLE_EVENT,{detail:{url:target.url,thumb:target.thumb||"",title:target.title||""}}));return!0}catch{return!1}},
query(url){try{window.dispatchEvent(new CustomEvent(SELECT_QUERY_EVENT,{detail:{url}}))}catch{}}
};
/* The dedicated player window: everything goes through the tab that opened it. */
const openerSelectBridge={
post(message){try{const opener=window.opener;if(!opener||opener.closed)return!1;opener.postMessage(Object.assign({channel:"download"},message),location.origin);return!0}catch{return!1}},
toggle(target){return this.post({type:PLAYER_SELECT_TOGGLE_MESSAGE,url:target.url,thumb:target.thumb||"",title:target.title||""})},
query(url){this.post({type:PLAYER_SELECT_QUERY_MESSAGE,url})}
};
function paintPlayerSelect(button,selected){
button.dataset.checked=selected?"1":"0";button.setAttribute("aria-checked",selected?"true":"false");
button.title=selected?"Bỏ chọn video này":"Chọn video này";button.setAttribute("aria-label",button.title);
button.style.setProperty("background",selected?"linear-gradient(135deg,#a855f7,#22d3ee)":"rgba(0,0,0,.55)","important");
button.style.setProperty("border-color",selected?"rgba(255,255,255,.9)":"rgba(255,255,255,.75)","important");
const mark=button.querySelector("svg");if(mark)mark.style.opacity=selected?"1":"0"
}
/* getTarget() returns {url,thumb,title} of the video the host player shows right now (or null).
 * The button stays hidden until refreshPlayerSelectButtons() has seen a URL for it. */
function makePlayerSelectButton(doc,getTarget,bridge){
const button=doc.createElement("button");
button.type="button";button.className=SELECT_BUTTON_CLASS;button.setAttribute("role","checkbox");
button.style.cssText="position:absolute!important;top:8px!important;left:8px!important;width:26px!important;height:26px!important;min-width:0!important;margin:0!important;padding:0!important;box-sizing:border-box!important;border-radius:7px!important;background:rgba(0,0,0,.55)!important;border:1.5px solid rgba(255,255,255,.75)!important;display:none!important;align-items:center!important;justify-content:center!important;cursor:pointer!important;z-index:2147483645!important;transition:transform .12s ease,background .15s ease,border-color .15s ease!important;pointer-events:auto!important";
button.innerHTML='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" style="opacity:0;transition:opacity .1s ease;pointer-events:none"><path d="M20 6 9 17l-5-5"/></svg>';
button.addEventListener("mouseenter",()=>{button.style.transform="scale(1.08)"});
button.addEventListener("mouseleave",()=>{button.style.transform="scale(1)"});
for(const type of["pointerdown","mousedown","touchstart"])button.addEventListener(type,event=>event.stopPropagation(),!0);
button.addEventListener("click",event=>{
event.preventDefault();event.stopPropagation();
let target=null;try{target=getTarget()}catch{}
if(!target||!target.url)return;
if(!bridge.toggle(target)){
button.title="Không tìm thấy tab tìm kiếm để chọn video";button.style.setProperty("border-color","#ef4444","important");
setTimeout(()=>{if(button.isConnected)paintPlayerSelect(button,button.dataset.checked==="1")},1800)
}
},!0);
playerSelectEntries.add({button,getTarget,bridge,url:""});
paintPlayerSelect(button,!1);
return button
}
/* Re-reads which video every player shows and asks multi-select.js whether it is ticked.  Called
 * whenever a player is built or switches video; entries whose window / overlay is gone are dropped. */
function refreshPlayerSelectButtons(){
for(const entry of Array.from(playerSelectEntries)){
let alive=!1;try{const view=entry.button.ownerDocument.defaultView;alive=!!(entry.button.isConnected&&view&&!view.closed)}catch{}
if(!alive){playerSelectEntries.delete(entry);continue}
let target=null;try{target=entry.getTarget()}catch{}
entry.url=target&&target.url||"";
entry.button.style.setProperty("display",entry.url?"flex":"none","important");
paintPlayerSelect(entry.button,!!entry.url&&selectionByUrl.get(entry.url)===!0);
if(entry.url)entry.bridge.query(entry.url)
}
}
function applySelectionState(url,selected){
if(!url)return;
selectionByUrl.set(url,selected);
for(const entry of playerSelectEntries)if(entry.url===url)paintPlayerSelect(entry.button,selected)
}
/* Tab that owns the selection: tell every player popup it opened about each change. */
function forwardSelectionToPlayerPopups(url,selected){
for(const popup of Array.from(selectSubscribers)){
try{if(!popup||popup.closed){selectSubscribers.delete(popup);continue}popup.postMessage({channel:"download",type:PLAYER_SELECT_STATE_MESSAGE,url,selected},location.origin)}catch{selectSubscribers.delete(popup)}
}
}
window.addEventListener(SELECT_STATE_EVENT,event=>{
const detail=event&&event.detail;if(!detail||typeof detail.url!=="string")return;
const selected=detail.selected===!0;applySelectionState(detail.url,selected);forwardSelectionToPlayerPopups(detail.url,selected)
});
window.addEventListener("message",event=>{
if(event.origin!==location.origin||!event.data||event.data.channel!=="download")return;
const message=event.data;
if(message.type===PLAYER_SELECT_STATE_MESSAGE){
/* In the popup window: state pushed by the tab that opened it. */
if(!isDedicatedPlayerWindow()||!window.opener||event.source!==window.opener||typeof message.url!=="string")return;
applySelectionState(message.url,message.selected===!0);return
}
if(message.type!==PLAYER_SELECT_TOGGLE_MESSAGE&&message.type!==PLAYER_SELECT_QUERY_MESSAGE)return;
/* In the search tab: a request from a player popup. */
if(isDedicatedPlayerWindow()||!event.source||event.source===window)return;
const url=videoUrl(message.url);if(!url)return;
selectSubscribers.add(event.source);
if(message.type===PLAYER_SELECT_TOGGLE_MESSAGE){const meta=selectMeta(message.thumb,message.title);localSelectBridge.toggle({url,thumb:meta.thumb,title:meta.title})}else localSelectBridge.query(url)
});
/* ===== [/Download] Player select button ===== */
function makeButton(action){
const btn=document.createElement("button");
const isPlayer=action==="player",isDownload=action==="download",isSpeed=action==="speed",label=isPlayer?"Mở video trên cửa sổ riêng":isDownload?"Tải xuống":isSpeed?"Playback speed":"Trình phát nổi",position=isPlayer?"top:46px!important;":isDownload?"top:84px!important;":isSpeed?"top:122px!important;":"top:8px!important;";
btn.type="button";btn.className=isPlayer?PLAYER_BUTTON_CLASS:isDownload?DOWNLOAD_BUTTON_CLASS:isSpeed?SPEED_BUTTON_CLASS:PIP_BUTTON_CLASS;btn.dataset.downloadAction=action;btn.title=label;btn.setAttribute("aria-label",label);
btn.style.cssText="position:absolute!important;"+position+"right:8px!important;width:32px!important;height:32px!important;padding:0!important;border:1px solid rgba(255,255,255,.42)!important;border-radius:50%!important;background:rgba(0,0,0,.62)!important;color:#fff!important;display:flex!important;align-items:center!important;justify-content:center!important;cursor:pointer!important;z-index:2147483645!important;box-shadow:0 2px 10px rgba(0,0,0,.42)!important;transition:transform .15s ease,background .15s ease!important;pointer-events:auto!important";
btn.innerHTML=isPlayer?playerIcon():isDownload?downloadIcon():isSpeed?'<span style="font:700 10px/1 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif">1×</span>':icon();
btn.addEventListener("mouseenter",()=>{if(!btn.dataset.downloadPipState)btn.style.transform="scale(1.08)"});
btn.addEventListener("mouseleave",()=>{btn.style.transform="scale(1)"});
return btn
}
function stopCardEvent(event){event.preventDefault();event.stopPropagation();event.stopImmediatePropagation()}
function formatSpeed(speed){return String(speed).replace(/\.0$/,"")+"×"}
/* Generic mouse-wheel "nudge a numeric value" helper, reused by every volume/speed/concurrency control below. preventDefault so the page behind the control does not scroll while the value is being adjusted. */
function wheelStepValue(current,step,min,max,deltaY){
/* Snap onto the grid anchored at `min` (the same grid a native <input type=range min max step>
 * element itself uses), not a grid anchored at 0. When min isn't itself a multiple of step
 * (e.g. min=.25, step=.1 → valid values are .25,.35,...,1.95,2.05,...) the old "round to the
 * nearest multiple of step from zero" logic produced values like 1.9 that don't exist on the
 * slider's real step grid; floating-point error in that rounding could also push the result to
 * the wrong neighboring tenth depending on direction, which is what made the value appear to
 * get stuck when decreasing. Doing the math in integers (scaled) avoids the float drift too. */
const SCALE=1e3,toInt=n=>Math.round(n*SCALE),stepI=toInt(step),minI=toInt(min),maxI=toInt(max),nextI=toInt(current)+(deltaY<0?stepI:-stepI),clampedI=Math.max(minI,Math.min(maxI,nextI)),stepsFromMin=Math.round((clampedI-minI)/stepI),snappedI=Math.max(minI,Math.min(maxI,minI+stepsFromMin*stepI));
return snappedI/SCALE
}
function bindWheelStep(el,step,min,max,getValue,onChange){
el.addEventListener("wheel",event=>{
const current=getValue();if(!Number.isFinite(current))return;
event.preventDefault();event.stopPropagation();
onChange(wheelStepValue(current,step,min,max,event.deltaY))
},{passive:!1})
}
function renderSpeedButton(btn){
if(!btn||!btn.isConnected)return;
const speed=searchPlaybackSpeed||1,label="Playback speed: "+formatSpeed(speed);
btn.title=label;btn.setAttribute("aria-label",label);btn.innerHTML='<span style="font:700 10px/1 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif">'+formatSpeed(speed)+"</span>"
}
function forceSearchSpeed(video){
if(!video||!isSearchPage()||video.__downloadSearchSpeedApplying)return;
if(isDocumentPipVideo(video)&&documentPipPlaybackSpeed!==null){
if(Math.abs(video.playbackRate-documentPipPlaybackSpeed)<.01)return;
try{video.__downloadSearchSpeedApplying=!0;video.playbackRate=documentPipPlaybackSpeed}catch{}finally{video.__downloadSearchSpeedApplying=!1}return
}
if(searchPlaybackSpeed===null)return;
if(Math.abs(video.playbackRate-searchPlaybackSpeed)<.01)return;
try{video.__downloadSearchSpeedApplying=!0;video.playbackRate=searchPlaybackSpeed}catch{}finally{video.__downloadSearchSpeedApplying=!1}
}
function isDocumentPipVideo(video){
const pipWindow=activeDocumentPipWindow();try{return!!(video&&pipWindow&&pipWindow.document.querySelector("#"+DOCUMENT_PIP_HOST_ID+" video")===video)}catch{return!1}
}
function setDocumentPipSpeed(video,speed){
const value=Math.max(.25,Math.min(3,Number(speed)||1));documentPipPlaybackSpeed=value;
try{sessionStorage.setItem(PIP_SPEED_STORAGE_KEY,String(value))}catch{}
try{video.__downloadSearchSpeedApplying=!0;video.playbackRate=value}catch{}finally{try{video.__downloadSearchSpeedApplying=!1}catch{}}
}
function bindSearchSpeed(video){
if(!video||video.__downloadSearchSpeedBound)return;
video.__downloadSearchSpeedBound=!0;
video.addEventListener("ratechange",()=>forceSearchSpeed(video),!0);
video.addEventListener("loadedmetadata",()=>forceSearchSpeed(video),!0);
video.addEventListener("playing",()=>forceSearchSpeed(video),!0);
forceSearchSpeed(video)
}
function applySearchSpeed(root=document){
if(searchPlaybackSpeed===null||!isSearchPage())return;
if(root&&root.nodeType===1&&root.matches("video"))bindSearchSpeed(root);
const scope=root&&typeof root.querySelectorAll==="function"?root:document;
scope.querySelectorAll("video").forEach(bindSearchSpeed);
/* The Document PiP video lives in a different document, so it is not part of
 * document.querySelectorAll("video") above.  Apply the same tab speed to it. */
const pipWindow=activeDocumentPipWindow();
try{const pipVideo=pipWindow&&pipWindow.document.querySelector("#"+DOCUMENT_PIP_HOST_ID+" video");if(pipVideo){bindSearchSpeed(pipVideo);setDocumentPipSpeed(pipVideo,searchPlaybackSpeed)}}catch{}
}
function syncSearchSpeed(){
if(searchPlaybackSpeed===null||!isSearchPage())return;
try{syncingSearchSpeed=!0;window.dispatchEvent(new CustomEvent("__download_settings__",{detail:{playbackSpeed:searchPlaybackSpeed}}))}catch{}finally{syncingSearchSpeed=!1}
applySearchSpeed()
}
function closeSpeedMenus(){document.querySelectorAll("."+SPEED_MENU_CLASS).forEach(menu=>{menu.__downloadClose&&menu.__downloadClose();menu.remove()})}
function chooseSpeed(speed,keepMenuOpen){
searchPlaybackSpeed=speed;
try{sessionStorage.setItem(SPEED_STORAGE_KEY,String(speed))}catch{}
if(isDedicatedPlayerWindow())try{window.opener&&window.opener.postMessage({channel:"download",type:PLAYER_SPEED_MESSAGE,speed},location.origin)}catch{}
document.querySelectorAll("."+SPEED_BUTTON_CLASS).forEach(renderSpeedButton);
syncSearchSpeed();if(!keepMenuOpen)closeSpeedMenus()
}
window.addEventListener("message",event=>{
if(event.origin!==location.origin||!event.data||event.data.channel!=="download"||event.data.type!==PLAYER_SPEED_MESSAGE)return;
const speed=Number(event.data.speed);if(Number.isFinite(speed)&&speed>=.25&&speed<=3)playerPopupSpeed=speed
},!0);
function openSpeedMenu(btn){
const existing=document.querySelector("."+SPEED_MENU_CLASS);if(existing){closeSpeedMenus();return}
const rect=btn.getBoundingClientRect(),menu=document.createElement("div");
menu.className=SPEED_MENU_CLASS;menu.setAttribute("role","menu");menu.style.cssText="position:fixed!important;z-index:2147483646!important;width:176px!important;padding:10px 12px 12px!important;border:1px solid rgba(255,255,255,.22)!important;border-radius:10px!important;background:rgba(20,20,24,.96)!important;box-shadow:0 8px 24px rgba(0,0,0,.5)!important;display:flex!important;flex-direction:column!important;gap:6px!important;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif!important";
const labelRow=document.createElement("div");labelRow.style.cssText="display:flex!important;align-items:center!important;justify-content:space-between!important;font:600 11px/1 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif!important";
const labelText=document.createElement("span");labelText.textContent="Playback speed";labelText.style.cssText="color:#fff!important;opacity:.7!important";
const valueText=document.createElement("span");valueText.style.cssText="color:#2fe4f8!important;font-weight:700!important";valueText.textContent=formatSpeed(searchPlaybackSpeed||1);
labelRow.append(labelText,valueText);
const slider=document.createElement("input");slider.type="range";slider.min=String(SPEED_MIN);slider.max=String(SPEED_MAX);slider.step=".05";slider.value=String(searchPlaybackSpeed||1);slider.title="Playback speed";slider.setAttribute("aria-label","Playback speed");slider.style.cssText="width:100%!important;margin:2px 0 0!important;accent-color:#2fe4f8!important;cursor:pointer!important";
/* stopPropagation only — never preventDefault — on the slider itself.
 * Dragging a native range thumb is a default browser action tied to
 * pointer/mouse events actually reaching this element; preventDefault()
 * here (or stopping propagation any higher up, before the event even
 * reaches this element) would suppress that native drag. This mirrors the
 * download-list panel fix: an ancestor's capturing listener must never
 * run interference before the interactive element itself gets the event. */
for(const type of["pointerdown","mousedown","touchstart","click"])slider.addEventListener(type,event=>event.stopPropagation());
slider.addEventListener("input",()=>{const value=Number(slider.value);if(!Number.isFinite(value))return;valueText.textContent=formatSpeed(value);chooseSpeed(value,!0)});
bindWheelStep(slider,.1,SPEED_MIN,SPEED_MAX,()=>Number(slider.value)||1,value=>{slider.value=String(value);valueText.textContent=formatSpeed(value);chooseSpeed(value,!0)});
menu.append(labelRow,slider);
document.body.appendChild(menu);const top=Math.min(innerHeight-menu.offsetHeight-8,Math.max(8,rect.bottom+6)),left=Math.max(8,Math.min(innerWidth-menu.offsetWidth-8,rect.right-menu.offsetWidth));menu.style.top=Math.round(top)+"px";menu.style.left=Math.round(left)+"px";
const dismiss=event=>{if(!menu.contains(event.target)&&!btn.contains(event.target))closeSpeedMenus()};const onScroll=()=>closeSpeedMenus();menu.__downloadClose=()=>{document.removeEventListener("pointerdown",dismiss,!0);window.removeEventListener("scroll",onScroll,!0);window.removeEventListener("resize",onScroll)};document.addEventListener("pointerdown",dismiss,!0);window.addEventListener("scroll",onScroll,!0);window.addEventListener("resize",onScroll)
}
window.addEventListener("__download_settings__",event=>{
const incoming=Number(event.detail&&event.detail.playbackSpeed);if(Math.abs(incoming-searchPlaybackSpeed)<.01)return;
if(Number.isFinite(incoming)&&incoming>0&&!syncingSearchSpeed)basePlaybackSpeed=incoming;
if(searchPlaybackSpeed===null||!isSearchPage())return;
queueMicrotask(()=>{if(searchPlaybackSpeed!==null&&isSearchPage())syncSearchSpeed()})
},!0);

function getVideoIn(host){
if(!host)return null;
const videos=Array.from(host.querySelectorAll("video")).filter(video=>video.isConnected);
return videos.sort((a,b)=>(b.paused?0:1e6)+(b.readyState>=1?1e5:0)-(a.paused?0:1e6)-(a.readyState>=1?1e5:0))[0]||null
}
function findVideoHost(video){
let host=video.parentElement,hops=0;
while(host&&hops++<8){if(hasCardSize(host))return host;host=host.parentElement}
return null
}
function attach(host,getVideo,getUrl){
if(!host||!hasCardSize(host))return;
try{if(getComputedStyle(host).position==="static")host.style.setProperty("position","relative","important")}catch{}
let pipButton=host.querySelector("."+PIP_BUTTON_CLASS);
if(pipSupported&&!pipButton){
pipButton=makeButton("pip");
for(const type of["pointerdown","mousedown","touchstart"])pipButton.addEventListener(type,stopCardEvent,!0);
pipButton.addEventListener("click",event=>{stopCardEvent(event);openPiP(pipButton)},!0);
pipButton.addEventListener("mouseenter",()=>prepare(pipButton));
pipButton.addEventListener("focus",()=>prepare(pipButton));
host.appendChild(pipButton)
}
if(pipButton){pipButton.__downloadGetVideo=getVideo;pipButton.__downloadGetUrl=getUrl}
let playerButton=host.querySelector("."+PLAYER_BUTTON_CLASS);
if(!playerButton){
playerButton=makeButton("player");
for(const type of["pointerdown","mousedown","touchstart"])playerButton.addEventListener(type,stopCardEvent,!0);
playerButton.addEventListener("click",event=>{stopCardEvent(event);openVideoPlayer(playerButton)},!0);
host.appendChild(playerButton)
}
playerButton.__downloadGetUrl=getUrl;
let downloadButton=host.querySelector("."+DOWNLOAD_BUTTON_CLASS);
if(!downloadButton){
downloadButton=makeButton("download");
for(const type of["pointerdown","mousedown","touchstart"])downloadButton.addEventListener(type,stopCardEvent,!0);
downloadButton.addEventListener("click",event=>{stopCardEvent(event);downloadVideo(downloadButton)},!0);
host.appendChild(downloadButton)
}
downloadButton.__downloadGetUrl=getUrl
let speedButton=host.querySelector("."+SPEED_BUTTON_CLASS);
if(!speedButton){
speedButton=makeButton("speed");
speedButton.addEventListener("pointerdown",event=>{stopCardEvent(event);speedButton.__downloadSpeedOpenedByPointer=!0;openSpeedMenu(speedButton)},!0);
for(const type of["mousedown","touchstart"])speedButton.addEventListener(type,stopCardEvent,!0);
speedButton.addEventListener("click",event=>{stopCardEvent(event);if(speedButton.__downloadSpeedOpenedByPointer){speedButton.__downloadSpeedOpenedByPointer=!1;return}openSpeedMenu(speedButton)},!0);
bindWheelStep(speedButton,.1,SPEED_MIN,SPEED_MAX,()=>searchPlaybackSpeed||1,value=>chooseSpeed(value));
host.appendChild(speedButton)
}
renderSpeedButton(speedButton)
let cardUrl="";try{cardUrl=typeof getUrl==="function"&&getUrl()||""}catch{}
restoreCardActionState(pipButton,cardUrl,pipActivatedUrls,"Đã xem");
restoreCardActionState(playerButton,cardUrl,playerActivatedUrls,"Đã xem");
restoreCardActionState(downloadButton,cardUrl,downloadActivatedUrls,"Đã tải")
}
function attachForLink(link){
if(!isThumbnailLink(link))return;
attach(link,()=>getVideoIn(link),()=>videoUrl(link.href))
}
function attachForVideo(video){
if(!video)return;
bindSearchSpeed(video);
if(!hasCardSize(video))return;
const link=video.closest("a[href*='/video/']");
if(link&&hasCardSize(link)){attach(link,()=>getVideoIn(link),()=>videoUrl(link.href));return}
const host=findVideoHost(video);host&&attach(host,()=>getVideoIn(host)||video,()=>{
const cardLink=host.closest("a[href*='/video/']")||host.querySelector("a[href*='/video/']");return cardLink?videoUrl(cardLink.href):""
})
}

function scanRoot(root){
if(!isSearchPage()||isDedicatedPlayerWindow()||!root)return;
if(root===document){document.querySelectorAll("a[href*='/video/']").forEach(attachForLink);document.querySelectorAll("video").forEach(attachForVideo);return}
if(root.nodeType!==1)return;
const element=root;
if(element.matches("a[href*='/video/']"))attachForLink(element);
if(element.matches("video"))attachForVideo(element);
const parentLink=element.closest("a[href*='/video/']");parentLink&&attachForLink(parentLink);
element.querySelectorAll("a[href*='/video/']").forEach(attachForLink);
element.querySelectorAll("video").forEach(attachForVideo)
}
function flushScan(){scanScheduled=!1;const nodes=Array.from(queuedNodes);queuedNodes.clear();nodes.forEach(scanRoot)}
function queueScan(node){if(node)queuedNodes.add(node);if(!scanScheduled){scanScheduled=!0;requestAnimationFrame(flushScan)}}
function scanAll(){queueScan(document)}

function waitForMetadata(video,timeout=1500){
if(video.readyState>=HTMLMediaElement.HAVE_METADATA)return Promise.resolve(!0);
return new Promise(resolve=>{let done=!1;const finish=value=>{if(done)return;done=!0;video.removeEventListener("loadedmetadata",ready);video.removeEventListener("error",failed);resolve(value)},ready=()=>finish(!0),failed=()=>finish(!1);video.addEventListener("loadedmetadata",ready,{once:!0});video.addEventListener("error",failed,{once:!0});setTimeout(()=>finish(video.readyState>=HTMLMediaElement.HAVE_METADATA),timeout)})
}
async function enterPiP(video,waitForReady){
if(!video||!video.isConnected)return!1;
try{
T(video);
if(document.pictureInPictureElement===video){await document.exitPictureInPicture();return!0}
if(document.pictureInPictureElement)await document.exitPictureInPicture();
if(video.readyState<HTMLMediaElement.HAVE_METADATA){try{video.play().catch(()=>{})}catch{}if(!waitForReady||!await waitForMetadata(video))return!1}
try{await video.requestPictureInPicture();return!0}catch{
try{await video.play()}catch{}
try{await video.requestPictureInPicture();return!0}catch{return!1}
}
}catch{return!1}
}

/* Search cards use Document Picture-in-Picture when Chrome supports it.  This
 * window contains our own transparent controls, so Chrome's dark native PiP
 * hover overlay is never drawn over the video. */
const DOCUMENT_PIP_HOST_ID="__download_document_pip_player";
function activeDocumentPipWindow(){
const candidate=documentPipWindow||(window.documentPictureInPicture&&window.documentPictureInPicture.window);
try{return candidate&&!candidate.closed&&candidate.__downloadDocumentPip===!0?candidate:null}catch{return null}
}
function hideWarmVideo(video){
if(!video)return;try{video.pause()}catch{}
try{if(video.ownerDocument!==document||!video.isConnected)(document.body||document.documentElement).appendChild(video)}catch{}
video.style.cssText="position:fixed!important;left:-10000px!important;top:-10000px!important;width:1px!important;height:1px!important;opacity:0!important;pointer-events:none!important"
}
function makeDocumentPipButton(doc,label,title){
const button=doc.createElement("button");button.type="button";button.textContent=label;button.title=title;button.setAttribute("aria-label",title);
button.style.cssText="width:32px;height:30px;padding:0;border:0;border-radius:7px;background:transparent;color:#fff;font:700 15px/1 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;cursor:pointer;text-shadow:0 1px 3px #000";
button.addEventListener("mouseenter",()=>button.style.background="rgba(255,255,255,.16)");button.addEventListener("mouseleave",()=>button.style.background="transparent");return button
}
function buildDocumentPipPlayer(pipWindow,video){
if(video.__downloadPipHandlers){const _h=video.__downloadPipHandlers;video.removeEventListener("click",_h.togglePlay);video.removeEventListener("play",_h.updatePlay);video.removeEventListener("pause",_h.updatePlay);video.removeEventListener("volumechange",_h.updateMute);video.removeEventListener("ratechange",_h.updateSpeed);video.removeEventListener("durationchange",_h.updateTimeline);video.removeEventListener("loadedmetadata",_h.updateTimeline);video.removeEventListener("timeupdate",_h.updateTimeline);video.__downloadPipHandlers=null}
const doc=pipWindow.document,host=doc.createElement("div"),controls=doc.createElement("div"),play=makeDocumentPipButton(doc,"▶","Play"),progress=doc.createElement("input"),time=doc.createElement("span"),mute=makeDocumentPipButton(doc,"🔊","Mute"),speed=doc.createElement("span"),speedPopup=doc.createElement("div"),speedSlider=doc.createElement("input"),close=makeDocumentPipButton(doc,"×","Close Picture-in-Picture");
doc.title="Download";doc.head.replaceChildren();doc.body.replaceChildren();
const style=doc.createElement("style");style.textContent="html,body{width:100%;height:100%;margin:0;overflow:hidden;background:#000}#"+DOCUMENT_PIP_HOST_ID+"{position:fixed;inset:0;background:#000;overflow:hidden}#"+DOCUMENT_PIP_HOST_ID+" video{display:block;width:100%;height:100%;background:#000;object-fit:contain}.download-pip-controls{position:absolute;left:8px;right:8px;bottom:8px;display:flex;align-items:center;gap:8px;min-height:32px;padding:0;background:transparent;opacity:0;pointer-events:none;transition:opacity .16s ease}.download-pip-controls.is-visible{opacity:1;pointer-events:auto}.download-pip-progress{flex:1;min-width:36px;margin:0;accent-color:#2fe4f8;cursor:pointer}.download-pip-time{min-width:64px;color:#fff;font:500 11px/1 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;text-shadow:0 1px 3px #000;font-variant-numeric:tabular-nums;text-align:right;white-space:nowrap}.download-pip-speed{margin-left:auto;min-width:32px;padding:4px 6px;border-radius:6px;color:#fff;font:700 12px/1 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;text-align:right;text-shadow:0 1px 3px #000;cursor:pointer;user-select:none}.download-pip-speed:hover,.download-pip-speed.is-open{background:rgba(255,255,255,.16)}.download-pip-speed-popup{position:absolute;right:8px;bottom:40px;display:none;align-items:center;gap:8px;padding:8px 10px;border-radius:9px;background:rgba(20,20,24,.96);box-shadow:0 8px 24px rgba(0,0,0,.5);pointer-events:auto}.download-pip-speed-popup.is-visible{display:flex}.download-pip-speed-popup input[type=range]{width:120px;accent-color:#2fe4f8;cursor:pointer}";doc.head.appendChild(style);
style.textContent+=".download-pip-controls{flex-wrap:wrap;gap:4px 6px}";
host.id=DOCUMENT_PIP_HOST_ID;controls.className="download-pip-controls";controls.setAttribute("aria-label","Picture-in-Picture controls");
speed.className="download-pip-speed";speed.tabIndex=0;speed.setAttribute("role","button");speed.title="Playback speed (scroll to adjust)";speed.setAttribute("aria-label","Playback speed");
speedSlider.type="range";speedSlider.min=".25";speedSlider.max="3";speedSlider.step=".1";speedSlider.title="Playback speed";speedSlider.setAttribute("aria-label","Playback speed");
speedPopup.className="download-pip-speed-popup";speedPopup.appendChild(speedSlider);
progress.type="range";progress.min="0";progress.max="0";progress.step=".01";progress.value="0";progress.className="download-pip-progress";progress.title="Seek";progress.setAttribute("aria-label","Seek");
time.className="download-pip-time";
controls.append(play,progress,time,mute,speed,close);
const selectButton=makePlayerSelectButton(doc,()=>{const url=video.__downloadSearchPipUrl;if(!url)return null;const data=streamCache.get(url)||{};return{url,thumb:data.coverUrl,title:data.title}},localSelectBridge);
host.append(video,controls,speedPopup,selectButton);doc.body.appendChild(host);
video.controls=!1;video.playsInline=!0;video.style.cssText="display:block!important;width:100%!important;height:100%!important;background:#000!important;object-fit:contain!important;cursor:pointer!important";
const updatePlay=()=>{play.textContent=video.paused?"▶":"❚❚";play.title=video.paused?"Play":"Pause";play.setAttribute("aria-label",play.title)},updateMute=()=>{mute.textContent=video.muted||video.volume===0?"🔇":"🔊";mute.title=video.muted?"Unmute":"Mute";mute.setAttribute("aria-label",mute.title)},updateSpeed=()=>{const current=Math.max(.25,Math.min(3,Number(video.playbackRate)||1));speed.textContent=formatSpeed(current);if(!speedSlider.matches(":active"))speedSlider.value=String(current)},updateTimeline=()=>{const duration=Number.isFinite(video.duration)?video.duration:0;progress.max=String(duration);if(!progress.matches(":active"))progress.value=String(Math.min(duration,video.currentTime||0));time.textContent=formatPlayerTime(video.currentTime)+" / "+formatPlayerTime(duration)};
const togglePlay=()=>{video.paused?video.play().catch(()=>{}):video.pause()};play.addEventListener("click",togglePlay);video.addEventListener("click",togglePlay);mute.addEventListener("click",()=>{video.muted=!video.muted});close.addEventListener("click",()=>pipWindow.close());
progress.addEventListener("input",()=>{const value=Number(progress.value);if(Number.isFinite(value))video.currentTime=value});
for(const type of["pointerdown","mousedown","touchstart","click"])progress.addEventListener(type,event=>event.stopPropagation());
/* Click the "2×" badge to open a small popup slider (max 3×); scroll the
 * badge itself, or the slider, to nudge speed by 0.1 per wheel notch. */
const closeSpeedPopup=()=>{speedPopup.classList.remove("is-visible");speed.classList.remove("is-open")};
const openSpeedPopup=()=>{speedSlider.value=String(Math.max(.25,Math.min(3,Number(video.playbackRate)||1)));speedPopup.classList.add("is-visible");speed.classList.add("is-open")};
speed.addEventListener("click",event=>{event.preventDefault();event.stopPropagation();speedPopup.classList.contains("is-visible")?closeSpeedPopup():openSpeedPopup()});
speed.addEventListener("keydown",event=>{if(event.key==="Enter"||event.key===" "){event.preventDefault();event.stopPropagation();speedPopup.classList.contains("is-visible")?closeSpeedPopup():openSpeedPopup()}});
bindWheelStep(speed,.1,.25,3,()=>Number(video.playbackRate)||1,value=>{setDocumentPipSpeed(video,value);updateSpeed()});
for(const type of["pointerdown","mousedown","touchstart","click"])speedSlider.addEventListener(type,event=>event.stopPropagation());
speedSlider.addEventListener("input",()=>{const value=Number(speedSlider.value);if(!Number.isFinite(value))return;setDocumentPipSpeed(video,value);updateSpeed()});
bindWheelStep(speedSlider,.1,.25,3,()=>Number(speedSlider.value)||1,value=>{speedSlider.value=String(value);setDocumentPipSpeed(video,value);updateSpeed()});
doc.addEventListener("pointerdown",event=>{if(!speedPopup.contains(event.target)&&event.target!==speed)closeSpeedPopup()},!0);
video.addEventListener("play",updatePlay);video.addEventListener("pause",updatePlay);video.addEventListener("volumechange",updateMute);video.addEventListener("ratechange",updateSpeed);video.addEventListener("durationchange",updateTimeline);video.addEventListener("loadedmetadata",updateTimeline);video.addEventListener("timeupdate",updateTimeline);
video.__downloadPipHandlers={togglePlay,updatePlay,updateMute,updateSpeed,updateTimeline};
let hideTimer=0;const showControls=()=>{clearTimeout(hideTimer);controls.classList.add("is-visible")},hideControls=()=>{clearTimeout(hideTimer);hideTimer=setTimeout(()=>{if(!controls.matches(":focus-within")&&!speedPopup.classList.contains("is-visible"))controls.classList.remove("is-visible")},180)};
host.addEventListener("pointermove",event=>{event.clientY>=pipWindow.innerHeight-68?showControls():hideControls()});host.addEventListener("pointerleave",hideControls);controls.addEventListener("pointerenter",showControls);controls.addEventListener("pointerleave",hideControls);
doc.addEventListener("keydown",event=>{
if(event.ctrlKey&&!event.altKey&&!event.metaKey&&(event.key==="ArrowRight"||event.key==="ArrowLeft")){
event.preventDefault();event.stopPropagation();
const current=Number(video.playbackRate)||documentPipPlaybackSpeed||searchPlaybackSpeed||1,next=wheelStepValue(current,.1,.25,3,event.key==="ArrowRight"?-1:1);
setDocumentPipSpeed(video,next);return
}
if(event.code!=="Space"||event.ctrlKey||event.altKey||event.metaKey)return;
const tag=event.target&&event.target.tagName;if(tag==="BUTTON"||tag==="INPUT")return;event.preventDefault();event.stopPropagation();togglePlay()
});
updatePlay();updateMute();updateSpeed();updateTimeline();return host
}
function handleDocumentPipClosed(pipWindow){
let video=null;try{video=pipWindow.document.querySelector("video")}catch{}if(video===warmVideo)hideWarmVideo(video);if(documentPipWindow===pipWindow)documentPipWindow=null;
broadcastPipClosed(video&&video.__downloadSearchPipUrl)
}
/* Tells the multi-select popup's "Đang xem" indicator (assets/multi-select.js,
 * ISOLATED world) that the PiP video for this URL is no longer showing —
 * covers every way it can close (native close button on the PiP window,
 * navigating it away, the user's own "leavepictureinpicture"), not just the
 * toggle-off click path that already replies through the request/response
 * bridge above. Harmless no-op there if this URL isn't the one it's tracking. */
function broadcastPipClosed(url){
if(!url)return;
try{window.dispatchEvent(new CustomEvent("__DOWNLOAD_MULTISELECT_PIP_CLOSED__",{detail:{url}}))}catch{}
}
function pipWindowShape(pipWindow){
try{const video=pipWindow.document.querySelector("video");return video&&video.videoWidth&&video.videoHeight?playerShape(video.videoWidth,video.videoHeight):null}catch{return null}
}
/* Size the PiP window for the video it just got.  Same shape as the previous video in this window ->
 * keep whatever size the user gave it.  New window or a different shape (9:16 <-> 16:9) -> the size
 * the user last gave that shape, else an automatic fit.  Position: best effort, Chrome may ignore moveTo(). */
function fitDocumentPipWindow(pipWindow,video){
try{
if(!pipWindow||pipWindow.closed)return;
const vw=video.videoWidth,vh=video.videoHeight;
if(!vw||!vh)return;
const shape=playerShape(vw,vh),previous=pipWindow.__downloadPipShape,fresh=!pipWindow.__downloadPipPlaced;
pipWindow.__downloadPipShape=shape;pipWindow.__downloadPipPlaced=!0;
trackPlayerBounds(pipWindow,"pip",()=>pipWindowShape(pipWindow));
if(previous===shape)return;
const scr=pipWindow.screen||window.screen||{},screenW=scr.availWidth||1280,screenH=scr.availHeight||800;
let size=savedPlayerSize("pip",shape);
if(!size){
const baseArea=400*680;let w=Math.sqrt(baseArea*(vw/vh)),h=w*(vh/vw);
const maxW=Math.min(screenW-40,720),maxH=Math.min(screenH-40,720);
if(w>maxW){w=maxW;h=w*(vh/vw)}
if(h>maxH){h=maxH;w=h*(vw/vh)}
size={w:Math.max(220,Math.round(w)),h:Math.max(160,Math.round(h))}
}
applyPlayerInnerSize(pipWindow,Math.min(size.w,screenW-24),Math.min(size.h,screenH-24));
if(fresh){
const rec=savedPlayerBounds("pip");
if(Number.isFinite(rec.x)&&Number.isFinite(rec.y))pipWindow.setTimeout(()=>{try{pipWindow.moveTo(Math.round(rec.x),Math.round(rec.y))}catch{}},450)
}
}catch{}
}
async function openDocumentPiP(url,data,windowRequest){
let pipWindow=activeDocumentPipWindow();
if(!pipWindow){
if(document.pictureInPictureElement)try{await document.exitPictureInPicture()}catch{}
pipWindow=await(windowRequest||window.documentPictureInPicture.requestWindow(pipWindowOptions()));pipWindow.__downloadDocumentPip=!0;documentPipWindow=pipWindow;
pipWindow.addEventListener("pagehide",()=>handleDocumentPipClosed(pipWindow),{once:!0})
}
const video=warm(url,data);let host=null;try{host=pipWindow.document.getElementById(DOCUMENT_PIP_HOST_ID)}catch{}
if(!host)host=buildDocumentPipPlayer(pipWindow,video);else{const controls=host.querySelector(".download-pip-controls");if(video.parentElement!==host||video.nextSibling!==controls)host.insertBefore(video,controls||null);video.controls=!1;video.style.cssText="display:block!important;width:100%!important;height:100%!important;background:#000!important;object-fit:contain!important;cursor:pointer!important"}
refreshPlayerSelectButtons();bindSearchSpeed(video);if(!await waitForMetadata(video,2500))return!1;forceSearchSpeed(video);fitDocumentPipWindow(pipWindow,video);try{await video.play()}catch{}return!0
}

function validStream(data){
try{return!!data&&typeof data.videoUrl==="string"&&new URL(data.videoUrl).protocol==="https:"}catch{return!1}}
function streamFor(url){
if(streamCache.has(url))return Promise.resolve(streamCache.get(url));
if(streamRequests.has(url))return streamRequests.get(url);
const requestId="download-pip-"+Date.now().toString(36)+"-"+(++requestNumber)+"-"+Math.random().toString(36).slice(2,8);
const promise=new Promise((resolve,reject)=>{
const timer=setTimeout(()=>{pendingRequests.delete(requestId);reject(new Error("metadata_timeout"))},15000);
pendingRequests.set(requestId,{resolve:data=>{clearTimeout(timer);pendingRequests.delete(requestId);resolve(data)},reject:error=>{clearTimeout(timer);pendingRequests.delete(requestId);reject(error)}});
window.postMessage({channel:"download",type:REQUEST_TYPE,requestId,url},location.origin)
}).then(data=>{if(!validStream(data))throw new Error("invalid_video_stream");streamCache.set(url,data);return data}).finally(()=>streamRequests.delete(url));
streamRequests.set(url,promise);return promise
}
window.addEventListener("message",event=>{
if(event.source!==window||event.origin!==location.origin)return;
const message=event.data;
if(!message||message.channel!=="download"||typeof message.requestId!=="string")return;
if(message.type===RESPONSE_TYPE){
const pending=pendingRequests.get(message.requestId);if(!pending)return;
message.success&&validStream(message.data)?pending.resolve(message.data):pending.reject(new Error(message.error||"metadata_unavailable"));return
}
if(message.type===DOWNLOAD_RESPONSE_TYPE){
const pending=pendingDownloads.get(message.requestId);if(!pending)return;
pendingDownloads.delete(message.requestId);clearTimeout(pending.timer);message.success?pending.resolve():pending.reject(new Error(message.error||"download_unavailable"))
}
});

function requestDownload(url){
const requestId="download-download-"+Date.now().toString(36)+"-"+(++requestNumber)+"-"+Math.random().toString(36).slice(2,8);
return new Promise((resolve,reject)=>{
const timer=setTimeout(()=>{pendingDownloads.delete(requestId);reject(new Error("download_timeout"))},20000);
pendingDownloads.set(requestId,{resolve,reject,timer});
window.postMessage({channel:"download",type:DOWNLOAD_REQUEST_TYPE,requestId,url},location.origin)
})
}
async function downloadVideo(btn){
if(!btn||downloadBusy.has(btn))return;
const url=typeof btn.__downloadGetUrl==="function"&&btn.__downloadGetUrl();
if(!url){flash(btn,"No downloadable TikTok video was found");return}
downloadBusy.add(btn);setButtonState(btn,"loading","Starting download…");
try{await requestDownload(url);markCardActionActive(btn,url,downloadActivatedUrls,"Đã tải")}catch{flash(btn,"Unable to download this TikTok video")}finally{downloadBusy.delete(btn)}
}

/* TikTok's regular video route also renders its author, caption, hashtags, and
 * comments.  This overlay uses the selected card stream instead, so it shows
 * only the video and Download's compact controls.  Escape or the black margin
 * closes it. */
function closeVideoPlayer(){
const overlay=document.getElementById(PLAYER_OVERLAY_ID);if(!overlay)return;
if(overlay.__downloadPlayerKeydown)document.removeEventListener("keydown",overlay.__downloadPlayerKeydown,!0);
const video=overlay.querySelector("video");
if(video){try{video.pause();video.removeAttribute("src");video.load()}catch{}}
overlay.remove()
}
function formatPlayerTime(seconds){
if(!Number.isFinite(seconds)||seconds<0)return"0:00";
const minutes=Math.floor(seconds/60),secs=Math.floor(seconds%60);return minutes+":"+String(secs).padStart(2,"0")
}
function makePlayerControl(label,title){
const button=document.createElement("button");button.type="button";button.title=title;button.setAttribute("aria-label",title);button.textContent=label;button.style.cssText="width:34px!important;height:30px!important;padding:0!important;border:0!important;border-radius:6px!important;background:transparent!important;color:#fff!important;font:700 16px/1 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif!important;cursor:pointer!important;flex:none!important";button.addEventListener("mouseenter",()=>button.style.background="rgba(255,255,255,.16)");button.addEventListener("mouseleave",()=>button.style.background="transparent");return button
}
function bindPlayerControls(overlay,video,controls){
const play=makePlayerControl("▶","Play"),mute=makePlayerControl("🔊","Mute"),fullscreen=makePlayerControl("⛶","Fullscreen");
const progress=document.createElement("input"),volume=document.createElement("input"),speed=document.createElement("input"),time=document.createElement("span"),speedLabel=document.createElement("span");
progress.type="range";progress.min="0";progress.max="0";progress.step=".01";progress.value="0";progress.title="Seek";progress.style.cssText="min-width:70px!important;flex:1!important;accent-color:#2fe4f8!important;cursor:pointer!important";
volume.type="range";volume.min="0";volume.max="1";volume.step=".01";volume.value=String(video.volume);volume.title="Volume";volume.style.cssText="width:72px!important;accent-color:#2fe4f8!important;cursor:pointer!important";
speed.type="range";speed.min=".25";speed.max="3";speed.step=".05";speed.value=String(searchPlaybackSpeed||video.playbackRate||1);speed.title="Playback speed";speed.style.cssText="width:96px!important;accent-color:#2fe4f8!important;cursor:pointer!important";
time.style.cssText="min-width:76px!important;color:#fff!important;font:500 12px/1 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif!important;font-variant-numeric:tabular-nums!important";
speedLabel.style.cssText="min-width:36px!important;color:#fff!important;font:700 12px/1 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif!important;text-align:right!important";
const updatePlay=()=>{play.textContent=video.paused?"▶":"❚❚";play.title=video.paused?"Play":"Pause";play.setAttribute("aria-label",play.title)};
const updateTimeline=()=>{const duration=Number.isFinite(video.duration)?video.duration:0;progress.max=String(duration);if(!progress.matches(":active"))progress.value=String(Math.min(duration,video.currentTime||0));time.textContent=formatPlayerTime(video.currentTime)+" / "+formatPlayerTime(duration)};
const updateVolume=()=>{mute.textContent=video.muted||video.volume===0?"🔇":"🔊";mute.title=video.muted?"Unmute":"Mute";mute.setAttribute("aria-label",mute.title);if(!volume.matches(":active"))volume.value=String(video.muted?0:video.volume)};
const updateSpeed=()=>{const current=Math.max(.25,Math.min(3,Number(video.playbackRate)||1));if(!speed.matches(":active"))speed.value=String(current);speedLabel.textContent=formatSpeed(current)};
const togglePlay=()=>{video.paused?video.play().catch(()=>{}):video.pause()};
play.addEventListener("click",togglePlay);video.addEventListener("click",togglePlay);
mute.addEventListener("click",()=>{video.muted=!video.muted});
progress.addEventListener("input",()=>{const value=Number(progress.value);if(Number.isFinite(value))video.currentTime=value});
volume.addEventListener("input",()=>{const value=Number(volume.value);if(Number.isFinite(value)){video.muted=value===0;video.volume=value}});
bindWheelStep(volume,.1,0,1,()=>Number(volume.value)||0,value=>{volume.value=String(value);video.muted=value===0;video.volume=value});
speed.addEventListener("input",()=>{const value=Number(speed.value);if(!Number.isFinite(value))return;chooseSpeed(value);try{video.playbackRate=value}catch{}updateSpeed()});
bindWheelStep(speed,.1,.25,3,()=>Number(speed.value)||1,value=>{speed.value=String(value);chooseSpeed(value);try{video.playbackRate=value}catch{}updateSpeed()});
fullscreen.addEventListener("click",()=>{const request=overlay.requestFullscreen||overlay.webkitRequestFullscreen;if(!request)return;try{const result=request.call(overlay);result&&result.catch&&result.catch(()=>{})}catch{}});
video.addEventListener("dblclick",event=>{event.preventDefault();try{if(document.fullscreenElement){const leave=document.exitFullscreen();leave&&leave.catch&&leave.catch(()=>{})}else fullscreen.click()}catch{}});
video.addEventListener("play",updatePlay);video.addEventListener("pause",updatePlay);video.addEventListener("durationchange",updateTimeline);video.addEventListener("loadedmetadata",updateTimeline);video.addEventListener("timeupdate",updateTimeline);video.addEventListener("volumechange",updateVolume);video.addEventListener("ratechange",updateSpeed);
controls.append(play,progress,time,mute,volume,speedLabel,speed,fullscreen);updatePlay();updateTimeline();updateVolume();updateSpeed()
}
function getVideoPlayer(){
let overlay=document.getElementById(PLAYER_OVERLAY_ID);if(overlay)return overlay;
overlay=document.createElement("div");overlay.id=PLAYER_OVERLAY_ID;overlay.setAttribute("role","dialog");overlay.setAttribute("aria-label","Video player");overlay.style.cssText="position:fixed!important;inset:0!important;z-index:2147483647!important;display:flex!important;align-items:center!important;justify-content:center!important;background:#000!important;cursor:default!important";
const video=document.createElement("video");video.controls=!1;video.autoplay=!0;video.playsInline=!0;video.preload="metadata";video.style.cssText="display:block!important;width:100vw!important;height:100vh!important;max-width:100vw!important;max-height:100vh!important;background:#000!important;object-fit:contain!important;cursor:pointer!important";
const controls=document.createElement("div");controls.className=PLAYER_CONTROLS_CLASS;controls.setAttribute("aria-hidden","true");controls.style.cssText="position:absolute!important;left:12px!important;right:12px!important;bottom:12px!important;z-index:1!important;min-height:48px!important;display:flex!important;align-items:center!important;gap:9px!important;padding:9px 10px!important;border:0!important;border-radius:10px!important;background:transparent!important;box-shadow:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important;opacity:0!important;pointer-events:none!important;transition:opacity .16s ease!important";
overlay.append(video,controls);bindPlayerControls(overlay,video,controls);
overlay.appendChild(makePlayerSelectButton(document,()=>{const url=video.__downloadPlayerSource;if(!url)return null;const meta=video.__downloadPlayerMeta||{};return{url,thumb:meta.thumb,title:meta.title}},isDedicatedPlayerWindow()?openerSelectBridge:localSelectBridge));
let hideControlsTimer=0;
const showControls=()=>{clearTimeout(hideControlsTimer);controls.style.setProperty("opacity","1","important");controls.style.setProperty("pointer-events","auto","important");controls.setAttribute("aria-hidden","false")};
const hideControls=()=>{clearTimeout(hideControlsTimer);hideControlsTimer=setTimeout(()=>{if(controls.matches(":focus-within"))return;controls.style.setProperty("opacity","0","important");controls.style.setProperty("pointer-events","none","important");controls.setAttribute("aria-hidden","true")},160)};
const updateControlsVisibility=event=>{const rect=controls.getBoundingClientRect();event.clientY>=rect.top-42?showControls():hideControls()};
overlay.addEventListener("pointermove",updateControlsVisibility,!0);overlay.addEventListener("pointerleave",hideControls,!0);controls.addEventListener("pointerenter",showControls,!0);controls.addEventListener("pointerleave",hideControls,!0);controls.addEventListener("focusin",showControls,!0);controls.addEventListener("focusout",hideControls,!0);
overlay.addEventListener("pointerdown",event=>{if(event.target===overlay)closeVideoPlayer()},!0);
overlay.__downloadPlayerKeydown=event=>{
if(event.key==="Escape"){event.preventDefault();closeVideoPlayer();return}
if(event.ctrlKey&&!event.altKey&&!event.metaKey&&(event.key==="ArrowRight"||event.key==="ArrowLeft")){
event.preventDefault();event.stopPropagation();
const current=Number(video.playbackRate)||searchPlaybackSpeed||1,delta=event.key==="ArrowRight"?.1:-.1,next=Math.max(.25,Math.min(3,Math.round((current+delta)*10)/10));
chooseSpeed(next);try{video.playbackRate=next}catch{}return
}
if(event.code==="Space"&&!event.ctrlKey&&!event.altKey&&!event.metaKey){
const target=event.target,tag=target&&target.tagName;
if(tag==="BUTTON"||tag==="INPUT"||tag==="TEXTAREA"||tag==="SELECT")return;
event.preventDefault();event.stopPropagation();video.paused?video.play().catch(()=>{}):video.pause()
}
};
document.addEventListener("keydown",overlay.__downloadPlayerKeydown,!0);
(document.body||document.documentElement).appendChild(overlay);return overlay
}
function requestedPlayerUrl(){try{return videoUrl(new URL(location.href).searchParams.get(PLAYER_REQUEST_PARAM)||"")}catch{return""}}
function requestedPlayerSpeed(){try{const speed=Number(new URL(location.href).searchParams.get(PLAYER_SPEED_PARAM));return Number.isFinite(speed)&&speed>=.25&&speed<=3?speed:null}catch{return null}}
function playerWindowUrl(url,speed){const target=new URL("/search",location.origin);target.searchParams.set(PLAYER_REQUEST_PARAM,url);if(Number.isFinite(speed)&&speed>=.25&&speed<=3)target.searchParams.set(PLAYER_SPEED_PARAM,String(speed));return target.href}
function speedFromPlayerWindow(playerWindow){
try{const video=playerWindow.document.querySelector("#"+PLAYER_OVERLAY_ID+" video"),speed=Number(video&&video.playbackRate);return Number.isFinite(speed)&&speed>=.25&&speed<=3?speed:null}catch{return null}
}
/* Always-on-top variant of the player: same Document PiP window as the PiP button. requestWindow()
 * must run synchronously from the click (stream discovery is async), exactly like openPiP(). */
async function openPlayerOnTop(btn,url){
if(!btn||busy.has(btn))return;
busy.add(btn);setButtonState(btn,"loading","Preparing Picture-in-Picture…");
try{
const windowRequest=activeDocumentPipWindow()?null:window.documentPictureInPicture.requestWindow(pipWindowOptions());
const data=await streamFor(url);
if(await openDocumentPiP(url,data,windowRequest)){markCardActionActive(btn,url,playerActivatedUrls,"Đã xem");return}
flash(btn,"Unable to open the always-on-top player")
}catch{flash(btn,"Unable to open the always-on-top player")}finally{busy.delete(btn)}
}
function openVideoPlayer(btn){
if(!btn)return;
const url=typeof btn.__downloadGetUrl==="function"&&btn.__downloadGetUrl();
if(!url){flash(btn,"No playable TikTok video was found");return}
if(playerAlwaysOnTop&&documentPipSupported){openPlayerOnTop(btn,url);return}
/* A fixed window name makes window.open reuse the existing player window.
 * Navigating it directly in the click handler retains Chrome's user activation
 * far more reliably than opening a blank popup and assigning location later. */
const openPlayer=playerPopup&&!playerPopup.closed?playerPopup:null;
const speed=speedFromPlayerWindow(openPlayer)||playerPopupSpeed||searchPlaybackSpeed||1;
const playerWindow=window.open(playerWindowUrl(url,speed),PLAYER_WINDOW_NAME,playerWindowFeatures());
if(!playerWindow){flash(btn,"Allow popups to open the video player");return}
playerPopup=playerWindow;
try{playerWindow.focus()}catch{}
markCardActionActive(btn,url,playerActivatedUrls,"Đã xem")
}
async function ensurePlayerVideoPlaying(video,sourceUrl){
if(!video||!video.isConnected||video.__downloadPlayerSource!==sourceUrl)return!1;
const play=async()=>{try{const result=video.play();result&&await result;return!video.paused}catch{return!1}};
return play()
}
function playerWindowShape(){
const video=document.querySelector("#"+PLAYER_OVERLAY_ID+" video");
return video&&video.videoWidth&&video.videoHeight?playerShape(video.videoWidth,video.videoHeight):null
}
/* Popup window opened via window.open() keeps its own title-bar "chrome", so outerWidth/outerHeight !=
 * innerWidth/innerHeight; sizes below are VIEWPORT sizes (the box the <video style="width:100vw;
 * height:100vh;object-fit:contain"> renders into).  Runs once per page load, right after metadata resolves:
 *  - maximised / fullscreen window: never touched (the same window is reused for the next video);
 *  - otherwise the size the user last gave this video shape (portrait / square / landscape), else an
 *    automatic fit to the video's aspect ratio.  A window the user resized keeps that size for the next
 *    video of the same shape; the size/position/maximised state are saved while the window is open
 *    (trackPlayerBounds) and reused after the browser is restarted. */
function fitVideoPlayerWindow(video){
try{
const vw=video.videoWidth,vh=video.videoHeight;
if(!vw||!vh)return;
trackPlayerBounds(window,"win",playerWindowShape);
window.__downloadBoundsHold=Date.now()+1500;
if(playerWindowIsFilled(window))return;
const scr=window.screen||{},availW=scr.availWidth||1280,availH=scr.availHeight||800,availL=scr.availLeft||0,availT=scr.availTop||0;
if(savedPlayerBounds("win").max===!0){window.moveTo(availL,availT);window.resizeTo(availW,availH);return}
const chromeW=Math.max(0,window.outerWidth-window.innerWidth),chromeH=Math.max(0,window.outerHeight-window.innerHeight);
let size=savedPlayerSize("win",playerShape(vw,vh));
if(!size){
const maxOuterW=Math.min(availW-40,760),maxOuterH=Math.min(availH-60,900);
let h=Math.min(820,maxOuterH-chromeH),w=h*(vw/vh);
if(w>maxOuterW-chromeW){w=maxOuterW-chromeW;h=w*(vh/vw)}
size={w:Math.max(220,Math.round(w)),h:Math.max(160,Math.round(h))}
}
const tw=Math.round(Math.min(size.w,availW-chromeW)),th=Math.round(Math.min(size.h,availH-chromeH));
if(Math.abs(window.innerWidth-tw)<=3&&Math.abs(window.innerHeight-th)<=3)return;
const ow=tw+chromeW,oh=th+chromeH;
window.resizeTo(ow,oh);
let x=window.screenX,y=window.screenY;
if(x+ow>availL+availW)x=Math.max(availL,availL+availW-ow);
if(y+oh>availT+availH)y=Math.max(availT,availT+availH-oh);
if(x!==window.screenX||y!==window.screenY)window.moveTo(x,y)
}catch{}
}
async function openVideoPlayerStream(url){
try{
const data=await streamFor(url),overlay=getVideoPlayer(),video=overlay.querySelector("video");
if(!video)throw new Error("player_unavailable");
try{video.pause()}catch{}
video.__downloadPlayerSource=url;video.__downloadPlayerMeta={thumb:data.coverUrl,title:data.title};refreshPlayerSelectButtons();
/* Prefer audible playback. If Chrome rejects autoplay, leave the video
 * paused rather than silently forcing muted playback. */
try{video.muted=!1}catch{}
video.src=data.videoUrl;if(data.coverUrl)video.poster=data.coverUrl;else video.removeAttribute("poster");
try{video.playbackRate=searchPlaybackSpeed||1}catch{}
bindSearchSpeed(video);try{video.load()}catch{}
await waitForMetadata(video,3000);forceSearchSpeed(video);await playerBoundsReady(800);fitVideoPlayerWindow(video);
if(!await ensurePlayerVideoPlaying(video,url)){
const retry=()=>{ensurePlayerVideoPlaying(video,url)};
video.addEventListener("canplay",retry,{once:!0});setTimeout(retry,450)
}
return!0
}catch{closeVideoPlayer();return!1}
}
function launchRequestedPlayer(){
if(playerRequestStarted)return;
const url=requestedPlayerUrl();if(!url)return;
playerRequestStarted=!0;
const requestedSpeed=requestedPlayerSpeed();if(requestedSpeed!==null)chooseSpeed(requestedSpeed);
try{document.documentElement.style.background="#000"}catch{}
openVideoPlayerStream(url)
}
if(requestedPlayerUrl()){
try{document.documentElement.style.background="#000"}catch{}
window.addEventListener("__DOWNLOAD_PLAYER_BRIDGE_READY__",launchRequestedPlayer,{once:!0});
setTimeout(launchRequestedPlayer,2500)
}

function getWarmVideo(){
if(warmVideo)return warmVideo;
warmVideo=document.createElement("video");warmVideo.__downloadSearchPipMedia=!0;warmVideo.preload="metadata";warmVideo.playsInline=!0;warmVideo.style.cssText="position:fixed!important;left:-10000px!important;top:-10000px!important;width:1px!important;height:1px!important;opacity:0!important;pointer-events:none!important";
return warmVideo
}
function mountWarmVideo(video){
if(video.ownerDocument!==document||!video.isConnected)(document.body||document.documentElement).appendChild(video);
return video
}
function warm(url,data){
const video=getWarmVideo();
if(video.__downloadSearchPipUrl===url)return video;
video.pause();video.__downloadSearchPipUrl=url;video.src=data.videoUrl;if(data.coverUrl)video.poster=data.coverUrl;try{video.load()}catch{}return video
}
async function switchWarmPiP(video,url,data){
if(video.__downloadSearchPipUrl!==url)warm(url,data);
bindSearchSpeed(video);
if(!await waitForMetadata(video,2500))return!1;
forceSearchSpeed(video);
try{await video.play()}catch{}
return document.pictureInPictureElement===video
}
async function prepare(btn){
if(!btn||btn.__downloadPreparing)return;
const url=typeof btn.__downloadGetUrl==="function"&&btn.__downloadGetUrl();
if(!url)return;
btn.__downloadPreparing=!0;
try{const data=await streamFor(url);if(btn.isConnected&&(typeof btn.__downloadGetUrl!=="function"||btn.__downloadGetUrl()===url)){btn.__downloadStream=data;!activeDocumentPipWindow()&&document.pictureInPictureElement!==warmVideo&&warm(url,data);pipActivatedUrls.has(url)?setButtonState(btn,"active","Đã xem"):setButtonState(btn,"","Trình phát nổi")}}catch{}finally{btn.__downloadPreparing=!1}
}
async function openPiP(btn){
if(!btn||busy.has(btn))return;
busy.add(btn);setButtonState(btn,"loading","Preparing Picture-in-Picture…");
try{
const url=typeof btn.__downloadGetUrl==="function"&&btn.__downloadGetUrl();
if(!url){flash(btn,"No playable TikTok video was found");return}
const existingDocumentPip=activeDocumentPipWindow();
if(existingDocumentPip&&warmVideo&&warmVideo.__downloadSearchPipUrl===url){existingDocumentPip.close();markCardActionActive(btn,url,pipActivatedUrls,"Đã xem");return}
/* requestWindow() must run synchronously from this click.  Stream discovery is
 * asynchronous, so requesting it after streamFor() would lose user activation. */
const documentWindowRequest=documentPipSupported&&!existingDocumentPip?window.documentPictureInPicture.requestWindow(pipWindowOptions()):null;
const data=btn.__downloadStream||await streamFor(url);
if(documentPipSupported){
const opened=await openDocumentPiP(url,data,documentWindowRequest);
if(opened){markCardActionActive(btn,url,pipActivatedUrls,"Đã xem");return}
flash(btn,"Unable to open Picture-in-Picture");return
}
const video=getWarmVideo();
if(document.pictureInPictureElement===video){
if(video.__downloadSearchPipUrl===url){await document.exitPictureInPicture();unlockSearchPiP(video);markCardActionActive(btn,url,pipActivatedUrls,"Đã xem");return}
setButtonState(btn,"loading","Switching Picture-in-Picture video…");
if(await switchWarmPiP(video,url,data)){lockSearchPiP(video);markCardActionActive(btn,url,pipActivatedUrls,"Đã xem");return}
flash(btn,"Unable to switch the Picture-in-Picture video");return
}
if(document.pictureInPictureElement){const previousPiP=document.pictureInPictureElement;await document.exitPictureInPicture();unlockSearchPiP(previousPiP)}
mountWarmVideo(warm(url,data));
const opened=await requestSelectedPiP(video,!0);
if(opened){document.pictureInPictureElement===video?lockSearchPiP(video):unlockSearchPiP(video);markCardActionActive(btn,url,pipActivatedUrls,"Đã xem");return}
if(document.pictureInPictureElement!==video)video.remove();
setButtonState(btn,"ready","Video is ready — click Picture-in-Picture again")
}catch{flash(btn,"Unable to load this TikTok video for Picture-in-Picture")}finally{busy.delete(btn)}
}

/* ===== [Download] Multi-select popup bridge =====
 * The "Video đã chọn" management panel (assets/multi-select.js) runs in the
 * ISOLATED world and has no direct access to the functions above, so it
 * reaches this exact same Document PiP flow through a same-tick CustomEvent
 * instead of re-implementing its own PiP window. This keeps the popup
 * thumbnail's PiP identical to the Search/Explore PiP button: a scrubbable
 * seek bar, custom transparent controls, and no native-PiP dark hover
 * overlay. The request is handled synchronously up to requestWindow() (no
 * await before it) so the user gesture relayed from the popup's thumbnail
 * click is still valid when Document PiP is requested. */
async function openPiPForUrl(url,notify){
    const report=typeof notify==="function"?notify:function(){};
    if(!url){report({state:"error",message:"No playable TikTok video was found"});return}
    try{
        const existingDocumentPip=activeDocumentPipWindow();
        if(existingDocumentPip&&warmVideo&&warmVideo.__downloadSearchPipUrl===url){
            existingDocumentPip.close();
            report({state:"closed"});
            return
        }
        /* requestWindow() must run synchronously from the relayed click (see
         * the comment above openPiP()'s own documentWindowRequest). */
        const documentWindowRequest=documentPipSupported&&!existingDocumentPip?window.documentPictureInPicture.requestWindow(pipWindowOptions()):null;
        report({state:"loading"});
        const data=await streamFor(url);
        if(documentPipSupported){
            const opened=await openDocumentPiP(url,data,documentWindowRequest);
            report(opened?{state:"ok"}:{state:"error",message:"Unable to open Picture-in-Picture"});
            return
        }
        const video=getWarmVideo();
        if(document.pictureInPictureElement===video){
            if(video.__downloadSearchPipUrl===url){
                await document.exitPictureInPicture();
                unlockSearchPiP(video);
                report({state:"closed"});
                return
            }
            if(await switchWarmPiP(video,url,data)){
                lockSearchPiP(video);
                report({state:"ok"});
                return
            }
            report({state:"error",message:"Unable to switch the Picture-in-Picture video"});
            return
        }
        if(document.pictureInPictureElement){
            const previousPiP=document.pictureInPictureElement;
            await document.exitPictureInPicture();
            unlockSearchPiP(previousPiP)
        }
        mountWarmVideo(warm(url,data));
        const opened=await requestSelectedPiP(video,!0);
        if(opened){
            document.pictureInPictureElement===video?lockSearchPiP(video):unlockSearchPiP(video);
            report({state:"ok"});
            return
        }
        if(document.pictureInPictureElement!==video)video.remove();
        report({state:"error",message:"Video is ready — click again"})
    }catch{
        report({state:"error",message:"Unable to load this TikTok video for Picture-in-Picture"})
    }
}
window.addEventListener("__DOWNLOAD_MULTISELECT_PIP_REQUEST__",function(event){
    const detail=event&&event.detail;
    const url=detail&&typeof detail.url==="string"?detail.url:"";
    const requestId=detail&&typeof detail.requestId==="string"?detail.requestId:"";
    openPiPForUrl(url,function(result){
        try{
            window.dispatchEvent(new CustomEvent("__DOWNLOAD_MULTISELECT_PIP_RESPONSE__",{detail:Object.assign({requestId:requestId},result)}))
        }catch{}
    })
});
/* ===== [/Download] Multi-select popup bridge ===== */

/* ===== [Download] Hover preview =====
 * Hovering a search/explore card (the same cards that get the PiP / player /
 * download / speed buttons) plays a preview of that video on top of its
 * thumbnail; leaving the card stops it and the thumbnail shows again.
 * A speaker button at the bottom-right of the thumbnail switches the sound
 * on/off.  The choice is kept in localStorage and used by every later preview
 * (muted by default).
 * The stream comes from streamFor() - the same GET_TIKTOK_METADATA bridge the
 * PiP button uses - after a short dwell, so sweeping the pointer across the
 * grid does not fire one request per card.
 * The <video> lives in a closed shadow root so the page-wide
 * document.querySelectorAll("video") scans (playback-speed sync, auto-PiP,
 * the injected download badge, attachForVideo) never see it. */
const HOVER_PREVIEW_CLASS="__download_hover_preview",HOVER_MUTE_CLASS="__download_hover_mute_btn",HOVER_MUTE_STORAGE_KEY="__download_hover_preview_muted_v1",HOVER_PREVIEW_DELAY=350;
let hoverMuted=!0,hoverState=null;
function readHoverMuted(){
try{const saved=localStorage.getItem(HOVER_MUTE_STORAGE_KEY);if(saved==="0")hoverMuted=!1;else if(saved==="1")hoverMuted=!0}catch{}
return hoverMuted
}
function saveHoverMuted(muted){
hoverMuted=!!muted;
try{localStorage.setItem(HOVER_MUTE_STORAGE_KEY,hoverMuted?"1":"0")}catch{}
}
/* The card under the pointer: the nearest ancestor that attach() gave a player button. */
function hoverCardFor(target){
let el=target&&target.nodeType===1?target:null,hops=0;
while(el&&el!==document.documentElement&&hops++<14){
const marker=Array.prototype.find.call(el.children,child=>child.classList&&child.classList.contains(PLAYER_BUTTON_CLASS));
if(marker){let url="";try{url=typeof marker.__downloadGetUrl==="function"&&marker.__downloadGetUrl()||""}catch{}return url?{host:el,url}:null}
el=el.parentElement
}
return null
}
/* Box of the thumbnail image inside the card, relative to the card, so the preview covers only the thumbnail. */
function hoverMediaBox(host){
let best=null,bestArea=0;
try{host.querySelectorAll("img,picture,canvas,video,[style*='background']").forEach(el=>{
if(el.closest("button,[role='checkbox'],."+HOVER_PREVIEW_CLASS))return;
const r=el.getBoundingClientRect(),area=r.width*r.height;
if(area>bestArea){bestArea=area;best=el}
})}catch{}
const hostRect=host.getBoundingClientRect();
if(!best)return{left:0,top:0,width:hostRect.width,height:hostRect.height,radius:""};
const r=best.getBoundingClientRect();let radius="";
try{radius=getComputedStyle(best).borderRadius||""}catch{}
return{left:r.left-hostRect.left-(host.clientLeft||0),top:r.top-hostRect.top-(host.clientTop||0),width:r.width,height:r.height,radius}
}
function hoverVolumeIcon(muted){
return'<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.25" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 5 6 9H2v6h4l5 4V5z"/>'+(muted?'<line x1="22" y1="9" x2="16" y2="15"/><line x1="16" y1="9" x2="22" y2="15"/>':'<path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>')+"</svg>"
}
function renderHoverMuteButton(state){
const btn=state&&state.button,video=state&&state.video;
if(!btn||!video)return;
const muted=video.muted,label=muted?"Bật tiếng xem trước":"Tắt tiếng xem trước";
btn.innerHTML=hoverVolumeIcon(muted);btn.title=label;btn.setAttribute("aria-label",label)
}
function toggleHoverMute(state){
const video=state&&state.video;
if(!video)return;
const muted=!video.muted;
video.muted=muted;saveHoverMuted(muted);
if(video.paused)video.play().catch(()=>{});
renderHoverMuteButton(state)
}
function makeHoverMuteButton(state,box){
const btn=document.createElement("button");
btn.type="button";btn.className=HOVER_MUTE_CLASS;
const left=Math.max(0,Math.round(box.left+box.width-40)),top=Math.max(0,Math.round(box.top+box.height-40));
btn.style.cssText="position:absolute!important;left:"+left+"px!important;top:"+top+"px!important;width:32px!important;height:32px!important;padding:0!important;border:1px solid rgba(255,255,255,.42)!important;border-radius:50%!important;background:rgba(0,0,0,.62)!important;color:#fff!important;display:flex!important;align-items:center!important;justify-content:center!important;cursor:pointer!important;z-index:2147483645!important;box-shadow:0 2px 10px rgba(0,0,0,.42)!important;pointer-events:auto!important";
for(const type of["pointerdown","mousedown","touchstart"])btn.addEventListener(type,stopCardEvent,!0);
btn.addEventListener("click",event=>{stopCardEvent(event);toggleHoverMute(state)},!0);
return btn
}
function stopHoverPreview(){
const state=hoverState;hoverState=null;
if(!state)return;
clearTimeout(state.timer);clearInterval(state.watch);
const video=state.video;
if(video){try{video.pause();video.removeAttribute("src");video.load()}catch{}}
if(state.wrap)state.wrap.remove();
if(state.button)state.button.remove()
}
async function startHoverPreview(state){
if(hoverState!==state)return;
let data;
try{data=await streamFor(state.url)}catch{return}
const host=state.host;
if(hoverState!==state||!host.isConnected)return;
/* TikTok is already playing its own preview in this card: do not stack a second one on top. */
if(Array.prototype.some.call(host.querySelectorAll("video"),video=>!video.paused&&video.readyState>=2))return;
const box=hoverMediaBox(host);
if(!(box.width>=60&&box.height>=60))return;
const wrap=document.createElement("div");
wrap.className=HOVER_PREVIEW_CLASS;
wrap.style.cssText="position:absolute!important;left:"+Math.round(box.left)+"px!important;top:"+Math.round(box.top)+"px!important;width:"+Math.round(box.width)+"px!important;height:"+Math.round(box.height)+"px!important;overflow:hidden!important;"+(box.radius?"border-radius:"+box.radius+"!important;":"")+"background:#000!important;pointer-events:none!important;z-index:1!important;opacity:0;transition:opacity .15s ease";
const video=document.createElement("video");
video.muted=readHoverMuted();video.loop=!0;video.playsInline=!0;video.preload="auto";video.disablePictureInPicture=!0;
video.style.cssText="display:block!important;width:100%!important;height:100%!important;object-fit:cover!important;background:#000!important";
let mount=wrap;try{mount=wrap.attachShadow({mode:"closed"})}catch{}
mount.appendChild(video);
state.wrap=wrap;state.video=video;
video.addEventListener("playing",()=>{
if(hoverState!==state)return;
wrap.style.opacity="1";
if(!state.button){state.button=makeHoverMuteButton(state,box);host.appendChild(state.button)}
renderHoverMuteButton(state)
},{once:!0});
video.addEventListener("error",()=>{streamCache.delete(state.url);if(hoverState===state)stopHoverPreview()});
host.appendChild(wrap);
video.src=data.videoUrl;
try{await video.play()}catch{
if(hoverState!==state)return;
if(!video.muted){
/* The browser refuses unmuted autoplay until the page has had a user gesture:
 * fall back to muted playback; clicking the speaker button then restores sound. */
video.muted=!0;
try{await video.play()}catch{}
renderHoverMuteButton(state)
}
}
}
function scheduleHoverPreview(card){
stopHoverPreview();
const state={host:card.host,url:card.url,timer:0,watch:0,video:null,wrap:null,button:null};
hoverState=state;
state.timer=setTimeout(()=>{startHoverPreview(state).catch(()=>{})},HOVER_PREVIEW_DELAY);
/* Safety net for cases that fire no mouse event (scrolling under a still pointer, route change, hidden tab, card re-rendered). */
state.watch=setInterval(()=>{
if(hoverState!==state)return;
let hovered=!1;
try{hovered=state.host.isConnected&&state.host.matches(":hover")}catch{}
if(!hovered||document.hidden||!isSearchPage())stopHoverPreview()
},600)
}
document.addEventListener("mouseover",event=>{
if(!isSearchPage()||isDedicatedPlayerWindow()){if(hoverState)stopHoverPreview();return}
const target=event.target;
if(hoverState&&target&&hoverState.host.contains(target))return;
const card=hoverCardFor(target);
if(!card){if(hoverState)stopHoverPreview();return}
scheduleHoverPreview(card)
},!0);
window.addEventListener("mouseout",event=>{if(!event.relatedTarget)stopHoverPreview()},!0);
document.addEventListener("click",event=>{
if(!hoverState)return;
const target=event.target;
if(target&&target.closest&&target.closest("button"))return;
stopHoverPreview()
},!0);
document.addEventListener("visibilitychange",()=>{if(document.hidden)stopHoverPreview()});
/* ===== [/Download] Hover preview ===== */

scanAll();
wasSearchPage=isSearchPage();
if(searchPlaybackSpeed!==null)syncSearchSpeed();
const root=document.documentElement;
if(root)try{new MutationObserver(records=>{for(const record of records){if(record.type==="attributes")queueScan(record.target);else record.addedNodes.forEach(queueScan)}}).observe(root,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["href","src"]})}catch{}
setTimeout(scanAll,800);setTimeout(scanAll,2000);
setInterval(()=>{if(location.href===lastHref)return;lastHref=location.href;const nowSearchPage=isSearchPage();if(wasSearchPage&&!nowSearchPage&&searchPlaybackSpeed!==null)try{window.dispatchEvent(new CustomEvent("__download_settings__",{detail:{playbackSpeed:basePlaybackSpeed}}))}catch{}if(!wasSearchPage&&nowSearchPage&&searchPlaybackSpeed!==null)setTimeout(syncSearchSpeed,0);wasSearchPage=nowSearchPage;closeSpeedMenus();closeVideoPlayer();document.querySelectorAll("."+PIP_BUTTON_CLASS+",."+PLAYER_BUTTON_CLASS+",."+DOWNLOAD_BUTTON_CLASS+",."+SPEED_BUTTON_CLASS).forEach(button=>button.remove());setTimeout(scanAll,250)},750)
})();
/* ===== [/Download] Search-result PiP + player + download + speed ===== */

})();
})()
