/* ===== [Download] Multi-select checkbox + management panel =====
 * Pure addition — does not modify any existing bundled file.
 * Runs in the ISOLATED world (default), so it can call chrome.runtime
 * directly: no MAIN-world postMessage bridge is needed here.
 *
 * Card recognition mirrors the existing Search/Explore 4-button module
 * (assets/tiktok-hook.js) so the checkbox always lands on the
 * exact same cards as the PiP/Player/Download/Speed buttons:
 *   - page: /search or /explore
 *   - host: an <a href*="/video/"> whose box is card-sized (76–720 / 76–1100)
 *           and that contains an <img>/<video>/<picture>/<canvas> or a
 *           background-image element.
 *
 * Download re-uses the existing background handlers verbatim:
 *   - TIKTOK_DOWNLOAD        (same message the existing Download buttons send)
 *   - GET_TIKTOK_METADATA    (same message the existing PiP button flow uses)
 * No fetch/tikwm/chrome.downloads logic is duplicated here.
 *
 * "Open video player" re-uses the existing dedicated player window
 * (window.open with the __download_player query param + the
 * "DownloadVideoPlayer" window name) — the same mechanism the existing
 * Player button opens, so clicking it from this panel reuses that window.
 *
 * Namespace: every id/class here is prefixed with __download_multi_ so it
 * can never collide with the existing extension's own elements.
 */
(function () {
    "use strict";
    if (window.__DOWNLOAD_MULTI_SELECT__) return;
    window.__DOWNLOAD_MULTI_SELECT__ = true;

    const NS = "__download_multi_";
    const CHECKBOX_CLASS = NS + "checkbox";
    const FAB_ID = NS + "fab";
    const FAB_COUNT_ID = NS + "fab_count";
    const PANEL_ID = NS + "panel";
    const PANEL_LIST_ID = NS + "panel_list";
    const PANEL_COUNT_ID = NS + "panel_count";
    const PANEL_CLOSE_ID = NS + "panel_close";
    const PANEL_DL_PICKED_ID = NS + "panel_dl_picked";
    const PANEL_DL_ALL_ID = NS + "panel_dl_all";
    const ROW_CHECK_CLASS = NS + "row_check";
    const ROW_THUMB_CLASS = NS + "row_thumb";
    const ROW_STATUS_CLASS = NS + "row_status";
    const ROW_PLAYER_CLASS = NS + "row_player";
    const ROW_DL_CLASS = NS + "row_dl";
    const ROW_REMOVE_CLASS = NS + "row_remove";
    const PANEL_SELECTALL_CHECK_ID = NS + "panel_selectall_check";
    const PANEL_RENAME_INPUT_ID = NS + "panel_rename_input";
    const PANEL_CONCURRENCY_INPUT_ID = NS + "panel_concurrency";
    const PANEL_SAVEPATH_BOX_ID = NS + "panel_savepath_box";
    const PANEL_SAVEPATH_TEXT_ID = NS + "panel_savepath_text";
    const PANEL_SAVEPATH_CLEAR_ID = NS + "panel_savepath_clear";
    const CENTER_TOAST_ID = NS + "center_toast";
    // Advanced folder mode (Video ↔ subfolder mapping) — only rendered/used
    // when advancedFolderMode is on; see the "Advanced folder mode" section.
    const PANEL_ADV_SECTION_ID = NS + "panel_adv_section";
    const PANEL_FOLDER_LIST_ID = NS + "panel_folder_list";
    const PANEL_ADV_REFRESH_ID = NS + "panel_adv_refresh";
    const ROW_NUM_BADGE_CLASS = NS + "row_badge";
    const ROW_FOLDER_CELL_CLASS = NS + "row_folder_cell";
    const ROW_FOLDER_INPUT_CLASS = NS + "row_folder_input";
    const FOLDER_CHIP_CLASS = NS + "folder_chip";

    const PLAYER_WINDOW_NAME = "DownloadVideoPlayer";
    const PLAYER_REQUEST_PARAM = "__download_player";

    // Persisted (chrome.storage.local) so the FAB stays where the user put it,
    // and so their preferred "how many at once" download setting survives
    // page reloads / new tabs.
    const FAB_POS_KEY = NS + "fab_pos";
    const CONCURRENCY_KEY = NS + "concurrency";
    // Subfolder order the user arranged by dragging chips in the panel:
    // { [rootFolderName]: [subfolderName, ...] }, see "Folder chip re-ordering".
    const FOLDER_ORDER_KEY = NS + "folder_order";
    const DEFAULT_CONCURRENCY = 3;
    // "Save to folder": the folder handle itself is not JSON-safe, so it
    // lives in IndexedDB (see the "Save to folder" section below).
    const SAVEPATH_IDB_NAME = NS + "fsdb";
    const SAVEPATH_IDB_STORE = "handles";
    const SAVEPATH_IDB_KEY = "root";
    const MAX_CONCURRENCY = 5;

    // Display mode of the selected-videos list: expanded (full list shown)
    // or collapsed (only the FAB download icon). The mode is sticky — it
    // changes ONLY when the user explicitly toggles it (clicking the FAB, or
    // the panel's own × button), never as a side effect of selecting videos,
    // clicking elsewhere on the page or pressing Escape. Remembered across
    // page loads. Expanded by default, matching the previous behavior.
    const PANEL_EXPANDED_KEY = NS + "panel_expanded";
    let panelExpandedMode = true;

    function loadPanelExpandedMode() {
        try {
            chrome.storage.local.get(PANEL_EXPANDED_KEY, (res) => {
                if (res && typeof res[PANEL_EXPANDED_KEY] === "boolean") panelExpandedMode = res[PANEL_EXPANDED_KEY];
            });
        } catch {}
    }

    function setPanelExpandedMode(expanded) {
        panelExpandedMode = !!expanded;
        try {
            chrome.storage.local.set({ [PANEL_EXPANDED_KEY]: panelExpandedMode });
        } catch {}
    }

    // Global extension setting (NOT namespaced with NS: plain, un-prefixed
    // key shared with popup.html/popup.js's "Chọn thư mục nâng cao" toggle,
    // so both sides must agree on the name).
    // When ON, the panel additionally reads the direct subfolders of the
    // chosen root folder and lets each video be mapped to one of them (see
    // the "Advanced folder mode" section further down). When OFF, every
    // piece of that is skipped and the panel behaves exactly as before.
    const ADVANCED_FOLDER_SETTING_KEY = "advancedFolderMode";
    let advancedFolderMode = false;

    function loadAdvancedFolderSetting() {
        try {
            chrome.storage.local.get(ADVANCED_FOLDER_SETTING_KEY, (res) => {
                advancedFolderMode = !!(res && res[ADVANCED_FOLDER_SETTING_KEY] === true);
                if (advancedFolderMode && rootDirHandle) rescanFolders();
                else renderAdvancedFolderSection();
            });
        } catch {}
    }

    // Same pattern again: plain, un-prefixed key shared with popup.html/popup.js's
    // "Luôn hiển thị trên cùng" toggle. When ON, the row's "Open video player"
    // button opens the video in an always-on-top Document PiP window (see
    // previewPip below) instead of the regular popup window. Cached here so the
    // click handler can read it synchronously; the onChanged listener keeps it
    // live, so flipping the toggle applies to the very next click.
    const PLAYER_ALWAYS_ON_TOP_SETTING_KEY = "playerAlwaysOnTop";
    let playerAlwaysOnTop = false;

    function loadPlayerAlwaysOnTopSetting() {
        try {
            chrome.storage.local.get(PLAYER_ALWAYS_ON_TOP_SETTING_KEY, (res) => {
                playerAlwaysOnTop = !!(res && res[PLAYER_ALWAYS_ON_TOP_SETTING_KEY] === true);
            });
        } catch {}
    }

    try {
        chrome.storage.onChanged.addListener((changes, area) => {
            if (area !== "local") return;
            if (changes[PLAYER_ALWAYS_ON_TOP_SETTING_KEY]) {
                playerAlwaysOnTop = changes[PLAYER_ALWAYS_ON_TOP_SETTING_KEY].newValue === true;
            }
            if (changes[ADVANCED_FOLDER_SETTING_KEY]) {
                advancedFolderMode = changes[ADVANCED_FOLDER_SETTING_KEY].newValue === true;
                // Toggling mid-session (the popup can be opened any time, not
                // just before a page load) must take effect immediately: pull
                // in the subfolder list if it turns on, and rebuild any
                // already-open row list either way so the Folder column /
                // numbering badges appear or disappear right away.
                if (advancedFolderMode && rootDirHandle) rescanFolders();
                else renderAdvancedFolderSection();
                if (panelOpen) renderPanelList();
            }
        });
    } catch {}
    const FAB_MARGIN = 16;
    const FAB_SIZE = 52;
    const DRAG_THRESHOLD = 6; // px of movement before a press-and-hold counts as a drag, not a click

    /* ---------------- page / card detection (mirrors the existing hook) --------------- */

    function isSearchPage() {
        try {
            return /^\/(?:search|explore)(?:\/|$)/.test(location.pathname);
        } catch {
            return false;
        }
    }

    function hasCardSize(el) {
        try {
            const r = el.getBoundingClientRect();
            return r.width >= 76 && r.height >= 76 && r.width <= 720 && r.height <= 1100;
        } catch {
            return false;
        }
    }

    function isThumbnailLink(link) {
        return !!(
            link &&
            hasCardSize(link) &&
            (link.querySelector("img,video,picture,canvas") || link.querySelector("[style*='background']"))
        );
    }

    function videoUrl(value) {
        try {
            const url = new URL(value, location.href);
            return url.protocol === "https:" && /(^|\.)tiktok\.com$/i.test(url.hostname) && /\/video\/\d+/.test(url.pathname)
                ? url.href
                : "";
        } catch {
            return "";
        }
    }

    function stopCardEvent(event) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
    }

    function escapeHtml(value) {
        return String(value == null ? "" : value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#39;");
    }

    function sleep(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }

    /* ---------------- background messaging (reuses existing handlers) --------------- */

    function sendMessage(msg) {
        return new Promise((resolve) => {
            try {
                chrome.runtime.sendMessage(msg, (result) => {
                    const err = chrome.runtime.lastError;
                    resolve(err ? { success: false, error: err.message } : result || { success: false, error: "no_response" });
                });
            } catch (e) {
                resolve({ success: false, error: (e && e.message) || "send_failed" });
            }
        });
    }

    // Reuses the extension's existing TIKTOK_DOWNLOAD handler; only adds an
    // optional custom filename, read fresh from the rename box each call.
    // When a save folder has been chosen, that folder is authoritative: the
    // download goes there and only there. It deliberately never falls back
    // to chrome.downloads on failure — a silent fallback used to mean a
    // video could show up in both the chosen folder and Chrome's default
    // Downloads folder, depending on exactly where the write failed.
    async function downloadUrl(url) {
        const renameInput = document.getElementById(PANEL_RENAME_INPUT_ID);
        const filename = nextRenamedFilename(renameInput ? renameInput.value : "");
        if (rootDirHandle) {
            const item = selected.get(url);
            const folderName = advancedFolderMode && item ? item.folderName || null : null;
            return await saveToChosenFolder(url, filename, folderName);
        }
        const msg = { type: "TIKTOK_DOWNLOAD", url };
        if (filename) msg.filename = filename;
        const res = await sendMessage(msg);
        return { success: !!(res && res.success), error: res && res.error };
    }

    // Reuses the extension's existing GET_TIKTOK_METADATA handler verbatim.
    async function getMetadata(url) {
        const res = await sendMessage({ type: "GET_TIKTOK_METADATA", url });
        return res && res.success ? res.data : null;
    }

    /* ---------------- "Save to folder" (persisted custom download location) ---------------
     * Chrome deliberately does not let a page/extension read or write an
     * arbitrary absolute OS path, see the real absolute path of a folder the
     * user picks, or open an arbitrary OS folder in the system file manager
     * — that is a browser security boundary, not a bug here. The closest
     * the platform allows is the File System Access API: showDirectoryPicker()
     * opens the real native OS folder browser, and the resulting handle can
     * be used to write files straight into that folder on every future
     * download without asking again, as long as the granted permission is
     * still valid (see queryRootPermission below — Chrome may ask to
     * re-confirm it after a browser restart, which just needs one click,
     * not re-picking the folder).
     *
     * Trade-offs this implies, by design:
     *  - Only the folder's own name is ever exposed to us (never a full
     *    "D:\..." path) — refreshSavePathUI() shows that name, not a path.
     *  - Files are saved directly in that folder — there is no subfolder
     *    picker/typed subpath here anymore.
     *  - Files written this way do NOT go through chrome.downloads, so they
     *    will not appear in Chrome's download history/shelf.
     *  - Once a folder is chosen it is authoritative: downloadUrl() sends
     *    every download through saveToChosenFolder() only. A failure there
     *    is reported back as an error and never silently retried through
     *    the normal TIKTOK_DOWNLOAD/chrome.downloads flow, so a video is
     *    never saved to the chosen folder and Chrome's default folder at
     *    the same time.
     */

    let rootDirHandle = null; // FileSystemDirectoryHandle | null — cached in memory after the first IndexedDB load
    let rootDirLoaded = false; // true once that first load has resolved (lets the UI show "loading" briefly instead of "not set")
    let savePathNeedsPermission = false; // kept in sync by refreshSavePathUI(); read by the box's click handler

    // ---- Advanced folder mode state (only meaningful when advancedFolderMode === true) ----
    // currentFolders: names of the direct subfolders of rootDirHandle, in the
    // same order shown to the user — index 0 is "folder #1", etc. Names
    // (not handles) are the source of truth for a video's mapping, so a
    // rescan can tell a still-present folder apart from one that was
    // deleted/renamed, per rescanFolders()/reconcileFolderMappings() below.
    let currentFolders = [];
    let folderHandleCache = new Map(); // subfolder name -> FileSystemDirectoryHandle, refreshed by every rescanFolders()
    // "no-root" | "no-permission" | "loading" | "empty" | "ready"
    let advFolderStatus = "no-root";
    // The Folder-column <input> the user most recently focused, so a click on
    // a folder chip (see "click-to-link", section 10 of the spec) knows which
    // video row to apply the mapping to.
    let focusedFolderInputEl = null;
    // Last time that input gained or lost focus. A chip click lands right
    // after the input blurs (pressing the chip moves focus), so "focused or
    // blurred a moment ago" = the user deliberately picked that row first.
    // An older focus is stale and must not hijack the single-unmapped shortcut.
    let focusedFolderInputAt = 0;
    const FOLDER_FOCUS_FRESH_MS = 1500;
    // Drag-to-reorder state for the subfolder chips (see "Folder chip
    // re-ordering"). chipClickSuppressUntil swallows the click that the
    // browser fires right after a drag ends, so dropping a chip never also
    // links it to a video.
    const CHIP_DRAG_THRESHOLD_PX = 5;
    let folderDragState = null; // { chip, name, startX, startY, dragging, insertAt }
    let chipClickSuppressUntil = 0;

    function idbOpen() {
        return new Promise((resolve, reject) => {
            try {
                const req = indexedDB.open(SAVEPATH_IDB_NAME, 1);
                req.onupgradeneeded = () => {
                    if (!req.result.objectStoreNames.contains(SAVEPATH_IDB_STORE)) {
                        req.result.createObjectStore(SAVEPATH_IDB_STORE);
                    }
                };
                req.onsuccess = () => resolve(req.result);
                req.onerror = () => reject(req.error || new Error("idb_open_failed"));
            } catch (e) {
                reject(e);
            }
        });
    }

    async function idbSet(key, value) {
        const db = await idbOpen();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(SAVEPATH_IDB_STORE, "readwrite");
            tx.objectStore(SAVEPATH_IDB_STORE).put(value, key);
            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error || new Error("idb_set_failed"));
        });
    }

    async function idbGet(key) {
        const db = await idbOpen();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(SAVEPATH_IDB_STORE, "readonly");
            const req = tx.objectStore(SAVEPATH_IDB_STORE).get(key);
            req.onsuccess = () => resolve(req.result || null);
            req.onerror = () => reject(req.error || new Error("idb_get_failed"));
        });
    }

    async function idbDelete(key) {
        const db = await idbOpen();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(SAVEPATH_IDB_STORE, "readwrite");
            tx.objectStore(SAVEPATH_IDB_STORE).delete(key);
            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error || new Error("idb_delete_failed"));
        });
    }

    // Loaded once at startup: pulls the previously-picked folder handle (if
    // any) out of IndexedDB. Purely passive — never prompts the user.
    async function loadRootDirHandle() {
        try {
            rootDirHandle = await idbGet(SAVEPATH_IDB_KEY);
        } catch {
            rootDirHandle = null;
        }
        rootDirLoaded = true;
        refreshSavePathUI();
        if (advancedFolderMode && rootDirHandle) rescanFolders();
        else renderAdvancedFolderSection();
    }

    // Passive check only — never shows a permission prompt. Safe to call any
    // time, including outside a user gesture (e.g. right after page load).
    async function queryRootPermission() {
        if (!rootDirHandle) return "no-handle";
        try {
            return await rootDirHandle.queryPermission({ mode: "readwrite" });
        } catch {
            return "denied";
        }
    }

    // Interactive — must only be called synchronously-ish from inside a real
    // click handler, since re-confirming a lapsed permission requires a
    // user gesture.
    async function requestRootPermission() {
        if (!rootDirHandle) return "no-handle";
        try {
            return await rootDirHandle.requestPermission({ mode: "readwrite" });
        } catch {
            return "denied";
        }
    }

    // Reconstructs the raw video bytes from the base64 string background.js
    // sends over (see the comment in __fetchBytesForChosenFolder for why a
    // plain ArrayBuffer can't be sent through chrome.runtime.sendMessage).
    function base64ToBytes(base64) {
        const binary = atob(base64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
        }
        return bytes;
    }

    function sanitizeFsName(name) {
        return String(name || "")
            .replace(/[<>:"/\\|?*\x00-\x1f\x7f]/g, "")
            .replace(/\s+/g, " ")
            .trim()
            .slice(0, 180);
    }

    // Mirrors the extension's own default-filename convention ("<author> -
    // <title or short id>.mp4") so files saved this way look the same as
    // ones saved through the normal TIKTOK_DOWNLOAD flow.
    function buildDefaultFilename(meta, url) {
        const idMatch = String(url || "").match(/\/video\/(\d+)/);
        const idSuffix = idMatch ? idMatch[1].slice(-8) : String(Date.now());
        const author = ((meta && meta.author) || "tiktok").trim() || "tiktok";
        const title = ((meta && meta.title) || "").trim();
        const base = title ? author + " - " + title : author + " - " + idSuffix;
        return sanitizeFsName(base) + ".mp4";
    }

    // Writes straight into the chosen folder and reports the real outcome —
    // {success:true} once the file is actually written, or
    // {success:false, error} otherwise. Unlike the old implementation, this
    // never falls back to chrome.downloads: once a folder is chosen it is
    // the only place a video gets saved, so a failure here is surfaced to
    // the caller instead of silently retried elsewhere.
    //
    // `folderName`, when given (advanced folder mode only — see downloadUrl),
    // is the direct subfolder of rootDirHandle this particular video is
    // mapped to; the file is written inside that subfolder instead of
    // straight into rootDirHandle. Left null/undefined, behavior is exactly
    // the plain flat-root save this function has always done.
    async function saveToChosenFolder(url, filenameOverride, folderName) {
        let filename = null;
        let targetDirHandle = rootDirHandle;
        try {
            let permission = await queryRootPermission();
            if (permission !== "granted") {
                // Interactive re-confirmation needs a user gesture; safe to
                // call here because this only ever runs from inside a real
                // click handler (the row / "Đã chọn" / "Tất cả" buttons).
                permission = await requestRootPermission();
            }
            if (permission !== "granted") {
                return { success: false, error: "Chưa có quyền ghi vào thư mục đã chọn" };
            }
            if (folderName) {
                try {
                    targetDirHandle = await rootDirHandle.getDirectoryHandle(folderName, { create: false });
                } catch {
                    // The folder this video was mapped to is gone (deleted or
                    // renamed since the mapping was made) — never silently
                    // fall back to the root folder for it. Trigger a rescan so
                    // the folder list / numbering the user sees is accurate
                    // right away, matching section 17/18 of the spec.
                    rescanFolders();
                    return { success: false, error: 'Không tìm thấy thư mục "' + folderName + '".' };
                }
            }
            const meta = await getMetadata(url);
            if (!meta || !meta.videoUrl) return { success: false, error: "Không lấy được video" };
            filename = filenameOverride ? sanitizeFsName(filenameOverride) + ".mp4" : buildDefaultFilename(meta, url);
            // Fetching the raw video bytes has to happen in the background
            // service worker (it holds the host_permissions needed to read
            // cross-origin video bytes) — a content-script fetch here would
            // be subject to the page's own CORS rules and could be blocked.
            const bytesRes = await sendMessage({ type: "__DOWNLOAD_MULTI_FETCH_BYTES__", url: meta.videoUrl });
            if (!bytesRes || !bytesRes.success || !bytesRes.base64) {
                return { success: false, error: (bytesRes && bytesRes.error) || "Không tải được dữ liệu video" };
            }
            const bytes = base64ToBytes(bytesRes.base64);
            const fileHandle = await targetDirHandle.getFileHandle(filename, { create: true });
            const writable = await fileHandle.createWritable();
            await writable.write(bytes);
            await writable.close();
            return { success: true };
        } catch (e) {
            // Best-effort cleanup: getFileHandle(create:true) above can
            // leave an empty/partial file behind if a later step throws,
            // and this stops that from lingering in the chosen folder.
            if (filename) {
                try {
                    await targetDirHandle.removeEntry(filename);
                } catch {}
            }
            return { success: false, error: (e && e.message) || "Lỗi khi lưu vào thư mục đã chọn" };
        }
    }

    async function pickRootFolder() {
        if (typeof window.showDirectoryPicker !== "function") {
            const textEl = document.getElementById(PANEL_SAVEPATH_TEXT_ID);
            if (textEl) textEl.textContent = "Trình duyệt này chưa hỗ trợ chọn thư mục";
            return;
        }
        let handle;
        try {
            handle = await window.showDirectoryPicker({ id: NS + "root", mode: "readwrite" });
        } catch {
            return; // user cancelled the native dialog — nothing to do
        }
        try {
            const permission = await handle.requestPermission({ mode: "readwrite" });
            if (permission !== "granted") return;
        } catch {
            return;
        }
        rootDirHandle = handle;
        try {
            await idbSet(SAVEPATH_IDB_KEY, handle);
        } catch {}
        refreshSavePathUI();
        // A freshly (re)picked root folder means any previous subfolder list
        // is for the OLD root and must not linger — rescanFolders() reads the
        // new one, renumbers 1→N, and re-validates every video's mapping
        // against it (clearing any that no longer resolve), per section 18.
        if (advancedFolderMode) await rescanFolders();
        else renderAdvancedFolderSection();
    }

    async function clearRootFolder() {
        rootDirHandle = null;
        try {
            await idbDelete(SAVEPATH_IDB_KEY);
        } catch {}
        refreshSavePathUI();
        await rescanFolders(); // no root -> empties currentFolders and clears every video's mapping
    }

    function folderIconSvg() {
        return '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex:none;"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/></svg>';
    }

    // Re-renders the box's display text/color from current in-memory state.
    // Safe to call any time — quietly no-ops if the panel isn't built yet.
    async function refreshSavePathUI() {
        const textEl = document.getElementById(PANEL_SAVEPATH_TEXT_ID);
        const box = document.getElementById(PANEL_SAVEPATH_BOX_ID);
        const clearBtn = document.getElementById(PANEL_SAVEPATH_CLEAR_ID);
        if (!textEl || !box) return;
        if (!rootDirLoaded) {
            textEl.textContent = "Đang tải…";
            box.style.color = "rgba(255,255,255,.55)";
            if (clearBtn) clearBtn.style.display = "none";
            savePathNeedsPermission = false;
            return;
        }
        if (!rootDirHandle) {
            textEl.textContent = "Chưa chọn thư mục — nhấp để chọn";
            box.style.color = "rgba(255,255,255,.5)";
            if (clearBtn) clearBtn.style.display = "none";
            savePathNeedsPermission = false;
            return;
        }
        if (clearBtn) clearBtn.style.display = "";
        const permission = await queryRootPermission();
        const rootName = rootDirHandle.name || "(thư mục đã chọn)";
        if (permission !== "granted") {
            textEl.textContent = "⚠ " + rootName + " — nhấp để cấp lại quyền";
            box.style.color = "#fbbf24";
            savePathNeedsPermission = true;
            return;
        }
        savePathNeedsPermission = false;
        textEl.textContent = rootName;
        box.style.color = "#67e8f9";
    }

    /* ---------------- Advanced folder mode (Video ↔ subfolder mapping) ---------------
     * Only active when advancedFolderMode === true AND a root folder is
     * chosen (the same root the flat "Save to folder" box above already
     * manages — advanced mode does not introduce a second root picker, it
     * reuses that one). Adds:
     *   - a numbered list of the root's direct subfolders (currentFolders),
     *   - a Folder column on every row in the panel list, letting a video be
     *     mapped to one of those subfolders by number, by typing or by
     *     clicking a folder chip after focusing the row's input,
     *   - validation of that number, and a warning before downloading any
     *     video that still has no folder chosen.
     * Mappings are kept as the subfolder's NAME on the item itself
     * (item.folderName), not its position, so a rescan can tell a
     * still-present folder apart from one that was deleted/renamed and
     * clear only the mappings that no longer resolve (see
     * reconcileFolderMappings) instead of trusting stale numbers.
     */

    // The File System Access API deliberately never exposes real OS-level
    // file attributes (Windows' "Hidden" checkbox/attrib +H, macOS Finder's
    // hidden flag, a Linux dotfile's own semantics, etc.) — a
    // FileSystemDirectoryHandle entry only ever gives a plain name and a
    // kind, nothing else, by design (same sandboxing this whole feature
    // already works within). The one "hidden folder" signal that IS
    // readable from the name alone — and is the standard convention on
    // macOS/Linux, plus widely recognized by cross-platform tools on
    // Windows too — is a leading dot, e.g. ".git", ".cache". That's what
    // this checks; it can't and doesn't check the Windows Hidden attribute
    // itself, since the API has no way to read that.
    function isHiddenFolderName(name) {
        return typeof name === "string" && name.charAt(0) === ".";
    }

    // Re-reads the direct subfolders of rootDirHandle, renumbers them, and
    // re-validates every selected video's mapping against the new list.
    // Safe to call any time (init, toggling the setting on, re-picking or
    // clearing the root, the manual refresh button, or automatically after a
    // download fails with "folder not found").
    async function rescanFolders() {
        if (!rootDirHandle) {
            currentFolders = [];
            folderHandleCache.clear();
            advFolderStatus = "no-root";
            reconcileFolderMappings();
            renderAdvancedFolderSection();
            if (panelOpen) renderPanelList();
            return;
        }
        const permission = await queryRootPermission();
        if (permission !== "granted") {
            advFolderStatus = "no-permission";
            renderAdvancedFolderSection();
            return;
        }
        advFolderStatus = "loading";
        renderAdvancedFolderSection();
        const names = [];
        const cache = new Map();
        try {
            // FileSystemDirectoryHandle is async-iterable; only entries whose
            // own kind is "directory" are subfolders — files sitting directly
            // in the root are ignored, matching section 6 of the spec (only
            // direct child folders, not files, not deeper levels). Hidden
            // (dot-prefixed) subfolders are skipped too — see
            // isHiddenFolderName above for why only that convention, and not
            // the OS's own Hidden attribute, can be checked here.
            for await (const [name, handle] of rootDirHandle.entries()) {
                if (handle.kind === "directory" && !isHiddenFolderName(name)) {
                    names.push(name);
                    cache.set(name, handle);
                }
            }
        } catch {
            // Read failed entirely (e.g. permission revoked mid-flight) —
            // treat as "no subfolders" rather than leaving stale data around.
            currentFolders = [];
            folderHandleCache.clear();
            advFolderStatus = "empty";
            reconcileFolderMappings();
            renderAdvancedFolderSection();
            if (panelOpen) renderPanelList();
            return;
        }
        // Stable, deterministic order so folder numbers don't reshuffle
        // between rescans unless the actual set of subfolders changed.
        names.sort((a, b) => a.localeCompare(b, "vi", { numeric: true, sensitivity: "base" }));
        // ...then the user's own drag-to-reorder arrangement (if any) wins
        // over that alphabetical default; folders it doesn't know about yet
        // (newly created) are appended at the end in alphabetical order.
        currentFolders = applySavedFolderOrder(names, await loadSavedFolderOrder(folderOrderRootKey()));
        folderHandleCache = cache;
        advFolderStatus = names.length ? "ready" : "empty";
        reconcileFolderMappings();
        renderAdvancedFolderSection();
        if (panelOpen) renderPanelList();
    }

    // Clears any video's mapping whose folder name is no longer among
    // currentFolders (deleted, renamed, or the root itself changed) — never
    // blindly keeps a stale mapping, per section 17/18 of the spec.
    function reconcileFolderMappings() {
        let invalidated = 0;
        for (const item of selected.values()) {
            if (item.folderName && !currentFolders.includes(item.folderName)) {
                item.folderName = null;
                invalidated++;
            }
        }
        if (invalidated > 0) {
            showCenterToast(
                invalidated + " video đã mất liên kết vì thư mục không còn tồn tại",
                "warn",
                5000
            );
        }
    }

    // 1-based position of `name` in currentFolders, or 0 if it isn't there.
    function folderIndexForName(name) {
        const idx = currentFolders.indexOf(name);
        return idx === -1 ? 0 : idx + 1;
    }

    // Applies folder #idx (1-based) to whichever video owns `inputEl`,
    // validating range first. Shared by the input's own change handler and
    // by clicking a folder chip (section 10/11 of the spec — typing a number
    // and clicking a folder both end up here).
    function applyFolderMapping(inputEl, idx) {
        const row = inputEl.closest("[data-url]");
        const item = row && selected.get(row.dataset.url);
        if (!item) return;
        if (!Number.isInteger(idx) || idx < 1) {
            inputEl.value = "";
            item.folderName = null;
            markFolderInputValidity(inputEl, true);
            return;
        }
        if (idx > currentFolders.length) {
            inputEl.value = "";
            item.folderName = null;
            markFolderInputValidity(inputEl, true);
            showCenterToast("Folder số " + idx + " không tồn tại.", "error", 3000);
            return;
        }
        item.folderName = currentFolders[idx - 1];
        inputEl.value = String(idx);
        markFolderInputValidity(inputEl, true);
    }

    function markFolderInputValidity(inputEl, valid) {
        inputEl.style.borderColor = valid ? "rgba(34,211,238,.55)" : "rgba(251,113,133,.7)";
        inputEl.style.color = valid ? "#67e8f9" : "#fb7185";
    }

    // Handles the Folder-column <input> being typed into directly. Only
    // positive integers are accepted at all (section 13); an in-range one is
    // resolved to a folder name via applyFolderMapping, everything else is
    // rejected with the video left unmapped rather than guessing.
    function handleFolderInputChange(item, inputEl) {
        const raw = inputEl.value.trim();
        if (raw === "") {
            item.folderName = null;
            markFolderInputValidity(inputEl, true);
            return;
        }
        if (!/^[1-9][0-9]*$/.test(raw)) {
            inputEl.value = "";
            item.folderName = null;
            markFolderInputValidity(inputEl, false);
            showCenterToast("Chỉ chấp nhận số nguyên dương (1-" + currentFolders.length + ").", "error", 3000);
            setTimeout(() => markFolderInputValidity(inputEl, true), 1500);
            return;
        }
        applyFolderMapping(inputEl, parseInt(raw, 10));
    }

    // After a row is removed from an already-open panel (removePanelRowByUrl
    // touches only that one row, not a full rebuild), every row below it has
    // shifted up one position — this brings their ①②③ badges back in sync
    // without re-rendering thumbnails/inputs. No-op outside advanced mode,
    // where those badges don't exist.
    function renumberVisibleRows() {
        if (!advancedFolderMode) return;
        const list = document.getElementById(PANEL_LIST_ID);
        if (!list) return;
        const rows = list.querySelectorAll("[data-url]");
        rows.forEach((row, i) => {
            const badge = row.querySelector("." + ROW_NUM_BADGE_CLASS);
            if (badge) badge.textContent = String(i + 1);
        });
    }

    // Renders the "Thư mục con" block inside the panel (folder chips /
    // empty-root hint / permission hint) and sizes the panel itself — wider
    // in advanced mode so the new Folder column and badges have room without
    // squeezing the existing video info, unchanged (320px) otherwise. Safe
    // to call any time, including before the panel has been built yet.
    function renderAdvancedFolderSection() {
        const panel = document.getElementById(PANEL_ID);
        if (panel) {
            panel.style.width = (advancedFolderMode ? 400 : 320) + "px";
            // positionPanelNearFab() pins the panel's LEFT edge to a fixed
            // pixel value computed from the FAB's position (see that
            // function), so changing the width alone — which is all the
            // line above does — only grows the panel further to the right,
            // potentially off-screen or overlapping the page, since the
            // right edge is whatever moves. Advanced folder mode can be
            // toggled from the popup/sidepanel while this panel is already
            // open (see the chrome.storage.onChanged listener above), so
            // re-anchoring here — not just when the panel first opens —
            // is what makes the panel grow toward the FAB (left) instead.
            if (panelOpen) positionPanelNearFab();
        }
        const section = document.getElementById(PANEL_ADV_SECTION_ID);
        const listEl = document.getElementById(PANEL_FOLDER_LIST_ID);
        if (!section || !listEl) return;
        if (!advancedFolderMode) {
            section.style.display = "none";
            return;
        }
        section.style.display = "block";
        listEl.innerHTML = "";
        if (!rootDirHandle) {
            listEl.innerHTML = '<div style="font-size:11px;opacity:.55;">Chọn thư mục gốc ở trên để bắt đầu.</div>';
            return;
        }
        if (advFolderStatus === "loading") {
            listEl.innerHTML = '<div style="font-size:11px;opacity:.55;">Đang đọc thư mục con…</div>';
            return;
        }
        if (advFolderStatus === "no-permission") {
            listEl.innerHTML = '<div style="font-size:11px;color:#fbbf24;">Thư mục cần được cấp lại quyền (nhấp vào ô phía trên).</div>';
            return;
        }
        if (advFolderStatus === "empty") {
            const hint = document.createElement("div");
            hint.style.cssText = "font-size:11px;opacity:.65;margin-bottom:6px;";
            hint.textContent = "Thư mục đã chọn không có thư mục con.";
            listEl.appendChild(hint);
            const btn = document.createElement("button");
            btn.type = "button";
            btn.textContent = "Chọn thư mục khác";
            btn.style.cssText =
                "font-size:11px;padding:5px 10px;border-radius:7px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.06);color:#fff;cursor:pointer;";
            btn.addEventListener("click", (ev) => {
                stopCardEvent(ev);
                pickRootFolder();
            });
            listEl.appendChild(btn);
            return;
        }
        currentFolders.forEach((name, i) => {
            const chip = document.createElement("button");
            chip.type = "button";
            chip.className = FOLDER_CHIP_CLASS;
            chip.textContent = "[" + (i + 1) + "] " + name;
            chip.dataset.folderName = name;
            chip.title = "Kéo để đổi vị trí. Bấm để liên kết: chỉ có 1 video (hoặc chỉ còn 1 video chưa liên kết) thì tự điền; còn lại bấm vào ô số của video trước.";
            chip.style.cssText =
                "font-size:11px;padding:4px 8px;border-radius:7px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);color:#a5f3fc;cursor:grab;max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;touch-action:none;user-select:none;";
            chip.addEventListener("click", (ev) => {
                stopCardEvent(ev);
                if (Date.now() < chipClickSuppressUntil) return;
                // Exactly one selected video: there is no ambiguity about
                // which video the folder is for, so link it straight away
                // without making the user focus that row's number box first.
                const soleInput = selected.size === 1 ? soleRowFolderInput() : null;
                if (soleInput) {
                    applyFolderMapping(soleInput, i + 1);
                    return;
                }
                const focusAlive = !!focusedFolderInputEl && focusedFolderInputEl.isConnected;
                // The user just picked a row's number box on purpose: honour
                // that row, even when exactly one other video is unmapped.
                if (focusAlive && Date.now() - focusedFolderInputAt < FOLDER_FOCUS_FRESH_MS) {
                    applyFolderMapping(focusedFolderInputEl, i + 1);
                    return;
                }
                // Several videos selected but exactly one of them has no
                // folder yet: it is the only one the click can be meant for.
                const unmappedInput = soleUnmappedRowFolderInput();
                if (unmappedInput) {
                    applyFolderMapping(unmappedInput, i + 1);
                    return;
                }
                if (!focusAlive) {
                    showCenterToast("Hãy bấm vào ô số của video trước, rồi bấm thư mục để liên kết.", "warn", 3000);
                    return;
                }
                applyFolderMapping(focusedFolderInputEl, i + 1);
            });
            listEl.appendChild(chip);
        });
    }

    /* ---------------- Single-video shortcut ----------------
     * With exactly one selected video there is nothing to disambiguate, so a
     * click on a subfolder chip links that folder straight to that video's
     * number box (the chip click handler in renderAdvancedFolderSection).
     * The same applies when several videos are selected but exactly one of
     * them has no folder yet (soleUnmappedRowFolderInput).
     */
    function soleRowFolderInput() {
        const list = document.getElementById(PANEL_LIST_ID);
        if (!list) return null;
        const rows = list.querySelectorAll("[data-url]");
        if (rows.length !== 1) return null;
        return rows[0].querySelector("." + ROW_FOLDER_INPUT_CLASS);
    }

    // The Folder-column <input> of the one selected video that has no folder
    // yet, or null when zero or several videos are still unmapped.
    function soleUnmappedRowFolderInput() {
        const list = document.getElementById(PANEL_LIST_ID);
        if (!list) return null;
        let found = null;
        for (const row of list.querySelectorAll("[data-url]")) {
            const item = selected.get(row.dataset.url);
            if (!item || item.folderName) continue;
            if (found) return null;
            found = row;
        }
        return found ? found.querySelector("." + ROW_FOLDER_INPUT_CLASS) : null;
    }

    // Refreshes every visible row's number box after the folder numbering
    // changed (chips re-ordered). Mappings are stored by folder NAME, so only
    // the displayed number has to follow; no row is rebuilt (thumbnails stay).
    function syncRowFolderInputs() {
        const list = document.getElementById(PANEL_LIST_ID);
        if (!list) return;
        list.querySelectorAll("[data-url]").forEach((row) => {
            const item = selected.get(row.dataset.url);
            const input = row.querySelector("." + ROW_FOLDER_INPUT_CLASS);
            if (!item || !input) return;
            const idx = item.folderName ? folderIndexForName(item.folderName) : 0;
            input.value = idx ? String(idx) : "";
            input.style.borderColor = idx ? "rgba(34,211,238,.55)" : "rgba(255,255,255,.15)";
            input.style.color = idx ? "#67e8f9" : "#fff";
        });
    }

    /* ---------------- Folder chip re-ordering ----------------
     * The subfolder chips can be dragged to a new position; the arrangement
     * is saved per root folder name in chrome.storage.local (FOLDER_ORDER_KEY)
     * and re-applied by every rescanFolders(), so it survives page loads and
     * panel re-opens. Position = folder number, so re-ordering also renumbers.
     */
    function folderOrderRootKey() {
        return rootDirHandle && rootDirHandle.name ? rootDirHandle.name : "";
    }

    function loadSavedFolderOrder(rootKey) {
        return new Promise((resolve) => {
            try {
                chrome.storage.local.get(FOLDER_ORDER_KEY, (res) => {
                    const all = res && res[FOLDER_ORDER_KEY];
                    const list = all && typeof all === "object" ? all[rootKey] : null;
                    resolve(Array.isArray(list) ? list.filter((n) => typeof n === "string") : []);
                });
            } catch {
                resolve([]);
            }
        });
    }

    function saveFolderOrder(rootKey, names) {
        try {
            chrome.storage.local.get(FOLDER_ORDER_KEY, (res) => {
                const prev = res && res[FOLDER_ORDER_KEY];
                const all = prev && typeof prev === "object" ? prev : {};
                all[rootKey] = names.slice();
                chrome.storage.local.set({ [FOLDER_ORDER_KEY]: all });
            });
        } catch {}
    }

    // `names` is the freshly scanned (alphabetical) list. Saved names that
    // still exist keep their saved order; anything new goes after them.
    function applySavedFolderOrder(names, saved) {
        if (!Array.isArray(saved) || saved.length === 0) return names;
        const remaining = new Set(names);
        const ordered = [];
        for (const n of saved) {
            if (remaining.has(n)) {
                ordered.push(n);
                remaining.delete(n);
            }
        }
        for (const n of names) if (remaining.has(n)) ordered.push(n);
        return ordered;
    }

    function clearFolderDropIndicators() {
        const listEl = document.getElementById(PANEL_FOLDER_LIST_ID);
        if (!listEl) return;
        listEl.querySelectorAll("." + FOLDER_CHIP_CLASS).forEach((c) => {
            c.style.boxShadow = "";
        });
    }

    function blockSelectDuringDrag(ev) {
        ev.preventDefault();
    }

    function onFolderChipPointerDown(ev) {
        if (!advancedFolderMode) return;
        // Primary button / touch / pen contact only (those all report 0).
        if (ev.button !== 0) return;
        // A previous drag whose pointerup never arrived must not wedge
        // dragging for good: tidy it up and start fresh.
        if (folderDragState) endFolderDrag();
        const chip = ev.target && ev.target.closest ? ev.target.closest("." + FOLDER_CHIP_CLASS) : null;
        if (!chip || !chip.dataset.folderName) return;
        folderDragState = {
            chip,
            name: chip.dataset.folderName,
            startX: ev.clientX,
            startY: ev.clientY,
            dragging: false,
            insertAt: -1,
        };
        window.addEventListener("pointermove", onFolderDragMove, true);
        window.addEventListener("pointerup", onFolderDragEnd, true);
        window.addEventListener("pointercancel", onFolderDragEnd, true);
    }

    function onFolderDragMove(ev) {
        const st = folderDragState;
        if (!st) return;
        if (!st.dragging) {
            // A plain click (no real movement) must stay a click: only turn
            // into a drag once the pointer has moved past a small threshold.
            if (Math.hypot(ev.clientX - st.startX, ev.clientY - st.startY) < CHIP_DRAG_THRESHOLD_PX) return;
            st.dragging = true;
            st.chip.style.opacity = ".45";
            st.chip.style.cursor = "grabbing";
            try {
                window.getSelection().removeAllRanges();
            } catch {}
            window.addEventListener("selectstart", blockSelectDuringDrag, true);
        }
        ev.preventDefault();
        const listEl = document.getElementById(PANEL_FOLDER_LIST_ID);
        const chips = listEl ? Array.from(listEl.querySelectorAll("." + FOLDER_CHIP_CLASS)) : [];
        if (!chips.includes(st.chip)) {
            // The chips were rebuilt under us (e.g. a rescan): give up.
            endFolderDrag();
            return;
        }
        // Drop target = the chip nearest to the pointer (works across wrapped
        // rows); left half -> insert before it, right half -> after it.
        let best = -1;
        let bestDist = Infinity;
        chips.forEach((c, i) => {
            const r = c.getBoundingClientRect();
            const dx = Math.max(r.left - ev.clientX, 0, ev.clientX - r.right);
            const dy = Math.max(r.top - ev.clientY, 0, ev.clientY - r.bottom);
            const d = dx * dx + dy * dy;
            if (d < bestDist) {
                bestDist = d;
                best = i;
            }
        });
        clearFolderDropIndicators();
        if (best === -1) return;
        const r = chips[best].getBoundingClientRect();
        const after = ev.clientX > r.left + r.width / 2;
        st.insertAt = best + (after ? 1 : 0);
        chips[best].style.boxShadow = after ? "inset -3px 0 0 #22d3ee" : "inset 3px 0 0 #22d3ee";
    }

    function endFolderDrag() {
        const st = folderDragState;
        folderDragState = null;
        window.removeEventListener("pointermove", onFolderDragMove, true);
        window.removeEventListener("pointerup", onFolderDragEnd, true);
        window.removeEventListener("pointercancel", onFolderDragEnd, true);
        window.removeEventListener("selectstart", blockSelectDuringDrag, true);
        if (st) {
            if (st.dragging) chipClickSuppressUntil = Date.now() + 300;
            if (st.chip.isConnected) {
                st.chip.style.opacity = "";
                st.chip.style.cursor = "grab";
            }
        }
        clearFolderDropIndicators();
    }

    function onFolderDragEnd(ev) {
        const st = folderDragState;
        if (!st) return;
        const reorder = st.dragging && ev.type === "pointerup" && st.insertAt >= 0;
        const insertAt = st.insertAt;
        endFolderDrag();
        if (!reorder) return;
        // insertAt is a slot in the list as it was BEFORE removing the
        // dragged chip, so it shifts down by one when moving rightwards.
        const from = currentFolders.indexOf(st.name);
        if (from === -1) return;
        const next = currentFolders.slice();
        next.splice(from, 1);
        next.splice(insertAt > from ? insertAt - 1 : insertAt, 0, st.name);
        if (next.every((n, i) => n === currentFolders[i])) return;
        currentFolders = next;
        saveFolderOrder(folderOrderRootKey(), next);
        renderAdvancedFolderSection();
        syncRowFolderInputs();
    }

    // A small confirm/choice overlay, independent of the panel (so it still
    // shows even if the panel were to close), used for the "video(s) chưa
    // được chọn thư mục" warning below. Resolves with whichever button's
    // `value` was clicked, or "cancel" if the user clicks outside the card.
    function showConfirmModal({ title, message, buttons }) {
        return new Promise((resolve) => {
            const overlay = document.createElement("div");
            overlay.style.cssText =
                "position:fixed!important;inset:0!important;background:rgba(0,0,0,.5)!important;z-index:2147483647!important;display:flex!important;align-items:center!important;justify-content:center!important;";
            const card = document.createElement("div");
            card.style.cssText =
                "width:280px;max-width:90vw;background:rgba(20,20,26,.98);border:1px solid rgba(255,255,255,.12);border-radius:14px;padding:16px;box-shadow:0 16px 48px rgba(0,0,0,.6);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#fff;";
            card.innerHTML =
                (title ? '<div style="font-weight:700;font-size:13.5px;margin-bottom:6px;">' + escapeHtml(title) + "</div>" : "") +
                '<div style="font-size:12.5px;opacity:.85;line-height:1.5;margin-bottom:14px;">' + escapeHtml(message) + "</div>";
            const btnRow = document.createElement("div");
            btnRow.style.cssText = "display:flex;flex-direction:column;gap:8px;";
            buttons.forEach((b) => {
                const btn = document.createElement("button");
                btn.type = "button";
                btn.textContent = b.label;
                btn.style.cssText =
                    "height:34px;border-radius:9px;font-size:12.5px;font-weight:700;cursor:pointer;" +
                    (b.primary
                        ? "border:0;background:linear-gradient(135deg,#a855f7,#22d3ee);color:#fff;"
                        : "border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.06);color:#fff;");
                btn.addEventListener("click", (ev) => {
                    stopCardEvent(ev);
                    if (overlay.isConnected) document.body.removeChild(overlay);
                    resolve(b.value);
                });
                btnRow.appendChild(btn);
            });
            card.appendChild(btnRow);
            overlay.appendChild(card);
            for (const type of ["pointerdown", "mousedown", "touchstart"]) {
                overlay.addEventListener(type, (ev) => ev.stopPropagation(), true);
            }
            overlay.addEventListener("click", (ev) => {
                if (ev.target !== overlay) return;
                if (overlay.isConnected) document.body.removeChild(overlay);
                resolve("cancel");
            });
            (document.body || document.documentElement).appendChild(overlay);
        });
    }

    // Section 14 of the spec: before downloading, any video still missing a
    // folder mapping must be called out — never silently assigned a random
    // folder. Returns the list of items to actually download:
    //   - unchanged, for "Tải về thư mục gốc" AND for the default case
    //     (nothing unmapped, or advanced mode isn't active) — an item left
    //     with folderName === null/undefined already saves straight into
    //     rootDirHandle (see saveToChosenFolder's `targetDirHandle` default),
    //     so no special-casing is needed here to make that happen;
    //   - a subset (only the already-mapped ones), for "Bỏ qua video này";
    //   - or null if the batch should not proceed at all ("Hủy", or "Chọn
    //     thư mục" — which instead focuses the first unmapped row so the
    //     user can map it and press download again).
    async function resolveDownloadBatch(items) {
        if (!advancedFolderMode || !rootDirHandle) return items;
        const unmapped = items.filter((i) => !i.folderName);
        if (unmapped.length === 0) return items;
        const choice = await showConfirmModal({
            title: "Có video chưa được chọn thư mục",
            message: unmapped.length + "/" + items.length + " video chưa được liên kết với thư mục con. Bạn muốn làm gì?",
            buttons: [
                { label: "Chọn thư mục", value: "map", primary: true },
                { label: "Tải về thư mục gốc", value: "root" },
                { label: "Bỏ qua video này", value: "skip" },
                { label: "Hủy", value: "cancel" },
            ],
        });
        if (choice === "root") return items;
        if (choice === "skip") return items.filter((i) => i.folderName);
        if (choice === "map") {
            const first = unmapped[0];
            const row = document.querySelector('[data-url="' + CSS.escape(first.url) + '"]');
            const input = row && row.querySelector("." + ROW_FOLDER_INPUT_CLASS);
            if (input) {
                input.focus();
                try {
                    input.scrollIntoView({ block: "center", behavior: "smooth" });
                } catch {}
            }
        }
        return null;
    }

    // Shows a short-lived summary banner fixed to the center of the
    // viewport once a batch download (runBatchDownload) finishes.
    //
    // This used to be a banner drawn *inside* the panel — but updateFab()
    // calls closePanel() the instant `selected` empties out, and every
    // successful item removes itself from `selected` as soon as it
    // finishes (see removeSelection). So on a fully-successful batch (the
    // common case), the very last item's success would empty `selected`,
    // close the panel, and only *then* would runBatchDownload try to show
    // the "✓ Đã tải xong…" banner inside that now-hidden panel — so it was
    // being set but never actually seen. Rendering it as its own
    // body-level, centered element sidesteps that: it stays visible no
    // matter what state the panel is in.
    //
    // There is also still no OS-level "download complete" notification for
    // videos saved through the chosen-folder flow (see the "Save to
    // folder" comment above), so this remains the only thing that actually
    // tells the user the batch is done.
    let centerToastTimer = null;
    function showCenterToast(text, tone, durationMs) {
        let el = document.getElementById(CENTER_TOAST_ID);
        if (!el) {
            el = document.createElement("div");
            el.id = CENTER_TOAST_ID;
            el.style.cssText =
                'position:fixed!important;top:50%!important;left:50%!important;' +
                'transform:translate(-50%,-50%)!important;max-width:min(86vw,420px)!important;' +
                'padding:14px 22px!important;border-radius:14px!important;background:rgba(0,0,0,.92)!important;' +
                'backdrop-filter:blur(20px)!important;-webkit-backdrop-filter:blur(20px)!important;color:#fff!important;' +
                'font:700 14px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif!important;text-align:center!important;' +
                'box-shadow:0 12px 40px rgba(0,0,0,.5),0 0 30px rgba(34,211,238,.2)!important;' +
                'border:1px solid rgba(34,211,238,.4)!important;z-index:2147483647!important;pointer-events:none!important;' +
                'opacity:0!important;transition:opacity .25s!important;';
            (document.body || document.documentElement).appendChild(el);
        }
        if (centerToastTimer) clearTimeout(centerToastTimer);
        el.textContent = text;
        const borderColor =
            tone === "error" ? "rgba(251,113,133,.5)" : tone === "warn" ? "rgba(251,191,36,.5)" : "rgba(34,211,238,.4)";
        const textColor = tone === "error" ? "#fb7185" : tone === "warn" ? "#fbbf24" : "#67e8f9";
        el.style.setProperty("border-color", borderColor, "important");
        el.style.setProperty("color", textColor, "important");
        requestAnimationFrame(() => {
            el.style.setProperty("opacity", "1", "important");
        });
        centerToastTimer = setTimeout(() => {
            centerToastTimer = null;
            el.style.setProperty("opacity", "0", "important");
        }, durationMs || 5000);
    }

    /* ---------------- "Open video player" (reuses the existing popup window) --------------- */

    // There's no cross-window "closed" event, so the only reliable way to
    // notice the player popup went away (native close button, Alt+F4, the
    // user just navigating it elsewhere) is to poll win.closed. Only one
    // poll ever runs: window.open() with PLAYER_WINDOW_NAME reuses/navigates
    // the same popup rather than opening a new one, so opening it again
    // (even for a different item) just re-points this same poll at the new
    // item instead of stacking a second interval.
    let playerCloseWatchId = null;

    function watchPlayerWindowClose(win, item) {
        if (playerCloseWatchId) clearInterval(playerCloseWatchId);
        playerCloseWatchId = setInterval(() => {
            let closed = true;
            try {
                closed = !win || win.closed;
            } catch {
                closed = true;
            }
            if (!closed) return;
            clearInterval(playerCloseWatchId);
            playerCloseWatchId = null;
            clearWatchingItem(item);
        }, 500);
    }

    function openPlayerWindow(item, setStatus) {
        const url = item && item.url;
        if (!url) return;
        // "Luôn hiển thị trên cùng": ordinary popup windows cannot be pinned on
        // top, so use the Document PiP window (always above other windows).
        // Needs Chrome's Document PiP; otherwise fall through to the popup.
        if (playerAlwaysOnTop && window.documentPictureInPicture) {
            previewPip(item, setStatus);
            return;
        }
        try {
            const target = new URL("/search", location.origin);
            target.searchParams.set(PLAYER_REQUEST_PARAM, url);
            const win = window.open(
                target.href,
                PLAYER_WINDOW_NAME,
                "popup=yes,width=560,height=820,resizable=yes,scrollbars=no"
            );
            if (win) {
                try {
                    win.focus();
                } catch {}
                setWatchingItem(item);
                watchPlayerWindowClose(win, item);
            }
        } catch {}
    }

    /* ---------------- PIP preview (new: this is a "view", not a "download") ---------------
     * Delegates to the exact same Document PiP flow the Search/Explore PiP
     * button uses (assets/tiktok-hook.js, MAIN world): a scrubbable seek bar,
     * custom transparent controls, and no native-PiP dark hover overlay.
     * Runs in the ISOLATED world, so it bridges to that MAIN-world flow with a
     * same-tick CustomEvent (dispatchEvent() calls listeners in every world
     * synchronously — unlike postMessage(), which would lose the click's user
     * gesture before tiktok-hook.js can call documentPictureInPicture.requestWindow()).
     * tiktok-hook.js owns all "is this URL already showing / same-window
     * switch / toggle-closed" logic, so this function only needs to relay the
     * URL and reflect back whatever state it reports. */

    let pipRequestSeq = 0;

    function previewPip(item, setStatus) {
        const url = item && item.url;
        if (!url) return;
        const requestId = "multi-pip-" + Date.now().toString(36) + "-" + (++pipRequestSeq);
        let settled = false;

        const finish = () => {
            settled = true;
            window.removeEventListener("__DOWNLOAD_MULTISELECT_PIP_RESPONSE__", onResponse);
            clearTimeout(timeoutId);
        };
        const onResponse = (event) => {
            const detail = event && event.detail;
            if (!detail || detail.requestId !== requestId) return;
            if (detail.state === "loading") {
                // Not terminal — tiktok-hook.js still has an "ok"/"error"
                // report coming for this same requestId once the stream is
                // fetched and the PiP window actually opens, so the listener
                // has to stay attached (finish() must NOT run here, or that
                // second report is missed entirely and the row gets stuck
                // showing "Đang tải…" forever instead of updating to "Đang
                // xem").
                setStatus && setStatus("Đang tải…");
                return;
            }
            finish();
            if (detail.state === "error") {
                setStatus && setStatus(detail.message || "Không thể xem PIP video này", true);
                return;
            }
            if (detail.state === "closed") {
                // Toggled off by clicking the already-open thumbnail again.
                clearWatchingItem(item);
                return;
            }
            // "ok": opened, or switched in place from a different URL — mark
            // this row as the one being watched (this also clears "Đang
            // xem" off whichever other row, PiP or player, held it before).
            setWatchingItem(item);
        };
        // tiktok-hook.js reports "loading" almost immediately, so a stuck
        // spinner past a few seconds means the bridge never got a listener
        // (e.g. an unusual page state) rather than a slow network fetch.
        const timeoutId = setTimeout(() => {
            if (settled) return;
            finish();
            setStatus && setStatus("Không thể xem PIP video này", true);
        }, 8000);

        window.addEventListener("__DOWNLOAD_MULTISELECT_PIP_RESPONSE__", onResponse);
        try {
            window.dispatchEvent(new CustomEvent("__DOWNLOAD_MULTISELECT_PIP_REQUEST__", {
                detail: { url, requestId },
            }));
        } catch {
            finish();
            setStatus && setStatus("PiP không được trình duyệt hỗ trợ", true);
        }
    }

    /* ---------------- selection state ---------------- */

    /** url -> { url, thumb, title, picked } */
    const selected = new Map();
    /** url -> Set<checkboxEl>  (keeps every on-page checkbox for a url in sync) */
    const urlCheckboxes = new Map();

    /* ---------------- "currently watching" indicator ----------------
     * Shared between the PiP thumbnail button and the "open video player"
     * button: only one row should ever show "Đang xem" at a time, no
     * matter which of the two actions opened it. Tracked by item (not by
     * a row/status closure) because the list can be fully rebuilt while
     * a video is open (renderPanelList/removePanelRowByUrl swap out row
     * elements), so any status update has to be re-looked-up via
     * setRowStatus at the time it happens. */
    let watchingItem = null;

    // Marks `item` as the one currently being watched: shows "Đang xem"
    // on its row and clears that text off whichever other item was
    // previously marked, if any.
    function setWatchingItem(item) {
        if (watchingItem && watchingItem !== item) {
            setRowStatus(watchingItem, "");
        }
        watchingItem = item;
        if (item) setRowStatus(item, "Đang xem");
    }

    // Clears `item`'s "Đang xem" indicator, but only while it's still the
    // one being tracked — guards against a late/stale event (e.g. an old
    // PiP "closed" response) overwriting a status set by a newer action.
    function clearWatchingItem(item) {
        if (watchingItem !== item) return;
        watchingItem = null;
        setRowStatus(item, "");
    }

    // The MAIN-world hook (tiktok-hook.js) broadcasts this whenever a PiP
    // window it manages closes for any reason — the native close button on
    // the PiP window, navigating it away, "leavepictureinpicture" — not just
    // the toggle-off-by-clicking-the-thumbnail-again path already covered by
    // previewPip's own request/response above. Clears "Đang xem" for that
    // URL if it's still the one currently marked (no-op otherwise).
    window.addEventListener("__DOWNLOAD_MULTISELECT_PIP_CLOSED__", (event) => {
        const url = event && event.detail && event.detail.url;
        if (!url || !watchingItem || watchingItem.url !== url) return;
        clearWatchingItem(watchingItem);
    });

    /* ---------------- rename-on-download (panel-only naming) ---------------- */

    // Every download the panel triggers reads the rename box fresh, so the
    // filename always matches what's currently typed — no separate "apply"
    // step needed. The counter is keyed to the *normalized* name so it only
    // resets when the user actually types a different name; "name" and
    // "name -" normalize to the same base and keep counting together.
    let renameBaseKey = "";
    let renameCounter = 0;

    function normalizeRenameBase(raw) {
        // Strip any trailing "-" the user already typed (with surrounding
        // spaces) so exactly one " - (N)" gets appended below — never two.
        return String(raw || "").trim().replace(/\s*-+\s*$/, "").trim();
    }

    function nextRenamedFilename(raw) {
        const base = normalizeRenameBase(raw);
        if (!base) return "";
        if (base !== renameBaseKey) {
            renameBaseKey = base;
            renameCounter = 0;
        }
        renameCounter += 1;
        return base + " - (" + renameCounter + ")";
    }

    function registerCheckbox(url, el) {
        let set = urlCheckboxes.get(url);
        if (!set) {
            set = new Set();
            urlCheckboxes.set(url, set);
        }
        set.add(el);
    }

    function syncCheckboxesFor(url) {
        const set = urlCheckboxes.get(url);
        if (!set) return;
        const isSelected = selected.has(url);
        for (const el of Array.from(set)) {
            if (!el.isConnected) {
                set.delete(el);
                continue;
            }
            setCheckboxVisual(el, isSelected);
        }
    }

    function setCheckboxVisual(el, checked) {
        el.dataset.checked = checked ? "1" : "0";
        el.setAttribute("aria-checked", checked ? "true" : "false");
        el.style.background = checked
            ? "linear-gradient(135deg,#a855f7,#22d3ee)"
            : "rgba(0,0,0,.55)";
        el.style.borderColor = checked ? "rgba(255,255,255,.9)" : "rgba(255,255,255,.75)";
        const mark = el.querySelector("svg");
        if (mark) mark.style.opacity = checked ? "1" : "0";
    }

    function extractThumb(link) {
        const img = link.querySelector("img");
        if (img && (img.currentSrc || img.src)) return img.currentSrc || img.src;
        const video = link.querySelector("video");
        if (video && video.poster) return video.poster;
        const bgEl = link.querySelector("[style*='background-image']");
        if (bgEl) {
            const m = /url\((['"]?)(.*?)\1\)/.exec(bgEl.style.backgroundImage || "");
            if (m && m[2]) return m[2];
        }
        return "";
    }

    function extractTitle(link, url) {
        const img = link.querySelector("img[alt]");
        if (img && img.alt && img.alt.trim()) return img.alt.trim();
        const m = /\/video\/(\d+)/.exec(url);
        return m ? "Video …" + m[1].slice(-6) : "TikTok video";
    }

    function toggleSelection(link, checkboxEl) {
        const url = videoUrl(link.href);
        if (!url) return;
        const isAdding = !selected.has(url);
        let addedItem = null;
        if (!isAdding) {
            selected.delete(url);
        } else {
            addedItem = {
                url,
                thumb: extractThumb(link),
                title: extractTitle(link, url),
                picked: true,
            };
            selected.set(url, addedItem);
        }
        registerCheckbox(url, checkboxEl);
        syncCheckboxesFor(url);
        updateFab();
        // Selecting a video never changes how the list is displayed: while
        // the list is in expanded mode it is (re)shown with the new row in
        // it, while it is in collapsed mode only the FAB icon/count updates
        // and the list stays hidden. Only the user clicking the FAB (or the
        // panel's ×) switches between the two modes, see togglePanel().
        if (isAdding && panelExpandedMode && !panelOpen) {
            // Genuinely opening the panel from hidden: a full render is
            // correct (and cheap) here since there's no existing DOM to
            // preserve yet.
            openPanel();
        } else if (panelOpen) {
            // Panel is already visible: touch only the one row that
            // changed instead of tearing down and rebuilding the whole
            // list (which was reloading every thumbnail image on every
            // single click).
            if (isAdding) {
                appendPanelRow(addedItem);
            } else {
                removePanelRowByUrl(url);
            }
        }
    }

    function removeSelection(url) {
        const item = selected.get(url);
        if (item && watchingItem === item) watchingItem = null;
        selected.delete(url);
        syncCheckboxesFor(url);
        updateFab();
        // updateFab() already closes the panel via closePanel() once the
        // list empties out, so this only needs to touch a still-open panel.
        if (panelOpen) removePanelRowByUrl(url);
    }

    // Tells the existing Search/Explore 4-button module (MAIN world) that a
    // video was downloaded from this panel, so its own on-card Download icon
    // switches to the same "Đã tải" state it already shows for its own
    // button — cross-world bridge, same pattern as __download_settings__.
    function markDownloadedOnPage(url) {
        try {
            window.dispatchEvent(new CustomEvent("__download_multi_mark_downloaded__", { detail: { url } }));
        } catch {}
    }

    /* ---------------- checkbox creation + DOM scanning ---------------- */

    function makeCheckbox() {
        const el = document.createElement("div");
        el.className = CHECKBOX_CLASS;
        el.setAttribute("role", "checkbox");
        el.setAttribute("aria-checked", "false");
        el.title = "Chọn video này";
        el.style.cssText =
            "position:absolute!important;top:8px!important;left:8px!important;width:26px!important;height:26px!important;border-radius:7px!important;background:rgba(0,0,0,.55)!important;border:1.5px solid rgba(255,255,255,.75)!important;display:flex!important;align-items:center!important;justify-content:center!important;cursor:pointer!important;z-index:2147483645!important;transition:transform .12s ease,background .15s ease,border-color .15s ease!important;pointer-events:auto!important";
        el.innerHTML =
            '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" style="opacity:0;transition:opacity .1s ease;pointer-events:none"><path d="M20 6 9 17l-5-5"/></svg>';
        el.addEventListener("mouseenter", () => (el.style.transform = "scale(1.08)"));
        el.addEventListener("mouseleave", () => (el.style.transform = "scale(1)"));
        return el;
    }

    function attachCheckboxForLink(link) {
        if (!isThumbnailLink(link)) return;
        let checkboxEl = link.querySelector(":scope > ." + CHECKBOX_CLASS);
        if (!checkboxEl) {
            try {
                if (getComputedStyle(link).position === "static") link.style.setProperty("position", "relative", "important");
            } catch {}
            checkboxEl = makeCheckbox();
            checkboxEl.addEventListener(
                "click",
                (ev) => {
                    stopCardEvent(ev);
                    toggleSelection(link, checkboxEl);
                },
                true
            );
            for (const type of ["pointerdown", "mousedown", "touchstart"]) {
                checkboxEl.addEventListener(type, stopCardEvent, true);
            }
            link.appendChild(checkboxEl);
        }
        const url = videoUrl(link.href);
        if (url) {
            registerCheckbox(url, checkboxEl);
            setCheckboxVisual(checkboxEl, selected.has(url));
        }
    }

    let scanScheduled = false;
    const queuedNodes = new Set();

    function scanRoot(root) {
        if (!isSearchPage() || !root) return;
        if (root === document) {
            document.querySelectorAll("a[href*='/video/']").forEach(attachCheckboxForLink);
            return;
        }
        if (root.nodeType !== 1) return;
        if (root.matches && root.matches("a[href*='/video/']")) attachCheckboxForLink(root);
        const parentLink = root.closest && root.closest("a[href*='/video/']");
        if (parentLink) attachCheckboxForLink(parentLink);
        if (root.querySelectorAll) root.querySelectorAll("a[href*='/video/']").forEach(attachCheckboxForLink);
    }

    function flushScan() {
        scanScheduled = false;
        const nodes = Array.from(queuedNodes);
        queuedNodes.clear();
        nodes.forEach(scanRoot);
    }

    function queueScan(node) {
        if (node) queuedNodes.add(node);
        if (!scanScheduled) {
            scanScheduled = true;
            requestAnimationFrame(flushScan);
        }
    }

    function scanAll() {
        queueScan(document);
    }

    function initObserver() {
        const root = document.documentElement;
        if (!root) {
            setTimeout(initObserver, 50);
            return;
        }
        try {
            new MutationObserver((records) => {
                for (const record of records) {
                    if (record.type === "attributes") queueScan(record.target);
                    else record.addedNodes.forEach(queueScan);
                }
            }).observe(root, { childList: true, subtree: true, attributes: true, attributeFilter: ["href", "src"] });
        } catch {}
    }

    /* ---------------- floating counter icon (FAB): bottom-right by default, draggable, persisted ---------------- */

    // Clamp + apply a right/bottom offset pair to the FAB so it can never be
    // dragged fully off-screen (also re-clamps on window resize).
    function applyFabPosition(right, bottom) {
        const fab = document.getElementById(FAB_ID);
        if (!fab) return;
        const w = fab.offsetWidth || FAB_SIZE;
        const h = fab.offsetHeight || FAB_SIZE;
        const maxRight = Math.max(4, window.innerWidth - w - 4);
        const maxBottom = Math.max(4, window.innerHeight - h - 4);
        right = Math.min(Math.max(4, right), maxRight);
        bottom = Math.min(Math.max(4, bottom), maxBottom);
        fab.style.right = right + "px";
        fab.style.bottom = bottom + "px";
        fab.style.left = "auto";
    }

    function saveFabPosition(right, bottom) {
        try {
            chrome.storage.local.set({ [FAB_POS_KEY]: { right, bottom } });
        } catch {}
    }

    function loadFabPosition() {
        try {
            chrome.storage.local.get(FAB_POS_KEY, (res) => {
                const pos = res && res[FAB_POS_KEY];
                if (pos && typeof pos.right === "number" && typeof pos.bottom === "number") {
                    applyFabPosition(pos.right, pos.bottom);
                }
            });
        } catch {}
    }

    let fabDragState = null;
    let fabSuppressNextClick = false;

    function ensureFab() {
        let fab = document.getElementById(FAB_ID);
        if (fab) return fab;
        fab = document.createElement("div");
        fab.id = FAB_ID;
        // Default corner: bottom-right. Position is expressed via right/bottom
        // (not left) so dragging + resize-clamping stay simple and consistent.
        fab.style.cssText =
            'position:fixed!important;right:' + FAB_MARGIN + 'px!important;bottom:' + FAB_MARGIN + 'px!important;min-width:52px!important;height:52px!important;padding:0 14px!important;border-radius:26px!important;background:linear-gradient(135deg,#a855f7,#22d3ee)!important;align-items:center!important;justify-content:center!important;gap:8px!important;cursor:grab!important;z-index:2147483646!important;box-shadow:0 6px 24px rgba(0,0,0,.45),inset 0 0 0 1px rgba(255,255,255,.18)!important;font:700 15px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif!important;color:#fff!important;user-select:none!important;touch-action:none!important;transition:transform .15s ease!important;display:none';
        let iconSrc = "";
        try {
            iconSrc = chrome.runtime.getURL("icons/icon-32.png");
        } catch {}
        fab.innerHTML =
            (iconSrc
                ? '<img src="' + iconSrc + '" alt="" style="width:22px;height:22px;object-fit:contain;display:block;pointer-events:none;">'
                : "") + '<span id="' + FAB_COUNT_ID + '" style="pointer-events:none;">0</span>';
        fab.title = "Giữ để di chuyển · Bấm để xổ/thu gọn danh sách";
        fab.addEventListener("mouseenter", () => {
            if (!fabDragState) fab.style.transform = "scale(1.06)";
        });
        fab.addEventListener("mouseleave", () => {
            if (!fabDragState) fab.style.transform = "scale(1)";
        });
        fab.addEventListener(
            "click",
            (ev) => {
                stopCardEvent(ev);
                if (fabSuppressNextClick) {
                    fabSuppressNextClick = false;
                    return;
                }
                togglePanel();
            },
            true
        );
        for (const type of ["mousedown", "touchstart"]) fab.addEventListener(type, stopCardEvent, true);

        // Press-and-hold to move: track from pointerdown, only "become" a
        // drag once the pointer has moved past a small threshold (so a plain
        // tap still opens the panel instead of being swallowed as a drag).
        fab.addEventListener(
            "pointerdown",
            (ev) => {
                stopCardEvent(ev);
                const rect = fab.getBoundingClientRect();
                fabDragState = {
                    pointerId: ev.pointerId,
                    startX: ev.clientX,
                    startY: ev.clientY,
                    startRight: window.innerWidth - rect.right,
                    startBottom: window.innerHeight - rect.bottom,
                    moved: false,
                };
                try {
                    fab.setPointerCapture(ev.pointerId);
                } catch {}
            },
            true
        );
        fab.addEventListener(
            "pointermove",
            (ev) => {
                if (!fabDragState || ev.pointerId !== fabDragState.pointerId) return;
                const dx = ev.clientX - fabDragState.startX;
                const dy = ev.clientY - fabDragState.startY;
                if (!fabDragState.moved && Math.hypot(dx, dy) > DRAG_THRESHOLD) {
                    fabDragState.moved = true;
                    fab.style.transition = "none";
                    fab.style.cursor = "grabbing";
                }
                if (fabDragState.moved) {
                    stopCardEvent(ev);
                    applyFabPosition(fabDragState.startRight - dx, fabDragState.startBottom - dy);
                    if (panelOpen) positionPanelNearFab();
                }
            },
            true
        );
        const endFabDrag = (ev) => {
            if (!fabDragState || ev.pointerId !== fabDragState.pointerId) return;
            fab.style.transition = "";
            fab.style.cursor = "grab";
            try {
                fab.releasePointerCapture(ev.pointerId);
            } catch {}
            if (fabDragState.moved) {
                stopCardEvent(ev);
                const right = parseFloat(fab.style.right) || FAB_MARGIN;
                const bottom = parseFloat(fab.style.bottom) || FAB_MARGIN;
                saveFabPosition(right, bottom);
                fabSuppressNextClick = true; // the browser still fires "click" right after; swallow just that one
            }
            fabDragState = null;
        };
        fab.addEventListener("pointerup", endFabDrag, true);
        fab.addEventListener("pointercancel", endFabDrag, true);

        (document.body || document.documentElement).appendChild(fab);
        loadFabPosition();
        window.addEventListener("resize", () => {
            const right = parseFloat(fab.style.right) || FAB_MARGIN;
            const bottom = parseFloat(fab.style.bottom) || FAB_MARGIN;
            applyFabPosition(right, bottom);
            if (panelOpen) positionPanelNearFab();
        });
        return fab;
    }

    function updateFab() {
        const fab = ensureFab();
        const count = selected.size;
        const countEl = document.getElementById(FAB_COUNT_ID);
        if (countEl) countEl.textContent = String(count);
        fab.style.display = count > 0 ? "flex" : "none";
        if (count === 0) closePanel();
    }

    /* ---------------- management panel ---------------- */

    let panelOpen = false;

    function ensurePanel() {
        let panel = document.getElementById(PANEL_ID);
        if (panel) return panel;
        panel = document.createElement("div");
        panel.id = PANEL_ID;
        panel.style.cssText =
            'position:fixed!important;right:16px!important;bottom:80px!important;width:320px!important;max-height:60vh!important;flex-direction:column!important;background:rgba(15,15,20,.97)!important;backdrop-filter:blur(20px)!important;-webkit-backdrop-filter:blur(20px)!important;border:1px solid rgba(255,255,255,.12)!important;border-radius:16px!important;box-shadow:0 16px 48px rgba(0,0,0,.55)!important;z-index:2147483646!important;overflow:hidden!important;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif!important;color:#fff!important;display:none';
        // Actual position is recalculated relative to the FAB's current spot
        // every time the panel opens (positionPanelNearFab) — the values
        // above are only a same-tick fallback before that first runs.
        panel.innerHTML =
            '<div style="display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid rgba(255,255,255,.08);flex:none;">' +
            '<span style="font-weight:700;font-size:14px;">Video đã chọn (<span id="' + PANEL_COUNT_ID + '">0</span>)</span>' +
            '<button type="button" id="' + PANEL_CLOSE_ID + '" title="Đóng" style="width:26px;height:26px;border:0;border-radius:8px;background:rgba(255,255,255,.08);color:#fff;cursor:pointer;font-size:15px;line-height:1;">×</button>' +
            "</div>" +
            '<div style="display:flex;align-items:center;gap:8px;padding:8px 14px;border-bottom:1px solid rgba(255,255,255,.08);flex:none;">' +
            '<input type="checkbox" id="' + PANEL_SELECTALL_CHECK_ID + '" style="width:16px;height:16px;flex:none;accent-color:#22d3ee;cursor:pointer;" title="Select/Deselect all">' +
            '<label for="' + PANEL_SELECTALL_CHECK_ID + '" style="font-size:12px;opacity:.85;cursor:pointer;user-select:none;white-space:nowrap;">Select all</label>' +
            '<div id="' + PANEL_SAVEPATH_BOX_ID + '" title="Nhấp để chọn/đổi thư mục lưu video" style="flex:1;min-width:0;height:24px;display:flex;align-items:center;gap:5px;padding:0 6px 0 8px;border-radius:7px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);cursor:pointer;user-select:none;">' +
            folderIconSvg() +
            '<span id="' + PANEL_SAVEPATH_TEXT_ID + '" style="flex:1;min-width:0;font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">Đang tải…</span>' +
            '<button type="button" id="' + PANEL_SAVEPATH_CLEAR_ID + '" title="Bỏ chọn thư mục" style="display:none;width:15px;height:15px;flex:none;border:0;border-radius:5px;background:transparent;color:rgba(255,255,255,.55);cursor:pointer;font-size:12px;line-height:1;padding:0;">×</button>' +
            "</div>" +
            "</div>" +
            '<div id="' + PANEL_ADV_SECTION_ID + '" style="display:none;padding:8px 14px 10px;border-bottom:1px solid rgba(255,255,255,.08);flex:none;">' +
            '<div style="display:flex;align-items:center;justify-content:space-between;gap:6px;margin-bottom:6px;">' +
            '<span style="font-size:11px;font-weight:700;opacity:.75;">Thư mục con <span style="font-weight:400;opacity:.7;">(kéo để đổi vị trí)</span></span>' +
            '<button type="button" id="' + PANEL_ADV_REFRESH_ID + '" title="Làm mới danh sách thư mục" style="width:20px;height:20px;flex:none;border:0;border-radius:6px;background:rgba(255,255,255,.08);color:#fff;cursor:pointer;font-size:12px;line-height:1;">⟳</button>' +
            "</div>" +
            '<div id="' + PANEL_FOLDER_LIST_ID + '" style="display:flex;flex-wrap:wrap;gap:6px;"></div>' +
            "</div>" +
            '<div style="display:flex;align-items:center;gap:8px;padding:8px 14px 10px;border-bottom:1px solid rgba(255,255,255,.08);flex:none;">' +
            '<label for="' + PANEL_CONCURRENCY_INPUT_ID + '" style="font-size:11.5px;opacity:.75;white-space:nowrap;flex:none;">Tải cùng lúc</label>' +
            '<input type="number" id="' + PANEL_CONCURRENCY_INPUT_ID + '" min="1" max="' + MAX_CONCURRENCY + '" step="1" value="' + DEFAULT_CONCURRENCY + '" title="Tối đa ' + MAX_CONCURRENCY + ' video / lượt" style="width:40px;height:30px;flex:none;box-sizing:border-box;border-radius:7px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);color:#fff;font-size:12px;padding:0 4px;text-align:center;outline:none;">' +
            '<input type="text" id="' + PANEL_RENAME_INPUT_ID + '" placeholder="Đặt tên khi tải (vd: Dép Nesty Ne01)" style="flex:1;min-width:0;height:30px;box-sizing:border-box;border-radius:8px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);color:#fff;font-size:12px;padding:0 10px;outline:none;">' +
            "</div>" +
            '<div id="' + PANEL_LIST_ID + '" style="overflow-y:auto;flex:1 1 auto;padding:8px;display:flex;flex-direction:column;gap:8px;"></div>' +
            '<div style="display:flex;align-items:center;gap:8px;padding:10px 12px;border-top:1px solid rgba(255,255,255,.08);flex:none;">' +
            '<div title="Tải xuống" style="width:36px;height:36px;flex:none;border-radius:10px;background:linear-gradient(135deg,#a855f7,#22d3ee);display:flex;align-items:center;justify-content:center;box-shadow:0 2px 10px rgba(168,85,247,.4);">' + footerDownloadIconSvg() + "</div>" +
            '<button type="button" id="' + PANEL_DL_PICKED_ID + '" title="Tải các video đã chọn" style="flex:1;height:36px;border:1.5px solid rgba(34,211,238,.55);border-radius:10px;background:rgba(34,211,238,.14);color:#67e8f9;font-weight:700;font-size:12.5px;cursor:pointer;">Đã chọn</button>' +
            '<button type="button" id="' + PANEL_DL_ALL_ID + '" title="Tải tất cả video trong danh sách" style="flex:1;height:36px;border:0;border-radius:10px;background:linear-gradient(135deg,#a855f7,#22d3ee);color:#fff;font-weight:700;font-size:12.5px;cursor:pointer;box-shadow:0 2px 10px rgba(168,85,247,.4);">Tất cả</button>' +
            "</div>";
        (document.body || document.documentElement).appendChild(panel);

        panel.querySelector("#" + PANEL_CLOSE_ID).addEventListener("click", (ev) => {
            stopCardEvent(ev);
            setPanelExpandedMode(false);
            closePanel();
        });
        panel.querySelector("#" + PANEL_SELECTALL_CHECK_ID).addEventListener("change", (ev) => {
            const checkAll = ev.target.checked;
            for (const item of selected.values()) item.picked = checkAll;
            renderPanelList();
        });
        // "Save to folder" box: a single click opens the native folder
        // picker to choose (or change) where videos get saved — there is no
        // subfolder text to edit anymore. Double click intentionally does
        // nothing (the box doesn't try to distinguish it from a single
        // click at all — see the dblclick listener below).
        const savePathBox = panel.querySelector("#" + PANEL_SAVEPATH_BOX_ID);
        savePathBox.addEventListener("click", (ev) => {
            ev.stopPropagation();
            ev.preventDefault();
            // Box is showing "⚠ ... — nhấp để cấp lại quyền": a single
            // click here means re-confirm the lapsed permission instead
            // of opening the picker again (matches that label literally).
            if (savePathNeedsPermission) {
                requestRootPermission().then(() => {
                    refreshSavePathUI();
                    if (advancedFolderMode) rescanFolders();
                });
            } else pickRootFolder();
        });
        // Swallows the dblclick so it doesn't bubble out to the page (e.g.
        // TikTok's own double-click-to-like handling underneath) — the box
        // still just runs its normal click handler for each of the two
        // clicks that make up a double click.
        savePathBox.addEventListener("dblclick", stopCardEvent);
        panel.querySelector("#" + PANEL_SAVEPATH_CLEAR_ID).addEventListener("click", (ev) => {
            stopCardEvent(ev);
            clearRootFolder();
        });
        panel.querySelector("#" + PANEL_ADV_REFRESH_ID).addEventListener("click", (ev) => {
            stopCardEvent(ev);
            rescanFolders();
        });
        refreshSavePathUI();
        renderAdvancedFolderSection();
        // Prevent TikTok's own keyboard shortcuts (mute, next video, etc.)
        // from firing while the user is typing a rename — only propagation
        // is stopped, so normal typing/selection inside the box is untouched.
        for (const type of ["keydown", "keyup", "keypress"]) {
            panel.querySelector("#" + PANEL_RENAME_INPUT_ID).addEventListener(type, (ev) => ev.stopPropagation());
        }
        const concurrencyInput = panel.querySelector("#" + PANEL_CONCURRENCY_INPUT_ID);
        for (const type of ["keydown", "keyup", "keypress"]) {
            concurrencyInput.addEventListener(type, (ev) => ev.stopPropagation());
        }
        concurrencyInput.addEventListener("change", (ev) => {
            stopCardEvent(ev);
            const n = getConcurrency();
            ev.target.value = String(n);
            try {
                chrome.storage.local.set({ [CONCURRENCY_KEY]: n });
            } catch {}
        });
        // Mouse wheel over the concurrency stepper nudges it by 1 per notch
        // (scroll up = increase), clamped to [1, MAX_CONCURRENCY].
        concurrencyInput.addEventListener("wheel", (ev) => {
            stopCardEvent(ev);
            const current = getConcurrency();
            const next = Math.max(1, Math.min(MAX_CONCURRENCY, current + (ev.deltaY < 0 ? 1 : -1)));
            concurrencyInput.value = String(next);
            try {
                chrome.storage.local.set({ [CONCURRENCY_KEY]: next });
            } catch {}
        }, { passive: false });
        try {
            chrome.storage.local.get(CONCURRENCY_KEY, (res) => {
                const n = res && res[CONCURRENCY_KEY];
                if (Number.isFinite(n) && n >= 1 && n <= MAX_CONCURRENCY) concurrencyInput.value = String(n);
            });
        } catch {}
        panel.querySelector("#" + PANEL_DL_PICKED_ID).addEventListener("click", async (ev) => {
            stopCardEvent(ev);
            const resolved = await resolveDownloadBatch(Array.from(selected.values()).filter((i) => i.picked !== false));
            if (resolved) runBatchDownload(resolved);
        });
        panel.querySelector("#" + PANEL_DL_ALL_ID).addEventListener("click", async (ev) => {
            stopCardEvent(ev);
            const resolved = await resolveDownloadBatch(Array.from(selected.values()));
            if (resolved) runBatchDownload(resolved);
        });
        // Subfolder chips are re-ordered by dragging. This must be attached
        // BEFORE the capturing stopPropagation() loop right below: that loop
        // swallows pointerdown for everything inside the panel (the chips
        // included), but listeners already attached to the panel itself in
        // the same phase still run.
        panel.addEventListener("pointerdown", onFolderChipPointerDown, true);
        for (const type of ["pointerdown", "mousedown", "touchstart"]) {
            panel.addEventListener(type, (ev) => ev.stopPropagation(), true);
        }
        // IMPORTANT: "click" must be bubble-phase here, not capturing.
        // A capturing stopPropagation() on this ancestor would stop the event
        // before it ever reaches a row's own button (target phase never runs),
        // which is why download/player/thumb/remove silently did nothing.
        // Each row control already calls stopCardEvent() itself right after
        // it's handled, so this bubble listener only mops up clicks that land
        // on inert panel chrome (padding, the checkbox's native click) and
        // keeps those from leaking out to the page's own listeners.
        panel.addEventListener("click", (ev) => ev.stopPropagation(), false);
        return panel;
    }

    function getConcurrency() {
        const input = document.getElementById(PANEL_CONCURRENCY_INPUT_ID);
        let n = input ? parseInt(input.value, 10) : DEFAULT_CONCURRENCY;
        if (!Number.isFinite(n) || n < 1) n = 1;
        if (n > MAX_CONCURRENCY) n = MAX_CONCURRENCY;
        return n;
    }

    // Places the panel just above/beside wherever the FAB currently is
    // (which may have been dragged anywhere on screen), using explicit
    // left/bottom pixel values so it stays fully on-screen from any corner.
    function positionPanelNearFab() {
        const panel = document.getElementById(PANEL_ID);
        const fab = document.getElementById(FAB_ID);
        if (!panel || !fab) return;
        const fabRect = fab.getBoundingClientRect();
        const panelWidth = panel.offsetWidth || 320;
        const gap = 8;
        let left = fabRect.right - panelWidth;
        left = Math.max(8, Math.min(left, window.innerWidth - panelWidth - 8));
        let bottom = Math.max(8, window.innerHeight - fabRect.top + gap);
        panel.style.left = left + "px";
        panel.style.right = "auto";
        panel.style.bottom = bottom + "px";
    }

    function playerIconSvg() {
        return '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.25" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="m10 9 5 3-5 3Z" fill="currentColor" stroke="none"/></svg>';
    }
    function downloadIconSvg() {
        return '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.35" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></svg>';
    }
    // Slightly larger, fixed-white variant used for the standalone footer
    // icon badge — stroke is hard-coded (not currentColor) so it always
    // reads as a bright icon against that badge's colored gradient, no
    // matter what text color the surrounding panel ends up using.
    function footerDownloadIconSvg() {
        return '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></svg>';
    }

    function updateSelectAllCheckbox() {
        const cb = document.getElementById(PANEL_SELECTALL_CHECK_ID);
        if (!cb) return;
        const items = Array.from(selected.values());
        const total = items.length;
        const pickedCount = items.filter((i) => i.picked !== false).length;
        cb.disabled = total === 0;
        cb.checked = total > 0 && pickedCount === total;
        cb.indeterminate = pickedCount > 0 && pickedCount < total;
    }

    // Builds one row's DOM node and wires up its controls. Shared by the
    // full renderPanelList() rebuild and by appendPanelRow()'s single-row
    // insert, so the two paths can never drift out of sync with each other.
    // `index` (1-based position within the current `selected` order) is only
    // used for the advanced-mode ①②③ badge — callers outside advanced mode
    // can omit it. See renderPanelList/appendPanelRow for how it's supplied.
    function buildPanelRow(item, index) {
        const row = document.createElement("div");
        row.dataset.url = item.url;
        row.style.cssText = "display:flex;align-items:center;gap:8px;padding:6px;border-radius:10px;background:rgba(255,255,255,.045);";
        const badgeHtml = advancedFolderMode
            ? '<div class="' + ROW_NUM_BADGE_CLASS + '" style="width:16px;height:16px;flex:none;border-radius:50%;background:rgba(255,255,255,.12);display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:rgba(255,255,255,.75);">' + (index || 1) + "</div>"
            : "";
        const mappedIdx = advancedFolderMode && item.folderName ? folderIndexForName(item.folderName) : 0;
        const folderCellHtml = advancedFolderMode
            ? '<div class="' + ROW_FOLDER_CELL_CLASS + '" style="flex:none;">' +
              '<input type="text" inputmode="numeric" autocomplete="off" class="' + ROW_FOLDER_INPUT_CLASS + '" placeholder="-" value="' + (mappedIdx ? mappedIdx : "") + '" title="' + (currentFolders.length ? "Số thư mục (1-" + currentFolders.length + ")" : "Chưa có thư mục con") + '" style="width:32px;height:26px;box-sizing:border-box;border-radius:7px;border:1px solid ' + (mappedIdx ? "rgba(34,211,238,.55)" : "rgba(255,255,255,.15)") + ';background:rgba(255,255,255,.06);color:' + (mappedIdx ? "#67e8f9" : "#fff") + ';font-size:11px;text-align:center;outline:none;">' +
              "</div>"
            : "";
        row.innerHTML =
            badgeHtml +
            '<input type="checkbox" class="' + ROW_CHECK_CLASS + '" ' + (item.picked !== false ? "checked" : "") +
            ' style="width:16px;height:16px;flex:none;accent-color:#22d3ee;cursor:pointer;" title="Chọn để tải trong lượt Download tiếp theo">' +
            '<div class="' + ROW_THUMB_CLASS + '" title="Xem PIP" style="width:38px;height:54px;border-radius:6px;overflow:hidden;background:#000;flex:none;cursor:pointer;position:relative;">' +
            (item.thumb ? '<img src="' + escapeHtml(item.thumb) + '" style="width:100%;height:100%;object-fit:cover;display:block;pointer-events:none;">' : "") +
            "</div>" +
            '<div style="flex:1;min-width:0;">' +
            '<div style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + escapeHtml(item.title) + "</div>" +
            '<div class="' + ROW_STATUS_CLASS + '" style="font-size:10.5px;opacity:.65;margin-top:2px;"></div>' +
            "</div>" +
            '<button type="button" class="' + ROW_PLAYER_CLASS + '" title="Open video player" style="width:26px;height:26px;flex:none;border:0;border-radius:7px;background:rgba(255,255,255,.08);color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;">' + playerIconSvg() + "</button>" +
            '<button type="button" class="' + ROW_DL_CLASS + '" title="Download" style="width:26px;height:26px;flex:none;border:0;border-radius:7px;background:rgba(255,255,255,.08);color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;">' + downloadIconSvg() + "</button>" +
            '<button type="button" class="' + ROW_REMOVE_CLASS + '" title="Xoá khỏi danh sách" style="width:22px;height:22px;flex:none;border:0;border-radius:7px;background:transparent;color:rgba(255,255,255,.55);cursor:pointer;font-size:15px;line-height:1;">×</button>' +
            folderCellHtml;

        const statusEl = row.querySelector("." + ROW_STATUS_CLASS);
        const setStatus = (text, isError) => {
            if (!statusEl) return;
            statusEl.textContent = text || "";
            statusEl.style.color = isError ? "#fb7185" : "rgba(255,255,255,.65)";
        };

        row.querySelector("." + ROW_CHECK_CLASS).addEventListener("change", (ev) => {
            item.picked = ev.target.checked;
            updateSelectAllCheckbox();
        });
        row.querySelector("." + ROW_THUMB_CLASS).addEventListener("click", (ev) => {
            stopCardEvent(ev);
            previewPip(item, setStatus);
        });
        row.querySelector("." + ROW_PLAYER_CLASS).addEventListener("click", (ev) => {
            stopCardEvent(ev);
            openPlayerWindow(item, setStatus);
        });
        row.querySelector("." + ROW_DL_CLASS).addEventListener("click", async (ev) => {
            stopCardEvent(ev);
            // Advanced mode: refuse (with the standard 3-option prompt) to
            // download this one video while it still has no folder chosen,
            // same rule the batch buttons enforce — see resolveDownloadBatch.
            const resolved = await resolveDownloadBatch([item]);
            if (!resolved || resolved.length === 0) return;
            setStatus("Đang tải…");
            const r = await downloadUrl(item.url);
            setStatus(r.success ? "Đã tải xong" : "Lỗi: " + (r.error || "unknown"), !r.success);
            if (r.success) {
                removeSelection(item.url);
                markDownloadedOnPage(item.url);
            }
        });
        row.querySelector("." + ROW_REMOVE_CLASS).addEventListener("click", (ev) => {
            stopCardEvent(ev);
            removeSelection(item.url);
        });

        if (advancedFolderMode) {
            const folderInput = row.querySelector("." + ROW_FOLDER_INPUT_CLASS);
            if (folderInput) {
                folderInput.addEventListener("focus", () => {
                    focusedFolderInputEl = folderInput;
                    focusedFolderInputAt = Date.now();
                });
                folderInput.addEventListener("blur", () => {
                    if (focusedFolderInputEl === folderInput) focusedFolderInputAt = Date.now();
                });
                // No click/pointerdown handling needed here: the panel's own
                // bubble-phase listeners already stop these from leaking out
                // to the page (same as the rename/concurrency inputs above),
                // without calling preventDefault() — which a text input needs
                // left alone on mousedown, or it can never receive focus.
                for (const type of ["keydown", "keyup", "keypress"]) {
                    folderInput.addEventListener(type, (ev) => ev.stopPropagation());
                }
                folderInput.addEventListener("change", (ev) => {
                    stopCardEvent(ev);
                    handleFolderInputChange(item, folderInput);
                });
            }
        }

        return row;
    }

    function emptyListPlaceholderHtml() {
        return '<div data-empty="1" style="padding:18px 6px;text-align:center;font-size:12.5px;opacity:.6;">Chưa có video nào được chọn</div>';
    }

    function renderPanelList() {
        const list = document.getElementById(PANEL_LIST_ID);
        const countEl = document.getElementById(PANEL_COUNT_ID);
        if (countEl) countEl.textContent = String(selected.size);
        updateSelectAllCheckbox();
        if (!list) return;
        list.innerHTML = "";
        if (selected.size === 0) {
            list.innerHTML = emptyListPlaceholderHtml();
            return;
        }
        let i = 0;
        for (const item of selected.values()) {
            i++;
            list.appendChild(buildPanelRow(item, i));
        }
    }

    // Adds exactly one new row for `item` to an already-open panel, leaving
    // every existing row (and its already-loaded thumbnail image) untouched.
    // This is what stops a new selection from re-rendering/reflashing the
    // whole list — only the newly picked video's row is created.
    function appendPanelRow(item) {
        const list = document.getElementById(PANEL_LIST_ID);
        const countEl = document.getElementById(PANEL_COUNT_ID);
        if (countEl) countEl.textContent = String(selected.size);
        updateSelectAllCheckbox();
        if (!list) return;
        const placeholder = list.querySelector("[data-empty]");
        if (placeholder) list.innerHTML = "";
        list.appendChild(buildPanelRow(item, selected.size));
    }

    // Removes exactly the row for `url` from an already-open panel, without
    // rebuilding/reflashing any other row.
    function removePanelRowByUrl(url) {
        const list = document.getElementById(PANEL_LIST_ID);
        const countEl = document.getElementById(PANEL_COUNT_ID);
        if (countEl) countEl.textContent = String(selected.size);
        updateSelectAllCheckbox();
        if (!list) return;
        const row = list.querySelector('[data-url="' + CSS.escape(url) + '"]');
        if (row) row.remove();
        if (selected.size === 0) list.innerHTML = emptyListPlaceholderHtml();
        else renumberVisibleRows();
    }

    // Sets a row's status text by re-querying the DOM fresh (the list gets
    // fully rebuilt whenever any item finishes, via removeSelection ->
    // renderPanelList, so a stale element reference from before that
    // rebuild would silently write to a detached node).
    function setRowStatus(item, text, isError) {
        const list = document.getElementById(PANEL_LIST_ID);
        if (!list) return;
        const statusEls = list.querySelectorAll("." + ROW_STATUS_CLASS);
        const idx = Array.from(selected.values()).indexOf(item);
        const statusEl = statusEls[idx];
        if (!statusEl) return;
        statusEl.textContent = text || "";
        statusEl.style.color = isError ? "#fb7185" : "rgba(255,255,255,.65)";
    }

    // A batch is attempted at most this many times in total: the initial
    // pass over every item, plus up to two automatic retry passes that only
    // re-attempt whatever is still failing. Kept small and fixed (rather
    // than exposed as a setting) since most failures here are transient
    // (a metadata fetch racing the page, a momentary network hiccup) and
    // clear up within a couple of tries; anything still failing after 3
    // attempts is almost always a real error worth surfacing rather than
    // hiding behind more retries.
    const MAX_DOWNLOAD_ATTEMPTS = 3;
    // Short pause before each retry pass (not before the first pass), so a
    // retry doesn't immediately re-hit whatever just failed.
    const RETRY_DELAY_MS = 1200;

    // Runs one concurrent pass over `items` (up to `concurrency` requests in
    // flight at once, via a small worker pool draining a shared cursor) and
    // reports which ones failed, so the caller can decide whether to retry
    // them. `statusPrefix` lets a retry pass show e.g. "Đang tải lại (lần
    // 2)…" instead of the first-pass "Đang tải…", so the user can tell a
    // retry is happening rather than a fresh attempt.
    async function runDownloadPass(items, concurrency, statusPrefix) {
        let cursor = 0;
        let successCount = 0;
        const failed = [];

        async function worker(workerIndex) {
            // Stagger worker start slightly so a big batch doesn't fire every
            // request in the exact same tick.
            if (workerIndex > 0) await sleep(workerIndex * 150);
            while (true) {
                const idx = cursor++;
                if (idx >= items.length) return;
                const item = items[idx];
                setRowStatus(item, statusPrefix, false);
                const r = await downloadUrl(item.url);
                setRowStatus(item, r.success ? "Đã tải xong" : "Lỗi: " + (r.error || "unknown"), !r.success);
                if (r.success) {
                    successCount++;
                    removeSelection(item.url);
                    markDownloadedOnPage(item.url);
                } else {
                    item.lastError = r.error || "unknown";
                    failed.push(item);
                }
            }
        }

        const n = Math.min(concurrency, items.length);
        const workers = [];
        for (let i = 0; i < n; i++) workers.push(worker(i));
        await Promise.all(workers);
        return { successCount, failed };
    }

    // Downloads `items`, automatically retrying whatever is left over after
    // a pass still has failures — up to MAX_DOWNLOAD_ATTEMPTS attempts total
    // for any single item (1 initial pass + up to 2 retries). Only the
    // still-failing items are re-attempted each time, not the whole batch.
    async function runBatchDownload(items) {
        if (!items.length) return;
        const concurrency = getConcurrency();
        const total = items.length;
        let successCount = 0;
        let pending = items;
        let attempt = 1;

        while (pending.length && attempt <= MAX_DOWNLOAD_ATTEMPTS) {
            if (attempt > 1) {
                await sleep(RETRY_DELAY_MS);
            }
            const statusPrefix = attempt === 1 ? "Đang tải…" : "Đang tải lại (lần " + attempt + ")…";
            const result = await runDownloadPass(pending, concurrency, statusPrefix);
            successCount += result.successCount;
            pending = result.failed;
            attempt++;
        }

        const failCount = pending.length;
        const attemptsUsed = attempt - 1;

        // There is no OS-level "download complete" notification available
        // for videos saved through the chosen-folder flow (see the "Save to
        // folder" comment above), so this centered toast is what actually
        // tells the user the batch is done (see showCenterToast for why it
        // has to live outside the panel).
        if (failCount === 0) {
            showCenterToast("✓ Đã tải xong " + successCount + " video", "ok");
        } else if (successCount === 0) {
            showCenterToast(
                "Tải thất bại " + failCount + "/" + total + " video" + (attemptsUsed > 1 ? " (đã thử lại " + (attemptsUsed - 1) + " lần)" : ""),
                "error",
                6000
            );
        } else {
            showCenterToast(
                "Đã tải xong " + successCount + "/" + total + " video (" + failCount + " lỗi" + (attemptsUsed > 1 ? ", đã thử lại " + (attemptsUsed - 1) + " lần" : "") + ")",
                "warn",
                6000
            );
        }
    }

    function openPanel() {
        ensureFab();
        const panel = ensurePanel();
        renderPanelList();
        panel.style.display = "flex";
        panelOpen = true;
        positionPanelNearFab();
        // Re-check permission on the chosen folder every time the panel is
        // opened (not just once at page load) — Chrome can require the user
        // to re-confirm it after a browser restart, and this is what surfaces
        // that "⚠ needs permission again" state without a page reload.
        refreshSavePathUI();
        renderAdvancedFolderSection();
    }

    function closePanel() {
        const panel = document.getElementById(PANEL_ID);
        if (panel) panel.style.display = "none";
        panelOpen = false;
    }

    // Only the FAB's click handler calls this, so it is always an explicit
    // user choice — which is exactly what (re)sets the sticky display mode.
    function togglePanel() {
        if (panelOpen) {
            setPanelExpandedMode(false);
            closePanel();
        } else {
            setPanelExpandedMode(true);
            openPanel();
        }
    }

    // Deliberately NO "click outside" / Escape auto-close: the list stays in
    // whichever mode the user last chose (FAB click or the panel's ×), no
    // matter what else they do on the page.

    /* ---------------- init ---------------- */

    loadPanelExpandedMode();
    loadAdvancedFolderSetting();
    loadPlayerAlwaysOnTopSetting();
    loadRootDirHandle();
    scanAll();
    setTimeout(scanAll, 800);
    setTimeout(scanAll, 2000);
    initObserver();

    let lastHref = location.href;
    setInterval(() => {
        if (location.href !== lastHref) {
            lastHref = location.href;
            setTimeout(scanAll, 500);
            setTimeout(scanAll, 1500);
        }
    }, 1000);
})();
/* ===== [/Download] Multi-select checkbox + management panel ===== */
